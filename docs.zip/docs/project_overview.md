# Project Overview: Livelihood Evidence Loop

## 1. Executive Summary
The **Livelihood Evidence Loop** (beneficiary name: *Hunar Line*) is a one-district web prototype designed to demonstrate a livelihood intelligence system. It replaces top-down, seat-filling training programs with a continuous, evidence-based loop. 

The prototype tells one continuous story across 12 beats:
1. **Diagnose:** A beneficiary's spoken work history is converted into quoted evidence against national skill units and a specific barrier diagnosis.
2. **Allocate:** Local market evidence (supply, demand, workload) re-ranks her options. Her choice dynamically updates the district's planning board, tipping a planned intervention (like an RPL camp) over its viability threshold.
3. **Verify:** Independent check-ins on past trainees update the district's evidence, directly altering future rankings.

## 2. Technical Architecture & Constraints (CRITICAL FOR IDE)
* **Offline, Client-Side Execution:** The entire prototype must run in the browser from static seed files without a backend database.
* **Event Sourcing (State Management):** State equals the initial Seed Data plus an Event Log. **Never edit seed data in place.** Every action (consent, choice, replace plan line) appends an event.
* **Deterministic Rules vs. AI:** 
  * LLMs/AI are strictly forbidden from making decisions, ranking, or diagnosing. 
  * "AI" is solely used (conceptually/simulated) to extract facts and quotes from transcripts. 
  * All logic (Skill Evidence, Diagnosis, Pathways, Signals, Verdict, Allocation, Outcomes) must be strictly rule-based modules that output traceable, plain-text reasons.
* **Scripted Reality:** The primary demo relies on pre-scripted conversations (audio files and transcripts). Do NOT build live telephony, IVR, or live dialect speech recognition.

## 3. The Four User Roles & Interfaces
The app requires a "Role Switcher" to jump between these distinct views, plus a **Story Mode** for the presenter.

1. **Beneficiary (Voice Session):** 
   * **UI:** Phone-sized web frame.
   * **UX:** Voice-first. Large touch targets, no text inputs, icons with words. Every screen plays its content aloud.
   * **Data:** Sees only her own options and local evidence reasons.

2. **Local Helper:** 
   * **UI:** Simple mobile view.
   * **UX:** Task lists, session scheduling, and in-person check-in logging.

3. **District Officer (District Console):** 
   * **UI:** Dense, 1440px desktop layout (Map, Ledgers).
   * **UX:** Data-rich. Uses tabular figures, map tiles (5 blocks, 20 clusters), and slide-out evidence drawers showing exact counts and provenance.
   * **Actions:** Reviews interventions, builds the plan, overrides with typed reasons.

4. **Training Provider (Provider Desk):** 
   * **UI:** Desktop ledger.
   * **UX:** Receives cohort specs, confirms capacity, reports completion/outcomes.

## 4. The Livelihood Intelligence Engine (Signals & Verdicts)
The system evaluates 72 Cells (Place × Pathway). For each cell, it calculates a **Verdict** (Likely Room, Uncertain, Likely Crowded) and a **Confidence Level** based on 6 Signals:
* **A. Existing Workers** (Supply vs Peer Median)
* **B. Recent Entrants** (Trained in last 24 months)
* **C. Current Workload** (Median paid days, work turned away - Tie-breaker)
* **D. Past Outcomes** (Verified working vs Not working - Tie-breaker)
* **E. Funded Demand** (Committed work/orders)
* **F. Our Callers** (Who is waiting)

## 5. Data & Trust Requirements
* **100% Simulated Personal Data:** ~600 people are generated synthetically. The only real data allowed are the official Qualification standards (e.g., *Self Employed Tailor AMH/Q1947*).
* **Provenance Labels:** Every single number, chart, or data point on the screen must carry a "Simulated" hatch/tag and a provenance chip (e.g., "Verified", "Self-Reported", "Estimated by rule"). No exceptions.
* **Privacy Controls:** Must include a 3-part spoken consent flow (Recording, Planning use, Follow-up). No caste, religion, address, or surnames are collected.

## 6. The "WOW" Moment (Core Demo Target)
The entire build culminates in this split-screen sequence (Beat 8):
1. The beneficiary confirms her choice on the phone UI.
2. A marigold dot travels from the phone to the District Map.
3. The dot lands on the cluster tile, filling the 20th slot for an RPL camp.
4. The system instantly marks the camp as "Suggested" and dynamically flags a planned 30-seat beginner batch for replacement due to crowding.
