
Livelihood Evidence Loop: Prototype Blueprint
Oct 2, 2026 · @asdvhi;w
This blueprint specifies a one-district prototype in which one voice conversation diagnoses a person, and many conversations change what the district funds. Every number the prototype shows is seeded demo data and is labelled as simulated on screen.
1. Executive summary
Build one web prototype with four role views and a presenter mode, running on a seeded, simulated district. It must show three things in one continuous story.
    1. Diagnose. A 90-second spoken work history becomes quoted evidence against skill units, an RPL pre-screen and a named barrier.
    2. Allocate. Local evidence about a trade in her area re-ranks her options. Her choice then updates the district picture and tips a planned intervention.
    3. Verify. An independent check-in on a past trainee changes the evidence the next recommendation uses.
Decision	What to build
Product name	Livelihood Evidence Loop (matches the SIH idea title)
Scope	One simulated district: 5 blocks, 20 village clusters, 4 sectors, 7 pathways
Two deep features	Skill Evidence with RPL pre-screen; District Livelihood Intelligence that drives allocation
One thin feature	Outcome verification
Primary demo channel	Helper-assisted voice session on a phone-sized screen, scripted and replayable
Role views	Voice Session, Helper, District Console, Provider Desk, plus Story Mode for the presenter
Hero story	Sunita, seven years of tailoring, in a village cluster where tailoring is likely crowded
The moment judges remember	Her call is the 20th RPL-ready tailor nearby. An RPL camp becomes viable and a planned 30-seat beginner batch goes on hold.
Data	Every person-level record is simulated and labelled. Each signal names the real public source it would use.
Out of scope	Telephony, live dialect speech recognition, government system integration, demand forecasting, certification
How to read this document. Sections 2 to 12 define behaviour and rules. Sections 13 to 17 define the interface. Sections 18 to 21 define the data. Sections 22 to 24 define the demo. Sections 25 to 31 cover guardrails and the build plan. A developer short on time should read sections 10, 23 and 29 first.
Words used throughout.
Term	Meaning in this product
Cluster	A group of 4 to 6 neighbouring villages that share a market and a bus route. The unit for local evidence.
Pathway	An occupation in a specific market, plus the support package needed to enter it. Example: tailoring through SHG uniform orders, with RPL and order linkage.
Cell	One cluster (or block) crossed with one pathway. Every verdict belongs to a cell.
Verdict	Likely room, Uncertain, or Likely crowded. Never a number.
RPL pre-screen	The system's view that a person may be ready for a formal Recognition of Prior Learning assessment. It is not certification.
Provenance	The label on every number: official, self-reported, verified or estimated, and whether it is real or simulated.
2. Product thesis
Thesis. We are not building an AI counsellor. We are building the instrument a district uses to decide what to fund. The voice conversation is how that instrument is fed, and good advice is how the person is repaid for feeding it.
Item	Definition
Product name	Livelihood Evidence Loop
Spoken name for beneficiaries	Hunar Line (hunar means skill). This is a config value. Translate it for the district's language.
One-line description	A district livelihood intelligence system: each voice conversation finds what a person can already do and what is blocking them, and many conversations show the district where RPL, training and support should go.
Problem being solved	GIA skilling decides who is trained in what, where and in what numbers without knowing the person, the local market, or what happened to the last batch. Section 3 expands this.
Primary user	The beneficiary: an adult from an SC household, often a woman, with low digital literacy and a shared phone.
Government or customer user	The district implementing officer and the state SC development corporation, who choose trades, approve projects and answer for outcomes.
Training provider user	The centre manager who receives a cohort specification, confirms capacity and reports completion.
Local helper user	An SHG resource person or Common Service Centre operator who sits with the beneficiary and handles follow-ups.
Core differentiator	Every recommendation accounts for everyone else in the area, shows its evidence, and is corrected by independently verified outcomes.
In one paragraph. A beneficiary tells her work story by voice, with a local helper beside her. The system turns the story into evidence against official skill units, names what is actually holding her back, and offers two or three pathways she can choose from. Before ranking those pathways it checks local evidence about each trade in her area: how many people already do it, how many were recently trained, how busy they are, and what happened to earlier trainees. Each conversation also adds to that evidence. District officers see where skills are hidden, where a trade is likely crowded, and where an RPL camp or local batch would work, and they build the plan from it. Independent follow-up calls check outcomes and correct the evidence.
What makes this different from a generic AI voice assistant
Generic voice assistant	Livelihood Evidence Loop
Treats each caller alone	Ranks options using local evidence about each trade in her area
Outputs a course	Outputs a pathway: a market plus a support package, which is often not a course
Skill labels such as "tailor"	Evidence against skill units, with her own words and an evidence level
A hidden "demand score"	Six visible signals and a three-state verdict with a confidence level
Ends at the recommendation	Feeds the district plan, then checks what happened
The AI decides	Rules rank, the person chooses, the officer approves
What the prototype must demonstrate
    1. A spoken work history becomes skill-unit evidence with quotes, and an RPL pre-screen that is clearly not certification.
    2. The diagnosis of what blocks her changes the support package. The answer is not another beginner course.
    3. Local evidence visibly re-ranks her pathways, with signals, sample sizes and an honest "uncertain" state.
    4. Her confirmed choice updates the district picture and tips one intervention over its viability threshold. The officer changes the plan.
    5. One independent outcome check-in updates the evidence for that trade and place.
What the prototype deliberately does not attempt
    • Production speech recognition across dialects. Audio is recorded or synthesised, and transcripts are scripted.
    • Real phone calls or WhatsApp messages. The channel is shown as an assisted session on a phone-sized screen.
    • Integration with any government system. Real sources are named, not connected.
    • Demand forecasting or any exact capacity number.
    • Certifying a skill. RPL assessment stays with authorised bodies.
    • Real beneficiary data. Every person is simulated.
    • Logins, payments, multi-district scale or a full provider information system.
3. Problem definition
The problem is allocation without feedback. The system decides who is trained in what, where and in what numbers, without evidence about the person, the place, or what happened to the last batch.
Where the mismatch happens. It happens at selection, not in the classroom. A trade is chosen because a provider can run it and funds must be spent. People are then recruited to fill the seats.
What the public record shows.
    • The CAG's audit of PMKVY found 56.14 lakh candidates certified across 724 job roles, with about 40% of certifications in only 10 roles, and 41% placed. Source: CAG Report No. 20 of 2025.
    • PM-AJAY's own guidelines already ask for the opposite of seat-filling. Beneficiaries are to be identified after assessing their interest, and job roles need district endorsement for aspiration and job-market fit. Source: PM-AJAY Skill Development Programmes.
Root causes and the prototype's response
Root cause	What it looks like on the ground	What the prototype does
Seats are rewarded, not fit	A mobiliser fills a batch for a course the provider already runs	Pathways are built from the person's evidence and barriers (section 9)
Advice is individual, crowding is collective	Every woman with travel limits is steered to the same home-based trade	A verdict for each trade in each cluster changes the ranking (section 10)
Existing skill is invisible	Seven years of tailoring counts as unskilled without a certificate	Skill evidence and an RPL pre-screen (section 8)
Training is treated as the only fix	A skilled tailor is offered a tailoring course	Barrier diagnosis maps to RPL, capital, market or travel support (section 9)
Constraints are never recorded	Dropout looks random	Travel, time and care limits are captured and used to form local batches (section 11)
Outcomes are claimed by the party being paid	Placement is a one-time figure from the provider	Independent check-ins from a number the beneficiary gave (section 12)
Plans are written top-down	Proposals reach committees with no local evidence	Opportunities and a Plan Builder with an evidence trail (section 11)
Who carries the cost
Group	Their problem
Beneficiary	Loses wages to attend a course she did not need, then finds no work because the trade is crowded
Training provider	Pays heavily to recruit, loses milestone payments when mismatched trainees drop out
District and corporation	Cannot defend why a trade was funded in a place, or show what it achieved
Ministry	Sees training numbers rise while livelihood outcomes stay unverified
The problem statement's own "basic issues", mapped
Issue named in the problem statement	Where the prototype answers it
No roadmap from perspective plan to implementation	Plan Builder: plan lines generated from evidence
Identifying participants and financial consultants	Skill evidence finds who is ready; the enterprise package prepares a basic project proposal
Job placement after skilling	Placement opportunities plus independent outcome checks
Coordination between corporation, ministry and departments	One shared record per person and per plan line
Thin technical and support team on the ground	The Helper view turns one SHG resource person into a counselling point
4. Product architecture
The product is two loops that share one evidence store: a micro loop for one person and a macro loop for the district.
MICRO LOOP  (one person, minutes to months)

  Voice session -> Livelihood profile -> Skill evidence -> Barrier diagnosis
     -> Pathways ranked with local evidence -> Person chooses
     -> RPL / training / enterprise support / placement
     -> Follow-up -> Verified outcome
            |  writes                              ^  reads
            v                                      |
   EVIDENCE STORE: one record per cell (cluster x pathway)
            ^  reads                               |  writes
            |                                      v
MACRO LOOP  (one district, weeks to a year)

  Many conversations -> Signals A to F per cell -> Verdict + confidence
     -> Opportunities (RPL camp, local batch, hold, linkage, enterprise, placement)
     -> Officer builds the plan -> Cohort spec to provider -> Delivery
     -> Verified outcomes -> Signals updated
Layers
#	Layer	Job	Depth in the prototype
1	Beneficiary interaction	Voice in, voice out, consent, confirm-back	Scripted and replayable, one channel
2	Conversation understanding	Turn speech into structured facts, each tied to a quote	Pre-computed for the demo conversations; live extraction is optional
3	Skill evidence	Map tasks to skill units and produce an RPL pre-screen	Deep
4	Diagnosis and pathways	Find barriers, compose pathways, rank them	Deep, rule-based
5	Local livelihood intelligence	Signals, verdict and confidence for each cell	Deep
6	Allocation	Opportunities, local batches, the plan	Deep
7	Outcome verification	Independent check-ins that update the evidence	Thin
8	Trust	Provenance labels, consent, audit log	Thin, but visible on every screen
Layer 1: one demo channel
Decision: a helper-assisted voice session on a phone-sized screen. Do not build IVR or WhatsApp.
    • It needs no telephony or messaging approvals and runs with the network off.
    • It matches how first contact really happens for a low-trust, low-literacy user: someone she knows hands her the phone.
    • It lets Story Mode show the phone beside the evidence it produces.
IVR and WhatsApp appear only as two disabled labels on the Helper start screen, captioned "Same conversation engine. Not in this prototype."
What the beneficiary experiences.
    1. The helper opens a session and picks her language.
    2. She hears who is calling, what it is for, and that nothing she says affects benefits she already gets. She says yes or no to recording.
    3. She is asked about yesterday's work, not given a form.
    4. She hears a short summary of what was understood and corrects it.
    5. She hears which skills were found in her story.
    6. She hears two or three options, each with a reason drawn from local evidence.
    7. She picks one, or asks to be called back after talking at home.
    8. She hears the next step and the date of a follow-up call.
Technical shape: requirements, not a stack
    • Static first. All must-have behaviour runs in the browser from seed files. No server and no login. The demo must work offline.
    • Deterministic. The same seed and the same actions give the same screens. A "Reset demo" control restores the seed state.
    • Rules separate from interface. Seven rule modules compute everything. Each returns a result plus an explanation trace, a list of plain-language reasons. The interface renders the trace and computes nothing itself.
    • Event log. Each demo action appends one event: choice confirmed, opportunity added to plan, check-in recorded. Screen state is the seed plus the events. The audit screen shows the log.
    • Config, not constants. District, block and cluster names, language strings and every threshold live in config files.
    • Optional live layer. One server function may call a language model for live extraction, restricted to the skill catalogue. If it fails, the scripted path runs. This is a should-have.
    • Choosing tools. Any component-based web toolkit is acceptable if it supports client-side routing, SVG, and shared-element transitions. Do not use a UI kit with a default look.
Rule modules
Module	Reads	Returns
Skill evidence	Conversation facts, skill catalogue	Evidence level per skill unit with quotes; RPL pre-screen
Diagnosis	Profile, pathway catalogue, verdicts	Barriers per pathway; primary barrier
Pathways	Profile, barriers, verdicts	Two rankings (person only; person plus place) with reasons
Signals	Cell data	Six signal readings, each with a vote
Verdict	Signal votes	Verdict, confidence, what would change it
Allocation	People, verdicts, travel times, thresholds	Opportunities and candidate groups
Outcomes	Check-ins	Outcome status, updated outcome signal, learning events
5. User roles
Four roles use the product. The prototype switches between them with one control and has no login.
Role	Who they are	What they need	Device	What they are never shown
Beneficiary	An adult from an SC household, with low reading comfort and a shared phone	To be heard, to learn which of her skills count, and to choose among realistic options	The helper's phone	District data, other people's records, any score about herself
Local helper	An SHG resource person, CSC operator or panchayat volunteer	To run a session well and know who needs a follow-up	Own smartphone	People outside their clusters, provider performance
District officer	A district welfare officer or SC corporation manager	To decide what to fund and where, and to defend that decision	Laptop	Raw audio. Names appear as first name and initial.
Training provider	A training centre manager	To receive a cohort that will complete, and to confirm capacity	Laptop	Other providers' data, personal details beyond what delivery needs
What each role contributes to the loop
Role	Diagnose	Allocate	Verify
Beneficiary	Tells her story, confirms what was understood	Chooses a pathway	Answers the follow-up call
Local helper	Sets up the session and protects her privacy	Passes on the next step	Visits when a call cannot reach her
District officer	Reads profiles only when needed	Reviews evidence, builds the plan, sends cohorts	Reads claimed against verified outcomes
Training provider	None	Confirms capacity or proposes changes	Reports completion; sees its verified record
Role switcher
    • A control in the top bar reads "Viewing as" and offers Voice Session, Helper, District Console and Provider Desk.
    • Switching role changes the whole layout, not just the menu. The beneficiary view is a phone frame. The console is a wide desktop layout.
    • The prototype shows role views, not real access control. The Data and Trust screen says so in one line.
    • Story Mode is a presenter overlay that moves through the roles in the order of the demo (section 22).
6. User journeys
Four journeys cover every screen in the prototype. Screen codes (V1, C2 and so on) match the inventory in section 15.
Journey A: beneficiary (Sunita), from first contact to outcome
Step	Screen	Action	System response	Data generated	Next
1	H2 New session	Helper taps "Start a session", picks language, enters first name and cluster	Creates the session and hands the phone view to her	Beneficiary (draft), Session	V1
2	V1 Consent	She hears the consent prompt and says yes	Confirms aloud what was agreed	Consent record: recording yes, purpose guidance and anonymised planning	V2
3	V2 Conversation	She answers eight questions about her work, workload, training history, goals and limits	Speaks each question, shows a live waveform, stores each turn	Transcript turns, extracted facts with quotes, one worker-activity reading for her cell, one household training record	V3
4	V3 Confirm	She hears a four-line summary and taps "Yes, that's right"	Marks the profile as confirmed by her	Profile confirmed flag, any corrections	V4
5	V4 Skills found	She hears five skills found in her story and that she may be ready for a skill test	Plays each skill with an icon	Skill evidence records, RPL pre-screen	V5
6	V5 Options	She hears three options and taps "Why?" on one	Plays the reason from local evidence	Pathway list shown, reasons played	V6
7	V6 Confirm choice	She picks option 1 and confirms	Repeats her choice back	Pathway choice event; district counts update	V7
8	V7 Next step	She hears the next step and a follow-up date	Schedules the follow-up and a helper task	Follow-up, helper task	H3
9	V8 Check-in (30, 90, 180 days later)	She answers four questions about work and earnings	Thanks her, offers help if she reports a problem	Outcome record; outcome signal for her cell updates	C6
Journey B: district officer, from dashboard to intervention
Step	Screen	Action	System response	Data generated	Next
1	C1 Overview	Reads "What changed this week" and clicks "RPL camp in Nadi Paar now has 20 candidates"	Opens the map focused on that block	Audit: view	C2
2	C2 Livelihood Map	Selects the pathway "Own tailoring in the village"	Colours each cluster by verdict	None	C2a
3	C2a Evidence drawer	Clicks the Devgaon cluster	Slides in the six signals, the verdict, the confidence and a recommendation	Audit: evidence viewed	C3
4	C3 Opportunities	Clicks "See opportunities here"	Lists three items for Nadi Paar: an RPL camp, an order group, and a batch on hold	None	C3a
5	C3a Opportunity detail	Reviews candidates, travel and timing; changes the venue; clicks "Add to plan"	Adds a plan line carrying its evidence	Intervention (proposed), plan line	C4
6	C4 Plan Builder	On the held beginner batch, clicks "Replace with RPL camp and order group"	Marks the old line replaced and links the new lines	Plan change event with reason	C4a
7	C4a Cohort spec	Clicks "Send to provider" and picks Provider B	Creates the cohort spec and shows it as sent	Cohort spec, status sent	P1
8	C6 Outcomes (later)	Compares claimed and verified outcomes	Shows the comparison and any verdict that changed	Audit: view	C2
Journey C: training provider, from proposed cohort to outcomes
Step	Screen	Action	System response	Data generated	Next
1	P1 Cohort inbox	Opens the new item "RPL camp: self-employed tailor, 20 candidates"	Shows the cohort spec	Audit: view	P2
2	P2 Cohort detail	Reads venue, timing limits, which skill units to assess, and the evidence summary	Shows candidates as first name and initial with pre-screen status	None	P2
3	P2 Cohort detail	Clicks "Confirm capacity" and enters dates, or clicks "Propose a change"	Updates status to confirmed or change proposed	Provider response	C4
4	P2 Cohort detail (after delivery)	Marks each candidate attended, assessed and result	Stores these as provider-reported	Training records, provider-reported	P3
5	P3 Outcomes record	Views claimed against verified outcomes for own cohorts	Shows the gap; verified values cannot be edited	None	End
Journey D: local helper, from session to follow-up
Step	Screen	Action	System response	Data generated	Next
1	H1 Today	Opens the app	Lists sessions booked and follow-ups due	None	H2
2	H2 New session	Starts a session for Sunita	Shows a privacy tip: find a place where she can speak freely	Session	V1
3	V2 Conversation	Stays beside her; taps "Pause" if someone starts listening	Hides the screen content and stops recording	Pause event	V2
4	H3 Follow-ups	Opens the new task "Tell Sunita the RPL camp date and help with ID proof"	Shows the task with the date once the provider confirms	Task	H4
5	H4 Person card	Marks "Informed"	Closes the task	Task closed	H3
6	H3 Follow-ups	Opens "Asha: two follow-up calls unanswered" and records a visit check-in	Stores the check-in labelled helper-assisted	Outcome record, helper-assisted	H1
7. AI behaviour
The language model does one job: turn speech into structured facts, each tied to the words that support it. Rules do the ranking, the verdicts and the diagnosis.
7.1 Conversation phases
Phase	What happens	Limit
Consent	States who is calling, the purpose, that caste is not asked, and that existing benefits are unaffected. Asks to record.	One prompt, yes or no
Story	"Tell me about your work. What did you do yesterday?"	Open question first
Follow-ups	Asks only what changes the result (order below)	Eight questions at most
Confirm-back	Repeats a four-line summary and asks if it is right	Must be confirmed before saving
Options	Presents two or three pathways with reasons, then asks for a choice or a callback	Never one, never more than three
Order of follow-up questions.
    1. Hard limits not yet known: travel, time, staying away from home.
    2. Core skill units that are not yet evidence-supported and would change the RPL pre-screen.
    3. The worker-activity check, if she already works in a trade: paid days last month, work turned away, whether rates are rising or falling.
    4. Household training history: who trained in what, and whether it led to work.
    5. One open district question that this person can answer.
The session stops asking when no remaining question would change the ranking.
7.2 What is extracted
Every fact is stored as: field, value, supporting quote (turn and character span), basis (stated or inferred), and whether she confirmed it.
Group	Fields
Household livelihood	Income sources (who, activity, months, main or secondary); number of earners; current occupation; previous occupations with years; seasonal migration (months, destination type); household training history (relation, trade, year, whether it led to work)
Skills	Tasks performed (action, object, tools, frequency); years of experience; tools owned; type of customers or employer
Current workload (only if already in a trade)	Paid days last month; work turned away; typical rate band; rates rising, stable or falling
Constraints	Maximum one-way travel in minutes; travel mode; must be home by; days available; care duties; can stay overnight; willing to migrate; can work outside the home; busy months; minimum monthly income; weeks she can go without earning
Goals	Wage, self-employment or either; what she wants to change (certificate, income, stability, staying near home); trades she is interested in; family occupation and her stance on it (continue, modernise, leave), only if she raises it
Existing support	Certificates; training completed; SHG membership and years; bank account; existing loans; schemes she mentions; documents ready
Never asked and never stored: caste or sub-caste, religion, political views. Eligibility comes from the scheme's own beneficiary list, not from the conversation.
7.3 Guardrails
    • Closed vocabulary. A task can only be mapped to a skill unit in the catalogue. Anything else is stored as "unmapped" and shown that way.
    • Quote anchoring. No fact exists without a supporting quote. Every screen can show where a fact came from.
    • Unknown is allowed. A missing fact stays blank or triggers a follow-up. It is never filled by guesswork.
    • No model decisions. The model never ranks pathways, sets a verdict or names the barrier.
    • Family occupation is optional. If she mentions it, the system asks whether she wants to continue, modernise or leave it. It affects ranking only when she says continue or modernise.
    • Caste-linked terms. If a caste-linked occupational term is spoken, the task is stored in neutral words and the term is never spoken back.
    • Plain speech. Spoken sentences stay under 15 words. No promises of a job or a benefit.
    • Confirm before saving. Nothing is marked confirmed until she agrees with the summary.
7.4 Scripted and live modes
Mode	Behaviour	Priority
Scripted	Three conversations stored as turns. Each turn has an audio file, text in the local script, an English line, and the facts it reveals. Evidence appears turn by turn. Controls: play, pause, next turn, 1.5x speed.	Must have
Live sentence	A judge types or speaks one extra sentence. A server function returns catalogue unit IDs and quote spans only. Results are tagged "live, unreviewed" and never change seeded counts.	Should have
Record each turn in the district's language. Show the original script with the English line beneath it. The English renderings follow.
7.5 Demo conversation C-01: Sunita, Devgaon cluster
Turn	Speaker	Line
A1	Agent	Namaste. This is the Hunar Line. I will ask about your work so we can find the right support for you. I will not ask about caste. Nothing you say changes any benefit you get today. May I record this to understand you better?
B1	Sunita	Yes.
A2	Agent	Thank you. Tell me about your work. What did you do yesterday?
B2	Sunita	I finished two blouses for a wedding. I have been stitching blouses and suits for people in my village for seven years.
A3	Agent	When a customer comes, how do you begin?
B3	Sunita	I take her measurements with the tape and write them in my notebook. Then I cut the cloth from my own paper patterns.
A4	Agent	Do you also alter or repair clothes?
B4	Sunita	Every week. Fitting, shortening, changing zips. Hemming and hooks I do by hand. I don't have a buttonhole machine.
A5	Agent	What do you do when the machine gives trouble?
B5	Sunita	I oil it myself. For anything else the mechanic comes from town.
A6	Agent	Last month, on how many days did you get paid work? Did you turn any work away?
B6	Sunita	Eight or nine days. I didn't refuse anyone. There are many tailors here now and the rates have come down.
A7	Agent	Has anyone at home done a training course?
B7	Sunita	My sister-in-law did a tailoring course last year. She got a certificate but very little work.
A8	Agent	What should your work look like a year from now? And what limits should I know about?
B8	Sunita	A regular five or six thousand a month. I want to stay near home. I can go as far as the block town, but I must be back by four when the children return.
A9	Agent	Do you have a certificate for tailoring? Are you in a self-help group?
B9	Sunita	No certificate. I have been in the SHG for three years.
A10	Agent	Let me check. You have stitched blouses and suits for seven years. You measure, cut, stitch and alter. You have no certificate. You want regular income near home and must be back by four. Is that right?
B10	Sunita	Yes, that's right.

Result	C-01 Sunita
Extracted	Seven years of custom tailoring for village customers; owns a sewing machine; eight to nine paid days last month; no work turned away; rates falling; SHG member for three years; no certificate; wants steady income near home; can travel to the block town; must be home by 4 pm; a relative trained in tailoring last year with little work since
Skill evidence	5 of 7 core units evidence-supported; finishing self-reported; machine upkeep not evidenced
RPL pre-screen	Likely ready for assessment (self-employed tailor)
Barriers	Certification (blocking); market access (blocking); mobility and time (partial); skill (none)
Ranking on the person alone	1. Own tailoring in the village. 2. Uniform-order group. 3. Garment-unit job.
Local evidence	Own tailoring in Devgaon: likely crowded, medium confidence. Uniform orders in Nadi Paar: likely room, medium confidence. Garment-unit jobs in Sadar: likely room, medium confidence.
Ranking with place	1. RPL plus the uniform-order group. 2. RPL plus a garment-unit job (conflicts with being home by four). 3. Own tailoring (likely crowded).
Her choice	Option 1
Resulting intervention	RPL camp at Devgaon reaches 20 candidates; uniform-order group linkage; the planned 30-seat beginner tailoring batch is replaced
7.6 Demo conversation C-02: Raju, Khairwa cluster
Turn	Speaker	Line
A1	Agent	(Same consent prompt as C-01.)
B1	Raju	Yes.
A2	Agent	Tell me about your work last month.
B2	Raju	Building work. I started as a helper five years ago. Now I do most of the wall work myself, brick walls and plaster.
A3	Agent	How do you prepare the mortar?
B3	Raju	For walls, one cement to six sand. For plaster, one to four. I mix it myself and check that it holds on the trowel.
A4	Agent	Who sets out the building: the lines, levels and corners?
B4	Raju	The head mason does that from the drawing. I can't read the drawing. I use the plumb line and the level when he shows me.
A5	Agent	Have you fixed door or window frames, or laid floors?
B5	Raju	Floors I have done many times. Frames I have only helped with.
A6	Agent	On how many days did you work last month? Did you turn work away?
B6	Raju	Twenty-two days. Two families asked me to build for them. I said no because the contractor needed me.
A7	Agent	Do you go away for work?
B7	Raju	Four months every year, to the city, on building sites. This year I want to stay. My father is unwell.
A8	Agent	Houses have been approved for building in your panchayat this year. Did you know?
B8	Raju	I heard something. I don't know who gives that work.
A9	Agent	Do you have a certificate? A bank account?
B9	Raju	No certificate. I have an account.
A10	Agent	Let me check. Five years in building work. You build walls and plaster, and mix mortar yourself. You cannot yet read drawings. You want to stay near home this year. Is that right?
B10	Raju	Yes.

Result	C-02 Raju
Extracted	Five years in construction; 22 paid days last month; turned away two jobs; migrates four months a year and wants to stop; father unwell; unaware of who assigns local housing work; no certificate; has a bank account
Skill evidence	3 of 7 core units evidence-supported (mortar, walls, plaster); flooring and frames self-reported; setting out from drawings and scaffolding not evidenced
RPL pre-screen	Partly ready: bridge module first (reading drawings and setting out)
Barriers	Certification (blocking); skill (partial); information (partial); placement link (partial)
Local evidence	Masonry in Khairwa: likely room, medium confidence. Solar installation in Pahadi: uncertain, low confidence.
Ranking with place	1. RPL camp with a two-week bridge, linked to housing works in his panchayat. 2. Solar installer trial batch. 3. Stay with the contractor.
His choice	Option 1
Resulting intervention	RPL-with-bridge camp for masons in Pahadi: 23 candidates
7.7 Demo conversation C-03: Manoj, Tikri cluster
Turn	Speaker	Line
A1	Agent	(Same consent prompt as C-01.)
B1	Manoj	Yes.
A2	Agent	Tell me about your work.
B2	Manoj	I worked four years at a motorcycle garage in the block town. Servicing, oil change, chain and cables, brake shoes, clutch plates.
A3	Agent	Can you open an engine?
B3	Manoj	Yes. Tappet setting with the feeler gauge, carburettor cleaning, spark plug. I use the torque wrench for the head. The new fuel-injection bikes I have not done much.
A4	Agent	And electrical faults?
B4	Manoj	Battery and bulbs I do. Wiring faults I send to the electrician.
A5	Agent	What do you want to do next?
B5	Manoj	My own repair shop on the highway near my village. There are only two shops on that stretch. People push their bikes to town.
A6	Agent	What is stopping you?
B6	Manoj	Tools, a compressor and a shed. Sixty or seventy thousand rupees. I have saved ten thousand. The bank asked for a guarantor.
A7	Agent	Is anyone at home in a self-help group? Do you have a certificate?
B7	Manoj	My wife is in the SHG. No certificate. I left the garage in March and do small repair jobs at home.
A8	Agent	How many paid days last month?
B8	Manoj	Ten or twelve. Small jobs.
A9	Agent	Let me check. Four years as a motorcycle mechanic. You service, repair brakes and clutch, and open engines. You want your own shop and need tools and money. Is that right?
B9	Manoj	Yes.

Result	C-03 Manoj
Extracted	Four years as a two-wheeler mechanic; 10 to 12 paid days last month from home repairs; wants his own shop; needs about Rs 60,000 to 70,000 by his own estimate; has Rs 10,000 saved; bank asked for a guarantor; wife is an SHG member; no certificate
Skill evidence	5 of 6 core units evidence-supported; electrical diagnosis self-reported
RPL pre-screen	Likely ready for assessment (two-wheeler service technician)
Barriers	Capital (blocking); information about credit routes (partial); market access (partial, because local evidence is thin); certification (partial); skill (none)
Local evidence	Own repair shop in Tikri: uncertain, low confidence. Mechanic jobs at service centres in Sadar: likely room, medium confidence.
Ranking with place	1. RPL plus a mechanic job in Sadar. 2. Own shop with an enterprise package, as a trial. 3. Continue home repairs while saving.
His choice	Option 2. He chooses against the ranking, and the system supports it as a trial.
Resulting intervention	Enterprise support trial in Nahar: a short entrepreneurship course, a basic project proposal, credit linkage and toolkit support for two shops first, checked after three months
8. Skill evidence engine
The skill evidence engine turns her words into evidence against official skill standards and stops at a pre-screen. It never certifies anyone.
8.1 The chain from words to pre-screen
Step	What it is	Sunita's example	Produced by
1. Words	A quote, with its turn and character span	B3: "I take her measurements with the tape and write them in my notebook."	Transcript
2. Task	Action, object, tools, frequency	Takes body measurements; tape and notebook; every order	Language model, then her confirmation at V3
3. Skill unit	A plain-language unit from the closed catalogue	T1 Take and record measurements	Catalogue lookup
4. National Occupational Standard	The official standard the unit sits under	AMH/N1947 Drafting and Cutting the Fabric	Catalogue, real
5. Qualification	The national qualification	Self Employed Tailor, AMH/Q1947	Catalogue, real
6. NSQF level	The level listed for the version loaded	Level 3 in version 3.0	Catalogue, real
7. RPL pre-screen	A band, with the count behind it	Likely ready: 5 of 7 core units evidence-supported	Rule
Steps 1 to 3 are about her. Steps 4 to 6 are reference data. Step 7 is the only judgement, and a rule makes it.
8.2 Evidence levels
Every skill unit carries one of five levels. The interface must never blur them.
Level	Name	Mark	Meaning	Set when	Who can set it
0	Not evidenced	?	Nothing usable was said, or she said someone else does it	Default, or she claims fewer than half of the unit's main tasks	Rule
1	Self-reported	△	She says she does it, without detail or with a stated limit	She claims at least half the main tasks, but gives fewer than two specifics or names a limit on a main task	Rule
2	Evidence-supported	✓	She describes how she does it, in enough detail to be plausible	She claims at least half the main tasks, gives two or more specifics, and names no limit on a main task	Rule
3	Corroborated	✓ with a second tick	Something besides her words supports it	A photo of finished work, a customer's word, or the helper has seen it	Helper. Nice-to-have.
4	Assessed	Seal	An authorised assessor has tested it in person	An assessment result is recorded after an RPL camp	Assessment record only. Never the system.
What counts as a specific. A named tool, material or part. Steps given in order. A measure, quantity or frequency. A named product or operation. A problem and how she fixed it. A named workplace or type of customer. The language model tags specifics and a rule counts them.
What never counts. Years of experience alone never lift a unit above self-reported. An occupation label such as "tailor" fills no unit. A family occupation is never evidence.
8.3 The catalogue
The catalogue has two layers: real qualifications and standards from the national register, and our own plain-language skill units under them.
Pathways served	Qualification	Code	Level and version read	Source
Own tailoring; uniform orders	Self Employed Tailor	AMH/Q1947	Version 3.0: NSQF Level 3, 420 hours, RPL allowed. Version 2.0 listed Level 4.	Qualification file, pack v2.0
Rural mason	Rural Mason	CON/Q3603	Version 2.0: NSQF Level 4	Qualification pack
Own repair shop; mechanic job	Two Wheeler Service Technician	ASC/Q1411, read from the variant pack PWD/ASC/Q1411	NSQF Level 4	Register entry, variant pack
These were read on 2 October 2026. Several show review dates that have passed, so confirm the current version on the register before the demo. The sewing machine operator and solar installer qualifications were not read for this blueprint. Copy their titles, codes, levels and standards from the register, and show nothing for them until that is done.
The skill units are ours. They are a plain-language breakdown written for the demo, not official performance criteria. The screen labels them "Demo units mapped to national standards". A production version would use each standard's own performance criteria.
Tailor units
Unit	Plain name	Main tasks	Sits under	Core
T1	Take and record measurements	Take body measurements; record them	AMH/N1947 Drafting and Cutting the Fabric	Yes
T2	Draft or adapt a pattern	Make or adapt a pattern; mark the cloth	AMH/N1947	Yes
T3	Cut fabric	Lay the cloth; cut to the pattern	AMH/N1947	Yes
T4	Stitch garments on a machine	Stitch parts; assemble a full garment	AMH/N1948 Carry out the process of sewing	Yes
T5	Alter and repair for fit	Adjust fit; shorten or lengthen; replace zips and fastenings	AMH/N1949 Carry out inspections and alterations	Yes
T6	Finish garments	Hem; attach hooks, buttons and buttonholes; press	AMH/N1948	Yes
T7	Maintain machine and work area	Clean and oil; change needle and set tension; fix common faults	AMH/N0102 Maintain work area, tools and machines	Yes
T8	Deal with customers and price work	Take orders; quote a price; keep delivery dates	No direct standard	No
T9	Work safely	Handle scissors, needles and iron safely	AMH/N1950 Maintain health, safety, security in tailoring shop	No
Mason units
Unit	Plain name	Main tasks	Sits under	Core
M1	Set out from a drawing	Read a simple drawing; mark lines, levels and corners	CON/N3601 Mark layout for foundation, walls	Yes
M2	Prepare mortar and concrete	Measure the mix; mix to the right consistency	CON/N3602 and CON/N3607 Carry out manual concreting	Yes
M3	Build brick or block walls	Lay courses to line; keep the wall plumb and level	CON/N3602 Build brick / block masonry structures	Yes
M4	Plaster walls	Prepare the surface; apply and finish plaster	CON/N3602, provisional	Yes
M5	Lay floors	Prepare the base; lay and level the floor	CON/N3604 Carry out IPS flooring	Yes
M6	Erect and use scaffolding	Erect a simple scaffold; check it before use	Provisional. Staging appears in the helper-level standard CON/N3609.	Yes
M7	Fix frames and cast lintels	Set door and window frames; cast a lintel	CON/N3605 and CON/N3606, provisional	Yes
M8	Work safely at height	Use a helmet and safe access	No direct standard read	No
M9	Estimate materials	Work out bricks, cement and sand for a wall	No direct standard read	No
Two-wheeler units
Unit	Plain name	Main tasks	Sits under	Core
W1	Routine servicing	Change oil and filter; adjust chain, cables and controls	ASC/N1420 Perform routine servicing and minor repairs	Yes
W2	Brakes and wheels	Replace brake shoes or pads; adjust brakes	ASC/N1420	Yes
W3	Clutch and transmission	Replace clutch plates; set chain and sprockets	ASC/N1420, provisional	Yes
W4	Engine service	Set tappets; clean the carburettor; change the spark plug	ASC/N1420, provisional	Yes
W5	Diagnose electrical faults	Check battery, bulbs and fuses; trace wiring faults	ASC/N1420, provisional	Yes
W6	Use tools and measuring instruments	Choose the right tool; measure with a gauge; tighten to torque	ASC/N9801 Organize work and resources (Service)	Yes
W7	Deal with customers and job cards	Note the complaint; explain the work and cost	ASC/N9802 Interact effectively with colleagues, customers and others	No
W8	Work safely and handle waste oil	Use stands safely; store and dispose of used oil	ASC/N9801	No
"Provisional" means we placed the unit under that standard from its title alone. Check the standard's performance criteria before treating the mapping as settled.
Each catalogue record holds: unit ID, plain name in English and the local language, main tasks, example phrases, the standard's code and title, the qualification, a core flag, a mapping status, the source link with the date read, and one line on what an assessor would look for.
8.4 Seeded evidence for the three demo conversations
Sunita's table is the hero screen. Seed it exactly.
Unit	Mark	Supporting quote	Specifics counted	Note
T1 Take and record measurements	✓	B3: "I take her measurements with the tape and write them in my notebook."	Tape; notebook	Both main tasks described
T2 Draft or adapt a pattern	✓	B3: "from my own paper patterns"	Paper patterns; steps in order	Marking the cloth not mentioned
T3 Cut fabric	✓	B3: "Then I cut the cloth from my own paper patterns."	Paper patterns; steps in order	
T4 Stitch garments on a machine	✓	B2: "I finished two blouses for a wedding."	Two blouses; blouses and suits; village customers	Seven years stated, not counted
T5 Alter and repair for fit	✓	B4: "Every week. Fitting, shortening, changing zips."	Weekly; three operations named	All three main tasks
T6 Finish garments	△	B4: "Hemming and hooks I do by hand. I don't have a buttonhole machine."	By hand; operations named	Stated limit on a main task: buttonholes
T7 Maintain machine and work area	?	B5: "I oil it myself. For anything else the mechanic comes from town."	None counted	One of three main tasks; she says someone else does the rest

Person	✓ Evidence-supported	△ Self-reported	? Not evidenced	Count
Raju	M2 mortar (B3: "one cement to six sand"); M3 walls (B2, B4); M4 plaster (B2, B3: "one to four")	M5 floors (B5: "many times", frequency only); M7 frames (B5: "only helped with", stated limit)	M1 setting out (B4: "I can't read the drawing"); M6 scaffolding (nothing said)	3 of 7
Manoj	W1 servicing (B2); W2 brakes (B2: "brake shoes"); W3 clutch (B2: "clutch plates"); W4 engine (B3: "tappet setting with the feeler gauge"); W6 tools (B3: feeler gauge, torque wrench)	W5 electrical (B4: "Wiring faults I send to the electrician", stated limit)	None	5 of 6
Manoj also says he has done little on fuel-injection bikes. That lies outside W4's main tasks, so it is stored as a note and shown under "What an assessor would check".
8.5 The RPL pre-screen
The pre-screen is a band with a count behind it, and it is never a score.
Band	Rule (seed thresholds, held in config)	What it leads to	Spoken to her as
Likely ready	At least 70% of core units evidence-supported, and no more than two core units not evidenced	RPL assessment	"You may be ready for a skill test."
Partly ready	40% to 69% of core units evidence-supported	A bridge module on the missing units, then assessment	"You know much of this. A short top-up, then a test."
Not yet	Under 40%	A course, if she wants this pathway	"This would mean learning from the start."
    • Sunita: 5 of 7, likely ready. Raju: 3 of 7, partly ready. Manoj: 5 of 6, likely ready.
    • Show the count ("5 of 7 core units"). Never show a percentage, a score or a progress ring.
    • Entry route check (should-have). The qualification file lists entry routes. Version 3.0 of Self Employed Tailor includes "Ability to read and write with 5 years of experience". Show "Meets one listed entry route, by her own account" for Sunita.
    • The fixed banner on every pre-screen reads: "Pre-screen only. A certificate needs a practical test by an authorised assessor."
8.6 The skill evidence screen
The screen shows her words on the left, the units they support in the middle, and what follows on the right. It appears as the "Skill evidence" tab of the person profile (C5a) and as the right-hand pane of Story Mode.
Column	Width	Contents
Transcript	About 40%	Turns in order with speaker labels. Supporting quotes carry a marigold underline. A toggle switches between the original script and English.
Skill units	About 35%	Units grouped under their standard. Each row has the mark, the plain name and the level in words. A legend for the marks stays visible.
Pre-screen	About 25%	Band and count. Units below level 2 listed as "What an assessor would check". Entry route line. Qualification title, code, version and source link, with a "Real source" chip. The fixed banner.
Behaviour.
    • Clicking a unit scrolls the transcript to its quotes and highlights them. Clicking a quote highlights the units it supports.
    • In Story Mode the units start as "?" and change as each turn plays. The count rises one unit at a time.
    • Units with nothing said show a suggested follow-up question, taken from the catalogue.
    • Tasks that match no unit are listed under "Mentioned, not in the catalogue". They are never forced into a unit.
    • A fact she corrected at V3 shows a small "Corrected by her" tag, and the evidence is recomputed.
    • The officer sees transcript text only. Audio plays only in the Voice Session and Story Mode.
States. No conversation yet: "No session recorded. Start one from the Helper view." In progress: units fill as turns arrive. Complete and confirmed by her. Complete but not yet confirmed: the pre-screen is hidden until she confirms.
What she hears (V4). "From your story I found five things you already do that the tailoring test checks: measuring, patterns, cutting, stitching and alterations. Two were not clear: buttonholes, and looking after the machine. You may be ready for a skill test. An examiner does the test in person. I cannot give a certificate."
8.7 After the pre-screen
    • Each person's band feeds the district counts in signal F and can trigger an RPL camp (section 11).
    • After a camp, the provider records each candidate's result at P2. Only then does a unit reach level 4. In the prototype this is labelled "Assessment result, entered by provider".
    • Should-have: compare pre-screen bands with assessed results on the Outcomes screen, as one line. That line tells the district whether the pre-screen can be trusted.
9. Constraint diagnosis
Diagnosis is a rule table that reads named facts. Each barrier it finds adds a named support to the pathway, so the diagnosis changes what she is offered.
9.1 How it works
    • The language model is not involved. It only supplied the facts.
    • There are seven barrier types. Each gets a status of none, partial or blocking, and a "because" line that cites a fact and its quote.
    • "Her pathway" means the pathway she is in now, or the one she says she wants. If she has neither, it is the pathway ranked first.
    • Skill and certification are judged on the trade of her pathway. Capital, market access and placement link are judged on her pathway. Mobility and time, and information, are judged on the person.
    • The primary barrier is every barrier marked blocking. The screen states it as one sentence.
9.2 The rule table
Barrier	Facts read	Blocking when	Partial when	Support it adds
Skill	Evidence levels for the trade's core units	The pre-screen band is "not yet"	The band is "partly ready"	Blocking: a course. Partial: a bridge module on the missing units only.
Certification	Certificates held; whether a pathway in her trade asks for one	She has none, and a pathway in her trade that is not likely crowded asks for one	She has none, and a certificate only helps on those pathways	RPL assessment if likely ready. Bridge then assessment if partly ready.
Capital	The pathway's start-up cost band; her savings; a confirmed credit route	The cost band is above her savings and she has no confirmed credit route	She has an asset gap and a confirmed credit route	Entrepreneurship course, a basic project proposal, credit or asset linkage
Market access	Own-work and order pathways only: paid days last month, work turned away, the cell's verdict	She already works in it at 10 or fewer paid days and turned no work away; or she would be a new entrant to a likely crowded cell	The cell is uncertain	Order or customer linkage, or a related pathway with room
Mobility and time	One-way travel limit, home-by time, days free, overnight stay	Her limits rule out every candidate pathway except home-based work	Her limits rule out at least one candidate pathway	A camp or batch inside her limit, a timing window, travel support
Information	Things she said she did not know	A missing fact is the only thing in her way	A missing fact sits alongside other barriers	Told in the call, a helper task, a referral
Placement link	Wage pathways only: employer contact, stated openings	Openings exist, she has no employer contact and no current work in the trade	She works in the trade but has no link to the stated openings	Employer introduction or a placement drive
A confirmed credit route means a loan approved or in progress, or her own SHG membership with an active loan cycle. A spouse's membership does not count until someone confirms it.
9.3 The pathway catalogue
A pathway is an occupation in a specific market. The diagnosis reads these attributes. They are seed assumptions, so check each with the district before a pilot.
Pathway	ID	Type	Market and cell	Certificate	Start-up cost band	First income
Own tailoring in the village	APP-TAILOR-SE	Own work	Cluster	Not asked for	Low if she owns a machine	At once
Uniform and alteration orders through an SHG group	APP-UNIFORM-GRP	Group orders	Block	Asked for by the buyer	None	4 to 8 weeks
Sewing machine operator job at a garment unit	APP-SMO-WAGE	Wage	District town	Helps	None	2 to 6 weeks if experienced
Rural mason on housing works	CON-MASON	Wage or small contracts	Cluster, with funded works read at block level	Asked for on funded works	Low: hand tools	2 to 6 weeks
Rooftop solar installer	SOL-INSTALLER	Wage	Block	Asked for	None	Not known
Own two-wheeler repair shop	AUTO-2W-SHOP	Own work	Cluster, as a road stretch	Helps with credit	High	8 to 12 weeks
Mechanic job at a service centre	AUTO-2W-WAGE	Wage	District town	Helps	None	2 to 6 weeks
Cost bands are words, not rupee figures. The only rupee figure shown is the one the person states, labelled as her own estimate.
9.4 From barriers to a support package
Each option she is shown gets its own barrier check, and its package is the set of supports those barriers call for.
Option shown to Sunita	Barriers on this option	Package
Uniform orders through the SHG group	Certification blocking; time partial	RPL assessment at a camp inside her travel limit, between 10 am and 3 pm; then group linkage. No course.
Garment-unit job in the district town	Certification partial; placement link partial; conflicts with being home by four	RPL assessment; employer introduction. The conflict is stated, not hidden.
Own tailoring in the village	Market access blocking	None that would help. The cell is likely crowded, and she is told so.
Hard rule. If skill is "none" on a pathway, the package cannot contain a beginner course. The Plan Builder flags any plan line that would enrol such a person in one.
9.5 Ranking the options
Options are ordered by five keys in turn, with no weights and no score.
    1. Local verdict: likely room, then uncertain, then likely crowded.
    2. Fit with her hard limits: options that fit, then options that conflict.
    3. Skill fit: more core units evidence-supported first.
    4. Time to first income: shorter first.
    5. Goal match: own work or wage, near home or not.
The "person only" ranking uses keys 2 to 5. The "with place" ranking uses all five. The interface can show both, and the WOW moment is the switch between them (section 23).
Sunita's options	Person only	With place	Why it moved
Own tailoring in the village	1st: fits her limits and pays at once	3rd	Key 1: likely crowded in Devgaon
Uniform orders through the SHG group	2nd: fits her limits, 4 to 8 weeks	1st	Key 1: likely room in Nadi Paar
Garment-unit job	3rd: conflicts with being home by four	2nd	Key 1: likely room. Key 2 keeps it below uniform orders.
Rules for the list.
    • Show two or three options, never one and never more than three.
    • When only two pathways qualify, the third slot is "carry on as now", described honestly.
    • "Decide later, call me back" is always available.
    • Her stated preference always appears, tagged "Your preference", even when it ranks last.
    • A likely crowded pathway is never hidden and never blocked. She can still choose it.
    • If she chooses against the ranking, the system supports it as a trial and schedules an earlier check-in. Manoj does this.
9.6 Five personas
These five are hand-written seed records. Three have full conversations (section 7).
Persona	Evidence	Barriers found	A course-first system would offer	This system offers
Sunita, 32, Devgaon	Seven years of custom tailoring. 5 of 7 core units. No certificate. 8 to 9 paid days last month. Home by four.	Certification and market access blocking. Time partial. Skill none.	A beginner tailoring course	RPL assessment, then the uniform-order group. No course.
Raju, 27, Khairwa	Five years on building sites. 3 of 7 core units. 22 paid days. Migrates four months a year. Does not know who assigns housing work.	Certification blocking. Skill, information and placement link partial.	A mason course from the start, at the district centre	A two-week bridge on drawings and setting out, RPL assessment, and a link to housing works in his panchayat
Manoj, 29, Tikri	Four years as a mechanic. 5 of 6 core units. Wants his own shop. About Rs 60,000 to 70,000 short by his own estimate. Bank asked for a guarantor.	Capital blocking. Information, market access and certification partial. Skill none.	A two-wheeler repair course	An enterprise package as a trial: entrepreneurship course, basic project proposal, credit linkage, toolkit support. Checked after three months.
Kavita, 21, Lalpur	Class 12. No work experience. Wants a salaried job. Can travel 45 minutes.	Skill blocking.	A course	A sewing machine operator course in the district town, where the evidence shows likely room, then a placement drive. Here training is the barrier, so training is the answer.
Asha, 40, Devgaon	Finished a tailoring course eight months ago and holds the certificate. 5 paid days last month. The provider recorded her as self-employed.	Market access blocking. Skill and certification none.	An advanced tailoring course	The uniform-order group. No more training. Her check-in also corrects the outcome record (section 12).
PM-AJAY's skill guidelines allow 32 to 80 hours for up-skilling or RPL and 80 hours over 10 days for entrepreneurship development. The bridge and the enterprise course above fit inside those limits.
9.7 The "Barriers and pathways" tab
This is the third tab of the person profile (C5a), and Story Mode shows the same component.
    • Summary sentence. Generated from the rules: "Primary barrier: certification and customer access. Not skill."
    • Barrier strip. Seven items in a fixed order. Blocking is a filled marker, partial is half-filled, none is an outline. Each shows its "because" line, linked to the quote.
    • Options. One card per option. It shows the pathway name, the verdict and confidence, any conflict with her limits, the package as a short row of steps, and the time to first income.
    • Tags. "No course needed" when skill is none. "Your preference" on the pathway she named. "Chosen" after V6.
    • Ranking switch. "Rank with local evidence", on by default. Turning it off shows the person-only order.
    • Why this order. An expandable list of the rule steps that produced the ranking, in plain sentences.
Empty state: "No barriers computed yet. The profile needs her confirmation first."
10. Local livelihood intelligence engine
For every place and pathway, the engine shows six visible signals and reaches one of three verdicts by counting votes. It never produces a demand number or a score.
10.1 The cell
A cell is one place crossed with one pathway, and the pathway's market sets the size of the place.
Market	Cell	Pathways	Supply is compared with
Village customers and local sites	Cluster	Own tailoring; own two-wheeler shop; rural mason	The median of the district's other clusters of the same type, rural or peri-urban
Block-level buyers	Block	Uniform orders; rooftop solar	The median of the other blocks
District-town employers	The district town, Sadar	Garment-unit job; mechanic job	Nothing. Supply is not read for wage jobs.
    • The seed district has 72 cells: 60 cluster cells, 10 block cells and 2 district-town cells.
    • On the cluster map, a block-level pathway colours every cluster in its block alike and outlines the block.
    • For rural masons, funded work (signal E) is read at block level and shown with the share near the cluster.
10.2 The six signals
Signal	Question it answers	What is measured	Reading (seed thresholds, held in config)	Real source it stands in for
A. Existing workers and businesses	How many already do this here?	Workers or businesses per 1,000 households, against the peer median	High at 1.5 times the median or more. Low at two-thirds of it or less. Otherwise typical.	A village listing by helpers or the SHG federation; enterprise and worker registrations where they exist at this level
B. Recent entrants	How many were added lately?	People trained or newly started in the last 24 months, as a share of existing workers	High at 30% or more. Low at 10% or less.	Training records from this and other schemes, by trainee address
C. Current workload	Are those already doing it busy?	Median paid days last month; share who turned work away; whether rates are rising or falling	Slack: median 10 days or fewer, and 10% or fewer turned work away. Tight: median 18 days or more, or 30% or more turned work away. Needs 5 people asked within 90 days.	This system's own conversations: the worker-activity check
D. Past outcomes	What happened to those who entered before?	Of past trainees reached, the share now working in the pathway on 10 or more paid days a month	Weak at 35% or less. Strong at 60% or more. Needs 8 people reached.	This system's independent check-ins (section 12)
E. Funded or stated demand	Is paid work already committed?	A funded programme of work, or openings stated by named employers, for this place and period	Present, or none found. "None found" is not a vote.	Housing sanction lists; institutional orders; openings stated by named employers; district credit and skill plans
F. What our callers have and want	Who is waiting, and with what skills?	Counts from conversations: skilled people, RPL bands, people wanting to enter, travel limits	No reading and no vote. Shown as context and passed to allocation.	This system
Rate direction is shown beside signal C and does not change its reading.
Signal	Known weakness, shown in the drawer's help text
A	Registrations miss home-based work. A market village serves customers from outside.
B	Trained people may work elsewhere, or not at all.
C	Self-reported and seasonal.
D	Some people cannot be reached. Numbers are small.
E	A sanction is not yet work. A stated opening is an intention.
F	It only covers people who have called.
10.3 From readings to a verdict
Four kinds of evidence can vote. A and B share one vote because both come from supply records.
Kind of evidence	Votes crowded when	Votes room when
Supply (A and B)	A is high; or A is typical and B is high	A is low and B is not high
Workload (C)	Slack	Tight
Outcomes (D)	Weak	Strong
Demand (E)	Never	Present

Verdict	Rule
Likely crowded	Two or more kinds vote crowded, and none of workload, outcomes or demand votes room
Likely room	Two or more kinds vote room, and neither workload nor outcomes votes crowded
Uncertain: not enough evidence	Fewer than two kinds have a reading
Uncertain: evidence is mixed	Everything else

Confidence	Rule
High	Three or more kinds have a reading, and workload or outcomes rests on 20 or more people
Medium	Two or more kinds have a reading, and workload or outcomes rests on 10 or more people, or demand is backed by a named document or named employers
Low	Everything else
Further rules.
    • Few existing workers is not demand. It can mean nobody is buying. That is why supply alone never gives a verdict.
    • Freshness. A workload reading older than 90 days, or outcomes older than 12 months, is shown as stale and does not vote.
    • Block fallback. If a cluster has fewer than 8 outcomes, signal D uses the block's outcomes for that pathway when 20 or more people were reached there. The drawer says "Block-level evidence" and confidence cannot exceed medium.
    • What would change this. The module names the nearest threshold in a sentence, for example "One more verified check-in would raise confidence to high."
    • No hidden score. The module must not compute a composite index, even internally. It returns readings, votes, a verdict, a confidence and a list of plain sentences.
10.4 What a verdict does
Verdict	In her ranking	In allocation	Said to her
Likely room	First tier	Camps and batches can go ahead at normal size, with outcome checks	"People doing this near you are busy, and there is paid work coming."
Uncertain	Second tier	A trial of 12 seats or fewer, checked at 90 days before any second batch	"We do not know yet. A small first group will show."
Likely crowded	Last tier, never hidden	No new beginner batch. Prefer RPL, order linkage or a related pathway. The officer can override with a reason.	"Many people near you already do this, and they are getting few days of work."
10.5 Seeded hero cells
Every value below is simulated. Seed these exactly, because the demo depends on them.
Cell	A. Existing	B. Recent	C. Workload	D. Outcomes	E. Demand	Verdict and confidence
Devgaon, own tailoring	84 tailors in 1,860 households: 45 per 1,000 against 27. High.	27 trained in 24 months, 32%. High.	16 asked, median 9 days, 1 turned work away, rates falling. Slack.	22 due, 19 reached, 6 working. Weak.	None found	Likely crowded, medium
Nadi Paar, uniform orders	2 groups against a median of 3. Low.	No new group in 24 months. Low.	7 asked, median 19 days in season, 3 turned work away. Tight.	No reading	Present: an order for 4,200 uniform sets for the block's schools this year. The two groups state capacity for about 2,000.	Likely room, medium
Sadar, garment-unit job	Not read	55 trained in 24 months, shown as context	12 asked, median 24 days. Tight.	14 reached, 9 working. Strong.	Present: three named units state about 40 openings	Likely room, medium
Khairwa, rural mason	9 masons in 1,240 households: 7 per 1,000 against 12. Low.	1 trained in 24 months. Typical.	11 asked, median 21 days, 5 turned work away. Tight.	No reading: only 1 past trainee in the cluster	Present: 310 houses sanctioned in Pahadi this year, 120 near Khairwa	Likely room, medium
Tikri, own two-wheeler shop	2 shops in 1,510 households: 1.3 per 1,000 against 2.4. Low.	None	3 asked. Too few.	No reading	None found	Uncertain: not enough evidence, low
Sadar, mechanic job	Not read	12 trained in 24 months, shown as context	10 asked, median 23 days. Tight.	8 reached, 5 working. Strong.	Present: four named service centres state 9 openings	Likely room, medium
Pahadi, rooftop solar	3 installers against a median of 3. Typical.	30 trained last year. High.	2 asked. Too few.	No reading: none of the 30 was followed up	None found	Uncertain: not enough evidence, low
    • Before Sunita's call, Devgaon's workload reading rests on 15 people. Her call adds the 16th.
    • The Devgaon outcome count is one short of 20. Asha's check-in in section 12 takes it there and lifts confidence to high.
    • Section 21 gives the mix of verdicts the generator must produce for the remaining cells.
10.6 The evidence drawer (C2a)
Clicking a place on the map opens a drawer headed "Why is this area showing this signal?". This is its exact content for the hero cell.
Part	Content for Devgaon, own tailoring
Title	Own tailoring in the village. Devgaon cluster.
Verdict	Likely crowded. Confidence: medium.
Existing workers	High. 84 tailors in 1,860 households. 45 per 1,000, against 27 in similar clusters.
Recent entrants	High. 27 trained in the last 24 months.
Workload	Slack. Median 9 paid days last month across 16 tailors. 1 of 16 turned work away. Rates falling.
Past outcomes	Weak. 6 of 19 past trainees reached are working. 3 could not be reached.
Funded or stated demand	None found. This is not counted as a vote.
Our callers	11 want to start tailoring here. 9 are likely ready for RPL.
Confidence note	Medium: three kinds of evidence, and the largest sample is 19.
What would change this	One more verified check-in would raise confidence to high. A funded order for this cluster would make the evidence mixed.
Recommendation	Avoid adding a large beginner batch here. Consider RPL and order linkage for the people already skilled.
Actions	Button: "See opportunities here". Link: "How this is calculated", which opens the rules on the Data and Trust screen.
Each signal row shows five things: the reading word, the numbers, a small chart, the sample size and date, and a provenance chip that names the real source it stands in for.
Signal	Small chart
A	A bar with a tick at the peer median
B	Unit dots: 27 marked out of 84
C	A dot strip of paid days, one dot per person, with the median marked
D	A unit strip: working, not working, not reached
E	A document chip with the title and date, or "None found"
F	Unit dots, one per caller
The recommendation is produced by a rule from the verdict and signal F. It is never written by the language model.
10.7 How one conversation changes the evidence
What she says	Where it goes	Counted when
Paid days, work turned away, rate direction (turn B6)	Signal C for the cell of the trade she works in	She already works in the trade and agreed to planning use
Her skills and her pre-screen band	Signal F: skilled people and RPL bands	She confirmed the profile at V3
Her interest and her choice	Signal F, and candidate lists in allocation	She confirmed the choice at V6
Her travel and time limits	Local batch formation (section 11)	She confirmed the profile
A relative's training result (turn B7)	A follow-up lead. Never signal D.	Hearsay is not a verified outcome.
Sunita's call therefore does four things. It adds the 16th workload check for Devgaon. It adds one likely-ready tailor in Nadi Paar, taking the count from 19 to 20. It adds one person interested in uniform orders, taking that count from 12 to 13. It creates one follow-up lead about her sister-in-law.
On map layers and exports, any count under 5 is shown as "fewer than 5".
10.8 Limits to state openly
    • A verdict describes the evidence today. It does not forecast next year.
    • The thresholds are starting values for a prototype. A pilot would tune them against verified outcomes.
    • A village that serves outside customers can look crowded when it is not. Workload corrects this.
    • Self-reports can be wrong, so the sample size is always shown.
    • "Likely room" is not a promise of work. It is always paired with an outcome check.
11. Allocation engine
The allocation engine turns verdicts and people into a short list of proposed interventions, each with its candidates, venue, viability check and evidence. The officer decides what enters the plan.
11.1 From a pattern to an action
What the officer sees	Evidence pattern	Proposed intervention	Seed example
Hidden skill	Many people likely ready, none certified	RPL camp	Nadi Paar: 20 tailors
Skill with one shared gap	Many people partly ready, missing the same units	RPL with a bridge module	Pahadi: 23 masons, 21 of them missing setting out
Room and few workers	Likely room, and interested people who lack the skill	Training batch	Sadar: sewing machine operator course
Same pathway, cannot travel	Interest, plus travel limits that rule out the centre	Local batch at a nearer venue	Van Kshetra: 18 people, rural mason
A crowded trade with a batch planned	Likely crowded, and a plan line adds beginner seats	Hold and replace	Nadi Paar: 30-seat tailoring batch
Thin evidence	Uncertain	A small trial	Solar: 12 seats. Nahar: two repair shops.
Skilled people and a buyer	Evidence-supported skills, and a funded order	Order linkage	Nadi Paar: 13 for uniform orders
Skilled people and employers	Skilled or trained people, and stated openings	Placement drive	Sadar: 26 sewing machine operators
11.2 Opportunity types and triggers
Type	Trigger	Viability threshold (seed)	What it contains
RPL camp	People pre-screened likely ready for one qualification who can reach one venue	20 candidates	Orientation, then assessment by an authorised assessor
RPL with bridge	People partly ready who share missing units and can reach one venue	20 candidates	A bridge module on the shared units, then assessment
Training batch	The cell is likely room. People want the pathway and have a blocking skill barrier.	15 to 30 people	A course at the provider's centre
Local batch	As above, but most candidates cannot reach the centre	15 to 25 people	The same course at a venue inside their travel limits
Trial batch	The cell is uncertain. People want the pathway.	8 to 12 seats	A small batch, with a 90-day outcome check before any second batch
Hold or resize	A plan line adds beginner seats to a likely crowded cell, or more than 12 seats to an uncertain cell	None	A hold with a named replacement, or a smaller trial
Order linkage	People with evidence-supported skills, and signal E shows a funded order or buyer	10 people	Joining or forming a group to take the order
Enterprise support	People with no skill barrier and a blocking capital barrier	Any number. In an uncertain cell, two first.	Entrepreneurship course, basic project proposal, credit or asset linkage
Placement drive	Skilled or trained people, and named employers state openings	15 people	Employer introductions on one day
Thresholds are provider minimums and planning assumptions that the officer can edit. They live in config and are not facts. An opportunity below its threshold stays visible as "forming", with the number still needed.
11.3 Local batch formation
A local group forms when enough people who want the same thing can reach the same place at the same time.
    1. Pool. Take the people whose chosen or first-ranked option needs this intervention, in a cell whose verdict allows it.
    2. Split by level. Likely ready, partly ready and beginners are never mixed in one group.
    3. Check reach. For each candidate venue, count the people whose travel limit covers the trip from their cluster and whose free hours cover a session window. Travel times come from a cluster-to-cluster table in minutes.
    4. Choose the venue that covers the most people. Break ties by the lowest total travel time.
    5. Choose the session window that fits the most people.
    6. Check viability against the threshold. Below it, keep the group as "forming".
    7. List who is left out, and why.
Honest counts. Some people stated their limits. For others the limit is assumed from their cluster. The group shows both, and never one bare total.
Seed example	What the screen says
O5, rural mason for beginners	"18 people across 5 villages could form a local batch. 11 confirmed, 7 to confirm." Venue: a housing work site near Kusumi. Window: 10 am to 3 pm. Four people are left out because no shared venue is inside their limit.
O1, RPL camp for tailors	"Block office, Sonpur: 14 of 20 can reach it and be home on time. Panchayat hall, Devgaon: 20 of 20." The officer clicks "Use this venue" on Devgaon.
Each "to confirm" person creates a helper task. The travel table is simulated and labelled so.
11.4 Lifecycle and officer workflow
An opportunity moves through nine statuses: forming, suggested, reviewed, added to plan, sent to provider, provider confirmed, running, completed, outcomes verified. Two side states exist: dismissed and change proposed.
    1. See. The Overview lists what changed. The Opportunities screen lists every opportunity by type.
    2. Check the evidence. The detail screen shows candidates, reach, timing and the cell's signals.
    3. Adjust. The officer can change the venue, dates, seat count and provider. Each change recomputes reach.
    4. Decide. She adds it to the plan, dismisses it with a reason, or keeps a flagged line with a reason.
    5. Send. The cohort specification goes to the provider she picks.
    6. Track. The provider confirms capacity or proposes a change.
    7. Verify. Check-ins are scheduled when the line completes (section 12).
The officer decides at steps 3 to 5. The system records each decision with her reason and the evidence as it stood. That record is what a district committee would need when it endorses a job role.
11.5 Seed opportunities
ID	Opportunity	Place	People	Based on	Seed status
O1	RPL camp, Self Employed Tailor	Nadi Paar: Devgaon 9, Rampura 5, Bela 3, Sonpur 3	19 before Sunita, 20 after. Threshold 20.	Pre-screen bands	Forming, then suggested
O2	Order linkage, uniform group	Nadi Paar	12 before Sunita, 13 after. Threshold 10.	Likely room; funded order	Suggested
O3	Hold: beginner tailoring batch (plan line L1)	Nadi Paar	30 seats	Own tailoring is likely crowded in 3 of the block's 4 clusters	Suggested
O4	RPL with bridge, Rural Mason	Pahadi	23, including Raju. 21 share one gap: setting out from a drawing.	Pre-screen bands; likely room	Suggested
O5	Local batch, rural mason for beginners	Van Kshetra: 5 villages in the Kusumi and Mahuadih clusters	18: 11 confirmed, 7 to confirm	Likely room; travel limits	Suggested
O6	Trial batch, rooftop solar (resizes plan line L4)	Pahadi	12 seats	Uncertain	Suggested
O7	Enterprise support trial, two-wheeler repair shops	Nahar	4 candidates, including Manoj. Two supported first.	Uncertain	Suggested
O8	Placement drive, sewing machine operators	Sadar	26	Likely room; stated openings	Suggested
Before Sunita's call, Devgaon contributes 8 candidates to O1. Her confirmed choice makes it 9 and the total 20.
11.6 The Plan Builder (C4)
The plan is a ledger of plan lines. It starts with four lines proposed by providers, and the officer changes it with evidence.
Line	Proposed by	What	Seats	Plan check result	Suggested change
L1	Provider A	Beginner tailoring course, Nadi Paar	30	Beginner seats in a likely crowded cell	Replace with O1 and O2
L2	Provider B	Sewing machine operator course, Sadar	30	No flag: likely room	Keep, and add O8
L3	Provider C	Rural mason course at the district centre	30	Venue beyond most candidates' travel limit	Replace with O5 on site, and add O4
L4	Provider C	Rooftop solar installer course	30	More than 12 seats in an uncertain cell	Resize to O6, a 12-seat trial
Plan checks. Five rules run on every line.
    • Beginner seats in a likely crowded cell.
    • More than 12 seats in an uncertain cell.
    • A venue beyond most candidates' travel limit.
    • A person with no skill barrier enrolled in a beginner course.
    • No outcome check scheduled.
Before and after strip. It sits above the ledger and updates as lines change. Before: 4 course lines, 120 beginner seats. After all suggestions: 60 course seats, 43 RPL assessments, 13 people in order linkage, 26 in a placement drive, 2 enterprise trials. The strip counts interventions, not people, and says so.
Each plan line stores its evidence as it stood when decided, who decided, the reason, the lines it replaced and its status history.
Override. "Keep anyway" needs a typed reason. The line is tagged "Kept against the evidence" and gets an outcome check at 30 days.
Cost. Each line has one blank cost field for the officer to fill from scheme norms. The prototype does not model costs or invent unit rates.
11.7 The cohort specification (C4a and P2)
The cohort specification is the one page a provider needs to deliver the intervention.
Part	Content, with O1 as the example
Intervention	RPL camp. Self Employed Tailor, AMH/Q1947, the version loaded.
What to assess or teach	The seven core units. For a bridge: the missing units with counts, such as "M1 setting out: 21 of 23".
Candidates	20 people: first name and initial, village, pre-screen band
Limits that affect delivery	"14 of 20 must be home by 4 pm." Only what people stated.
Venue and window	Panchayat hall, Devgaon. 10 am to 3 pm. Local language.
Evidence summary	The verdict, the confidence and the date for the cells involved
What the provider reports	Attendance and a result for each person
Outcome checks	At 30, 90 and 180 days, done independently of the provider
The provider can confirm capacity with dates, propose a change to dates, venue or seats, or decline with a reason.
11.8 The Opportunities screens (C3 and C3a)
C3 list. One row per opportunity, grouped by type. Columns: opportunity, place, people with a threshold marker, verdict and confidence, status, next action. Newly viable items sort first. Filters: block, pathway, status.
C3a detail. Three columns.
    • Left: candidates as unit dots. Filled means confirmed and outlined means to confirm. Clicking a dot shows that person's summary.
    • Middle: venue options with reach, and session windows with fit. One is selected.
    • Right: the evidence as it stands, the effect on the plan ("Replaces L1"), and the main button "Add to plan". "Dismiss" is secondary and asks for a reason.
12. Outcome verification
Outcomes are checked by asking the person directly, on the number she gave at first contact. The provider's report is recorded beside her answer and never replaces it.
This is the thin feature. Build one interactive check-in, one comparison screen and the feedback into signal D. Seed everything else.
12.1 The verify loop
    1. The provider marks training or assessment complete at P2. This is stored as provider-reported.
    2. Check-ins fall due at 30, 90 and 180 days.
    3. The system calls the person and asks four questions by voice (V8).
    4. After two unanswered calls, the helper gets a visit task and runs the same four questions in person.
    5. A rule sets the outcome status from her answers.
    6. The outcome updates signal D for her cell. The verdict and confidence are recomputed.
    7. Any gap between the provider's claim and her answer is flagged for the officer.
12.2 The four questions
#	Question	Answer form	Feeds
1	Are you doing this work now?	Yes, a little, no	Outcome status
2	Last month, on how many days did you get paid work?	A number	Outcome status; signal C
3	About how much did you earn from it last month?	One of four bands, or "I'd rather not say"	Shown to the officer as a band only
4	What is the biggest difficulty?	Free speech, mapped to a barrier type	Diagnosis; helper task
The call ends with one offer: "Would you like the helper to contact you?"
12.3 Outcome statuses
Status	Set when	Set by
Not started	She chose a pathway but nothing has begun	System
Training active	The provider has marked attendance	Provider
Completed	The provider has marked completion, and no check-in has happened yet	Provider
Working	A wage job in the pathway, with 10 or more paid days last month	Check-in
Self-employed	Own work in the pathway, with 10 or more paid days last month	Check-in
Needs support	In the pathway, but under 10 paid days, or she asks for help	Check-in
Unable to find work	She looked and had no paid days	Check-in
Dropped out	She left before completion	Provider, confirmed at check-in
Not reached	Two calls and one visit failed	System
The 10-day bar is a seed threshold in config. "Working" and "Self-employed" count as working for signal D. "Not reached" is shown separately and is never counted as either result.
12.4 Claimed against verified
Every outcome carries its source: the person by call, the person with a helper present, or the provider.
    • The Outcomes screen (C6) shows each cohort as two marks on one line: the provider's claimed share working, and the verified share among people reached.
    • Verified values cannot be edited from the Provider Desk.
    • A person recorded differently by provider and check-in appears in a "Differences to review" list.
    • The prototype does not link payments to outcomes, and does not claim to.
Provider (simulated)	Cohorts	Completed	Claimed working	Reached	Verified working
Provider A, beginner tailoring, Nadi Paar	3	72	56 (78%)	58	20 (34%)
Provider B, sewing machine operator, Sadar	2	55	39 (71%)	14	9 (64%)
Provider C, rural mason, district centre	1	28	21 (75%)	9	6 (67%)
Provider B and Provider C have many trainees not yet due for a check-in. The screen shows the number reached beside every percentage.
12.5 How outcomes feed back
Rule	Effect
Each verified outcome updates signal D for its cell	The verdict and confidence are recomputed at once
Weak outcomes with 20 or more people reached	The plan check blocks new beginner batches in that cell unless the officer overrides with a reason
A cluster with fewer than 8 outcomes	Signal D borrows the block's outcomes for the pathway, labelled as block-level
"Needs support" or a stated difficulty	A helper task is created, and the person can be offered a linkage opportunity
An RPL result is recorded	Should-have: it is compared with the pre-screen band, as one line on C6
Any change of verdict or confidence	A learning event is logged in plain words and shown on C6 and C1
This is how the system learns. It keeps no trained model. It keeps counts, and the counts change the next recommendation.
12.6 The demo check-in: Asha, Devgaon
Asha finished Provider A's tailoring course eight months ago. The provider recorded her as self-employed. Two calls went unanswered, so the helper visits and runs the check-in (H3, then V8).
Turn	Speaker	Line
F1	Agent	Namaste. This is the Hunar Line. You finished the tailoring course eight months ago. May I ask four short questions? Your answers do not change any benefit.
G1	Asha	Yes.
F2	Agent	Are you doing tailoring work now?
G2	Asha	A little, from home.
F3	Agent	Last month, on how many days did you get paid work?
G3	Asha	Five days, maybe.
F4	Agent	About how much did you earn from it last month? You can skip this.
G4	Asha	I'd rather not say.
F5	Agent	What is the biggest difficulty?
G5	Asha	There are no customers. Everyone here stitches.
F6	Agent	Would you like the helper to tell you about group orders for school uniforms?
G6	Asha	Yes.

Result	What changes on screen
Outcome	Needs support. Source: the person, with a helper present. The provider's record said self-employed.
Signal D, Devgaon own tailoring	From 19 reached and 3 not reached, to 20 reached and 2 not reached. Still 6 working. Still weak.
Confidence	Medium to high. The verdict stays likely crowded.
Provider A	Reached 58 to 59. Verified working stays 20, which is 34%. One item is added to "Differences to review".
Learning event	"Own tailoring in Devgaon: confidence rose to high after 20 verified check-ins. 6 of 20 are working."
Helper task	"Tell Asha about the uniform-order group." Barrier recorded: market access.
12.7 The Outcomes screen (C6)
Area	Content
Check-ins	Due, completed and not reached, for each of 30, 90 and 180 days, as unit strips
Claimed against verified	One row per provider and cohort, with the two marks joined by a line and the number reached
Differences to review	People recorded differently by provider and check-in. First name and initial only.
What the district learned	The learning events, newest first, each linked to its cell on the map
Empty state for a new cohort: "No check-ins are due yet. The first falls due on" followed by the date.
13. Dashboard architecture
The District Console has seven screens. Of the twelve considered, five are folded into others, so nothing is built that the demo does not use.
13.1 Screens considered, and the decision
Candidate screen	Decision	Where it lives
Overview	Build	C1 Overview
Livelihood intelligence	Build	C2 Livelihood Map
Skill landscape	Fold in	A layer on C2
Opportunity signals	Fold in	The verdict layer on C2 and the evidence drawer C2a
Training allocation	Build	C3 Opportunities
Local batch opportunities	Fold in	A type filter on C3
Plan builder	Build	C4 Plan
Beneficiary profiles	Build	C5 People and C5a Profile
Outcome verification	Build	C6 Outcomes
Provider performance	Fold in	A section of C6
Evidence explorer	Fold in	The drawer C2a, plus a provenance chip on every number
Privacy, consent and audit	Build	C7 Data and Trust
13.2 The frame
    • Left rail. Seven items with an icon and a label, in this order: Overview, Livelihood Map, Opportunities, Plan, People, Outcomes, Data and Trust. Opportunities and Outcomes carry a count when something is new.
    • Top bar. The district name, the "Simulated district" banner, "Data as of 2 October 2026", the role switcher, Story Mode and Reset demo.
    • Page head. One title and one sentence saying which question the screen answers.
    • Two detail patterns only. A right-hand drawer for evidence (C2a). A full page with a back link for a record (C3a, C4a, C5a).
    • Width. Design at 1440 px. It must work at 1280 px. Below 1024 px the rail collapses to icons.
13.3 What each screen answers
Screen	The officer's question	Layout	Leads to
C1 Overview	What changed, and what needs my decision?	Two columns: a change feed and decisions waiting	C2, C3, C4, C6
C2 Livelihood Map	Where is this pathway crowded, open or unknown, and why?	A map with a control strip and a drawer	C2a, then C3
C3 Opportunities	What could we do, and is it viable?	A grouped ledger	C3a, then C4
C4 Plan	What will we fund, and what did we change?	A ledger under a before-and-after strip	C4a, then the Provider Desk
C5 People	Who is this about?	A dense table	C5a
C6 Outcomes	Did it work, and who says so?	Four stacked areas	C2
C7 Data and Trust	Where does each number come from, and who saw what?	Four tabs	Any screen
Sections 10.6, 11.6 to 11.8 and 12.7 specify C2a, C3, C3a, C4, C4a and C6. The rest follows.
13.4 C1 Overview
The Overview is a list of changes and decisions, not a wall of metric tiles.
    • What changed this week. At most seven sentences, each with a number and a link. Seed text is below.
    • Decisions waiting. Three counts with links: opportunities suggested, plan lines flagged, differences to review.
    • Small map. The verdict mix for the pathway most affected this week. Clicking it opens C2.
    • District facts. One line of four figures, computed from the seed: conversations completed, people with evidence-supported skills, people likely ready for RPL, and check-ins completed out of those due.
#	Seed sentence in the change feed	Opens
1	"RPL camp for tailors in Nadi Paar: 19 of 20 candidates. One more is needed." After Sunita's call: "RPL camp for tailors in Nadi Paar now has 20 of 20 candidates."	C2, focused on Nadi Paar
2	"The beginner tailoring batch planned for Nadi Paar conflicts with the evidence. Own tailoring is likely crowded in 3 of 4 clusters."	C4, line L1
3	"23 masons in Pahadi are partly ready for RPL. 21 share one gap: setting out from a drawing."	C3a, O4
4	"18 people across 5 villages in Van Kshetra could form a rural mason batch on site."	C3a, O5
5	"Own two-wheeler shops in Nahar: the evidence is thin. A trial of two is suggested."	C3a, O7
6	"Rooftop solar: 30 people were trained last year and none has been followed up."	C2, solar
7	"Provider A: 78% claimed working, 34% verified, with 58 of 72 reached."	C6
13.5 C2 Livelihood Map
The map answers one question for one pathway at a time: where is it crowded, open or unknown?
What is drawn.
    • Five blocks and twenty clusters. Each cluster is an equal-sized tile, placed roughly where it lies, inside its block outline.
    • Thin reference lines for the river, the canal, the highway and the forest edge. The district town is marked.
    • Equal tiles are deliberate. The district is simulated, and equal tiles stop empty land from dominating the picture. Real boundaries can replace them through config.
Controls.
Control	Options	Default
Pathway	The seven pathways, one at a time	Own tailoring in the village
Layer	Verdict, skilled people, RPL potential, interest, local groups	Verdict
Level	Clusters or blocks	Clusters
View	Map or table	Map
Layers.
Layer	What a tile shows
Verdict	Fill by verdict, with a pattern and an icon as well as colour. Confidence as one, two or three ticks.
Skilled people	Unit dots: people with evidence-supported skills for the pathway's qualification
RPL potential	Unit dots: filled for likely ready, half-filled for partly ready
Interest	Unit dots: people who want to enter the pathway
Local groups	An outline joining the clusters of each candidate group, with its count
    • Opportunity markers sit above any layer. A forming opportunity shows its count, such as "19 of 20".
    • The block level shows the mix inside each block, such as "3 of 4 clusters likely crowded".
    • The legend is always visible and includes the word "Simulated".
    • The table view holds the same data as a ledger. It serves keyboard and screen-reader users, and sorting.
Interaction.
    • Hover shows the place, the verdict, the confidence and the two strongest signals.
    • Click opens the evidence drawer. The tile keeps an outline while the drawer is open.
    • Arrow keys move between tiles. Enter opens the drawer. Escape closes it.
    • Changing the pathway keeps the selected place.
Rules.
    • An uncertain tile is hatched grey. It is never left blank, because blank reads as "no problem".
    • Dot layers show "fewer than 5" instead of a count under five.
    • No heat gradient, no continuous colour scale, no 3D, no pulsing, and no online basemap.
13.6 C5 People and C5a Profile
C5. A dense table of about 600 simulated people. Columns: name as first name and initial, cluster, trade, RPL pre-screen, primary barrier, chosen pathway, status, last contact. Filters: block, pathway, pre-screen band, barrier, status. Rows open the profile.
C5a. Four tabs.
Tab	Content
Summary	Household livelihood, goals, limits, existing support, and the next step with its date
Skill evidence	Section 8.6
Barriers and pathways	Section 9.7
Timeline and consent	Sessions, choices, follow-ups, check-ins, and who viewed the profile. Consent scopes with dates. "Record a withdrawal of consent".
    • Opening a profile writes an audit event.
    • The phone number is masked except for the last two digits.
    • No caste field exists anywhere. No audio plays in the console.
    • People with a full scripted conversation are Sunita, Raju, Manoj and Asha. Other profiles are generated, and their Skill evidence tab says "Generated profile. No transcript."
13.7 C7 Data and Trust
Tab	Content
Sources	Every data source: name, kind, real or simulated, date, the signal that uses it, and the real source it stands in for
Rules	Every threshold in plain words with its current value. The verdict and confidence rules, word for word.
Consent	People counted by consent scope. How consent is withdrawn. What is never collected.
Audit log	Time, role, action, object and reason, read from the event log
One line sits at the top: "This prototype shows role views, not real access control."
13.8 How the screens connect
C1 Overview
  |-- change item --> C2 Livelihood Map --> C2a Evidence drawer --> C3 Opportunities
  |-- decision -----> C3 Opportunities --> C3a Detail --> C4 Plan --> C4a Cohort spec --> Provider Desk (P1, P2)
  |-- difference ---> C6 Outcomes --> learning event --> C2 Livelihood Map

Any person's name --> C5a Profile        Any provenance chip --> C7 Data and Trust
14. Beneficiary UI
The beneficiary sees one thing at a time on a phone-sized screen, and everything on it is also spoken. It shares nothing with the officer console except the data.
14.1 Principles, as build rules
Principle	Rule
Voice first	Every screen plays its content aloud on arrival. "Hear again" is always present.
One thing at a time	One question or one decision per screen. Nothing needs scrolling to reach.
No reading or typing needed	No text fields. Captions are six words or fewer, in the local script.
Large controls	Touch targets are at least 64 px high. The main control is at least 72 px. At most two choices side by side.
Icons with words	Every choice has an icon, a spoken label and a short caption. Colour is never the only signal.
Confirm before it counts	Her summary and her choice are both read back and confirmed.
Honest words	No scores. No "eligible" or "rejected". No promise of a job.
Privacy in reach	"Pause" hides the screen and stops recording in one tap.
Her pace	No decision times out. "Decide later" is always offered.
14.2 The frame
    • Reference size is 390 by 844 px. In Story Mode the phone sits on the left and the evidence it produces on the right.
    • A bottom bar holds three controls on every screen: Hear again, Pause, and Ask the helper.
    • A top strip shows the language and a small mark while audio is being kept.
    • Four voice states are always distinguishable by shape as well as colour: speaking, listening, thinking, and did not catch that.
    • Thinking never lasts longer than 0.8 seconds. Do not fake a long wait.
    • Numbers are spoken as rounded words: "more than eighty tailors", "about nine days".
    • No face, avatar or mascot. The voice is enough.
14.3 Screen states
Code	Screen	What she hears	What she sees	Controls
V0	Start and language	Nothing yet. The helper holds the phone.	Language names in their own script	A language; Start
V1	Consent	Turn A1, then one question on planning use	An ear icon and one short line per question	Yes; No; Hear again
V2	Conversation	The agent's question	A speaking bar, then a large microphone with a live level meter. The question as a caption. Dots showing "question 3 of about 8".	Hear again; Pause
V3	Confirm what we heard	Turn A10, one line at a time	Four lines, each with an icon	"That's right"; "Not right" on any line
V4	Skills found	Turn A11	Five skill icons with ticks. Two marked "not clear yet". One line: "You may be ready for a skill test."	Hear again; Continue
V5	Your options	Turn A12	Two or three option tiles, stacked in ranked order	Choose; "Why?"; Decide later
V6	Confirm choice	Turn A14	Her chosen option alone	Yes; Change
V7	Next step	Turns A15 and A16	Who will contact her, what happens next, and a date shown as a calendar icon	Yes or No to the follow-up call; Done
V8	Follow-up check-in	The turns in section 12.6	One question per screen with large answer choices	An answer; Skip, on earnings only; Hear again
V9	Paused	Silence	One word, "Paused", and nothing personal	Continue; Stop
14.4 Consent, in three parts
Part	Asked as	Where	If she says no
Recording	"May I record this to understand you better?"	V1, in turn A1	The audio is not kept. Written notes are.
Planning use	"May the district count your answers, without your name, when it plans training?"	V1	The session continues. Her answers feed no district count.
Follow-up call	"May I call you in a month to ask how it is going?"	V7	No check-in is scheduled.
Use for her own guidance is the purpose stated in turn A1. If she does not want that, she taps Stop and nothing is stored. The planning question is a tap on V1 and is not part of the transcript.
14.5 The spoken script after the confirm-back
These turns continue conversation C-01 from section 7.5.
Turn	Screen	Speaker	Line
A11	V4	Agent	From your story I found five things you already do that the tailoring test checks: measuring, patterns, cutting, stitching and alterations. Two were not clear: buttonholes, and looking after the machine. You may be ready for a skill test. An examiner does the test in person. I cannot give a certificate.
A12	V5	Agent	I have three options. One: take the skill test, then join the group that stitches school uniforms. The groups near you are busy, and there is an order this year. Two: take the skill test, then a job at a garment unit in the district town. There are openings, but you would not be home by four. Three: carry on with your own tailoring in the village. Many people near you already do this, and they are getting few days of work. You can also decide later.
B12	V5	Sunita	(Taps "Why?" on option three.)
A13	V5	Agent	Around Devgaon there are more than eighty tailors. Twenty-seven more were trained in the last two years. The tailors I spoke to got about nine days of paid work last month. This can change, and it is your choice.
B13	V5	Sunita	The first one.
A14	V6	Agent	You chose the skill test, then uniform orders with the group. Is that right?
B14	V6	Sunita	Yes.
A15	V7	Agent	Rekha will tell you the test date. May I call you in a month to ask how it is going?
B15	V7	Sunita	Yes.
A16	V7	Agent	Thank you. You can change your mind at any time. Just tell Rekha.
Rekha is the local helper in the seed data.
14.6 The option tile (V5)
    • An icon for the pathway, and a name of five words or fewer.
    • One reason line of eight words or fewer.
    • A signal mark with a plain phrase: "Busy near you", "Not known yet" or "Many already do this".
    • Any conflict with her limits, stated on the tile: "Not home by four".
    • A "Why?" button that plays two or three sentences of evidence.
    • No numbers on the tile. Numbers are spoken only in "Why?".
    • A likely crowded tile uses the rust colour with a pattern, and stays fully selectable. Nothing on this screen is red or greyed out.
    • If she named a pathway herself, that tile carries the words "You asked for this".
14.7 Edge states
Situation	What happens
She is not understood	The agent asks once more in simpler words. After a second miss it offers two or three spoken choices as tiles.
Silence for 8 seconds	"Take your time. Tap the microphone when you are ready."
Someone walks in	She or the helper taps Pause. V9 shows, recording stops and the pause is logged.
She wants to stop	Stop, on V9. She is asked whether to keep or delete what she has said.
She disagrees with the summary	"Not right" on a line re-asks only that item.
She cannot decide	"Decide later" books a callback and creates a helper task. No option is recorded as chosen.
She picks a likely crowded option	The choice is accepted. She hears one sentence on what the evidence shows, and that a check-in will come sooner.
No connection	Design note only: a real session would be saved on the phone and sent later. The prototype runs offline in any case.
Presenter running the script	Space or a tap advances one turn. Speed is 1x or 1.5x. "Skip to options" exists for rehearsal.
14.8 The helper's screens
The helper uses a plain phone layout with normal text, because she reads and types.
Code	Screen	Content	Main action
H1	Today	Two lists: sessions planned, and follow-ups due	Start a session
H2	New session	First name, cluster and language. A privacy tip: "Find a place where she can speak freely. Then hand her the phone." Two disabled labels, "Phone call" and "WhatsApp voice note", captioned "Same conversation engine. Not in this prototype."	Hand over the phone
H3	Follow-ups	Tasks by type: tell her a date, confirm a travel limit, visit for a check-in	Open a task
H4	Person card	First name, village, her next step, and task history. No skill detail and no barriers.	Mark informed; Start check-in; Record a withdrawal of consent
14.9 How it differs from the console
Aspect	Voice Session	District Console
Reading load	None required	Dense, for a trained reader
Per screen	One decision	Many rows, one question
Numbers	Spoken, rounded, only on request	Exact, with sample size and provenance
Colour	Large fields, few colours	Small accents on a quiet ledger
Motion	Voice states only	Cause and effect between views
Language	Local script and speech	English in the prototype
15. Complete screen inventory
The prototype has 31 screens and shared parts: 3 shared, 10 in the Voice Session, 4 for the helper, 11 in the District Console and 3 on the Provider Desk. Nothing else should be built.
Screen	User	Purpose	Key components	Main action	Data
Top bar and role switcher	Everyone	Show where you are and switch role view	District name; "Simulated district" banner; data date; "Viewing as" control; Story Mode; Reset demo	Switch view	Reads config and role state
Reset demo dialog	Presenter	Restore the seed state	What will be cleared; confirm	Reset demo	Clears the event log
S1 Story Mode	Presenter	Run the demo in order, with the phone beside the evidence it produces	Beat list; split view; next and back; "Rank with local evidence" switch; caption line	Next beat	Reads everything; writes the same events as the real screens
V0 Start and language	Helper, then beneficiary	Pick the language and begin	Language names in their own script	Start	Reads config
V1 Consent	Beneficiary	Get spoken consent for recording and planning use	Consent audio; ear icon; Yes and No; Hear again	Yes	Writes Consent
V2 Conversation	Beneficiary	Collect her work story by voice	Speaking bar; microphone with level meter; caption; question dots; bottom bar	Speak	Reads the script; writes turns and facts
V3 Confirm what we heard	Beneficiary	Let her correct the summary	Four summary lines with icons; "Not right" on each	That's right	Reads facts; writes confirmation and corrections
V4 Skills found	Beneficiary	Tell her which of her skills count	Skill icons with marks; pre-screen line	Continue	Reads skill evidence and pre-screen
V5 Your options	Beneficiary	Offer two or three options with reasons	Option tiles; "Why?"; Decide later	Choose an option	Reads options and verdicts
V6 Confirm choice	Beneficiary	Confirm her choice	The chosen option; Yes and Change	Yes	Writes the choice event
V7 Next step	Beneficiary	Say what happens next and ask about a follow-up call	Next step; who will contact her; date; Yes and No	Done	Writes follow-up, helper task and consent
V8 Follow-up check-in	Beneficiary, alone or with the helper	Verify the outcome	One question per screen; answer tiles; Skip on earnings	Answer	Writes Outcome
V9 Paused	Beneficiary and helper	Protect privacy when someone is listening	The word "Paused"; Continue; Stop	Continue	Writes a pause event
H1 Today	Helper	See sessions planned and follow-ups due	Two lists with counts	Start a session	Reads tasks and sessions
H2 New session	Helper	Set up a session	First name; cluster; language; privacy tip; two disabled channel labels	Hand over the phone	Writes a draft Beneficiary and a Conversation
H3 Follow-ups	Helper	Work through tasks	Tasks by type and due date	Open a task	Reads tasks
H4 Person card	Helper	Act for one person	First name; village; next step; task history	Mark informed, or Start check-in	Reads a minimal profile; writes task status
C1 Overview	Officer	See what changed and what needs a decision	Change feed; decisions waiting; small map; district facts line	Open the top change	Reads events, opportunities and plan flags
C2 Livelihood Map	Officer	See where a pathway is crowded, open or unknown	Tile map; pathway, layer, level and view controls; legend; opportunity markers	Select a place	Reads cells, verdicts, caller counts and opportunities
C2a Evidence drawer	Officer	Show why a place has its verdict	Verdict; six signal rows with small charts and provenance; confidence note; what would change this; recommendation	See opportunities here	Reads signals and the verdict's explanation
C3 Opportunities	Officer	Review proposed interventions	Grouped ledger; threshold markers; filters	Open an opportunity	Reads opportunities
C3a Opportunity detail	Officer	Check and adjust one opportunity	Candidate dots; venue and window options with reach; evidence; effect on the plan	Add to plan	Reads candidates and the travel table; writes Intervention and plan line
C4 Plan	Officer	Build and change the district plan	Before-and-after strip; plan ledger; flags; history; override with reason	Replace, or Send to provider	Reads plan lines and checks; writes plan events
C4a Cohort specification	Officer	Send a brief the provider can deliver from	The parts in section 11.7; provider picker	Send to provider	Writes Batch
C5 People	Officer	Find a person	Dense table; filters; search	Open a profile	Reads beneficiaries
C5a Profile	Officer	Understand one person	Four tabs: Summary, Skill evidence, Barriers and pathways, Timeline and consent	Open her opportunity	Reads profile, evidence, barriers and timeline; writes an audit event
C6 Outcomes	Officer	Compare claimed and verified outcomes, and see what was learned	Check-in strips; claimed-against-verified rows; differences; learning events	Review a difference	Reads outcomes, training records and learning events
C7 Data and Trust	Officer	Trace any number, read the rules, see consent and the audit log	Four tabs: Sources, Rules, Consent, Audit log	Open a source	Reads sources, config, consent and the event log
P1 Cohort inbox	Provider	See the cohorts sent to this provider	List with status	Open a cohort	Reads this provider's batches
P2 Cohort detail	Provider	Confirm capacity, then report delivery	The specification; candidates; confirm form; propose a change; attendance and results	Confirm capacity	Writes the provider's response and training records
P3 Outcomes record	Provider	See own claimed and verified outcomes	One row per cohort; the gap; read-only	None	Reads outcomes for own cohorts
States every screen needs
State	Rule
Empty	Say what is missing and what to do next. Example: "No opportunities match these filters. Clear filters."
Loading	Show a skeleton only where a real wait exists. The seed loads once at start.
Error	Say what failed and how to recover, in the interface's voice. Example: "The seed data did not load. Reset demo."
Simulated	Every screen with data shows the banner, and every chart and table carries its own "Simulated" tag.
After an action	The button's verb returns as a past-tense confirmation. "Add to plan" gives "Added to plan".
16. Design system
The interface should look like a district's own register and map, made precise: calm, exact, humane and accountable. One idea carries it: every count on screen is visibly made of people.
16.1 Direction: map and ledger
Element	Decision	Why it fits this subject
Concept	A map for where, a ledger for what and who	District staff already think in maps and registers
Signature element	One dot is one person	The product's claim is that people add up to a plan. The dot makes that visible on every screen.
The person in focus	A marigold dot, quote underline and choice mark	Her words, her dot and her choice are the same colour everywhere, so the eye can follow her across screens
Authority	Indigo, the colour of stamp-pad ink	Decisions and verified marks look like something an office stood behind
Honesty	Hatching for anything simulated or uncertain	Unknown and simulated things must look different from known things
Spend boldness in one place: the dots and their journey. Keep everything around them quiet.
16.2 Colour
Colour has three jobs only: to mark the person, to mark an action, and to carry a status. Everything else is ink on paper.
Token	Starting value	Use
Paper	#F5F7FA	App background. Cool white, not cream.
Surface	#FFFFFF	Tables, drawers, the phone screen
Ink	#1A2233	Text and table rules of emphasis
Ink soft	#55607A	Secondary text, axis labels
Rule	#D8DEE8	Ledger lines and dividers
Indigo	#2F3E9E	Primary actions, links, selection, the verified seal
Marigold	#F2A20C	The person in focus. Never used for text on white.
Room	#0E7C6B	Likely room
Uncertain	#6B7385	Uncertain, always hatched
Crowded	#B5471B	Likely crowded. A rust, not an alarm red.
    • Each status colour has a pale tint for fills and the full value for borders and icons.
    • Test every pair for contrast before use. Text needs 4.5 to 1 and graphical marks need 3 to 1.
    • No gradients. No dark mode in the prototype. No colour used only for decoration.
    • Red is not in the palette. Nothing in this product is an alarm.
16.3 Typography
Use one type family with matching designs for Latin and the district's script, so that Hindi and English sit together without one looking like an afterthought.
Requirement	Detail
Scripts	Latin and the district's script from the same family
Weights	Regular, medium and semibold
Figures	Tabular lining figures for every number in a table or chart
Licence	Open, so it can be bundled for offline use
Recommended	Anek, which has matching designs across Latin and nine Indian scripts and a width axis. Confirm it has tabular figures before committing.
Fallback	Noto Sans with the matching Noto script font

Role	Console size and line height	Weight
Page title	28 / 36 px	Semibold, slightly condensed
Section heading	18 / 28 px	Semibold
Body	15 / 24 px	Regular
Table text	14 / 20 px	Regular, tabular figures
Caption and chip	13 / 18 px	Medium
Large figure	34 / 40 px	Semibold. At most one per screen.

Role	Voice Session size	Note
Option name	24 / 34 px	Semibold
Caption	20 / 30 px	Never below 18 px
Button label	22 px	With an icon
    • Set the line height of the local script at 1.5 or more. Its marks above and below the line need the room.
    • Hierarchy comes from size and weight. Do not use all capitals, letter-spaced labels or a label above every heading.
    • Do not use a monospace face for data labels. Tabular figures do that job.
    • Sentence case everywhere. Line length under 80 characters.
16.4 Spacing, grid and shape
Item	Value
Base unit	4 px. Steps: 4, 8, 12, 16, 24, 32, 48, 64.
Console grid	12 columns, 24 px gutters, content up to 1360 px wide
Left rail	232 px
Evidence drawer	440 px
Page gutter	32 px. Gap between sections: 48 px.
Table cell padding	8 px by 12 px
Phone padding	20 px
Corner radius	4 px for controls and chips. 8 px for cards and the drawer. 16 px for phone tiles and buttons. Tables have square corners.
Shadow	One, for overlays only: drawer, dialog, popover. Cards have a 1 px border and no shadow.
16.5 Cards and tables
Use a card only for an object the user acts on as one thing: an option tile, an opportunity's detail header, a cohort specification, a helper task.
Do not use a card for a metric, to group a section, to wrap a table or a chart, or for a list of more than about six like items. Sections are separated by space and a heading. Lists of like items are tables.
Table rule	Value
Row height	36 px in the console. 44 px on the Provider Desk and helper screens.
Lines	1 px rules between rows. A 2 px ink line under the header. No zebra striping.
Alignment	Text left. Numbers right, in tabular figures.
Columns	Eight at most. Status is a mark with a word, never colour alone.
Header	Sticky, sortable, sentence case
Rows	The whole row is clickable when it opens a record. Keyboard focus moves by row.
Density	Show real density: 15 to 25 rows visible. Do not pad a table to look spacious.
16.6 Charts
Pick the chart from the question, and prefer forms that show the sample size.
Information	Chart	Where
How many people	Unit dots, one dot per person. Above 60, one dot is five people, with a legend.	Map layers, candidates, signal F
A value against the peer median	A single bar with a tick at the median	Signal A
A share of a group	Unit dots with some filled	Signal B
How busy people are	A dot strip: one dot per person on a 0 to 30 day axis, with the median marked	Signal C
What happened to past trainees	A unit strip in three segments: working, not working, not reached	Signal D, C6
Progress to a threshold	A dot row with a notch at the threshold	Opportunities
Claimed against verified	Two marks on one line, joined	C6
The plan before and after	Two aligned segmented bars	C4
    • A chart's title states the finding: "6 of 19 reached are working".
    • Every chart carries its sample size, its date and a "Simulated" tag.
    • Label directly. Avoid a separate legend where labels fit.
    • No pie, donut, gauge, radar, 3D, area gradient or sparkline without an axis.
    • No line chart, because the prototype has no real time series.
    • Fewer than three numbers is a sentence, not a chart.
16.7 Map
Order of prominence	Element
1	Verdict fill on each tile: tint, pattern and icon
2	The selected tile's indigo outline
3	Opportunity markers
4	Cluster names inside tiles; block names outside the outlines
5	Reference lines for river, canal, highway and forest edge, as thin dashed lines
A tile holds the cluster name at top left, the verdict icon at bottom left and the confidence ticks at bottom right.
16.8 Status indicators
Every status is a shape, a pattern or mark, a word and a colour. Remove the colour and it must still read.
Status	Mark	Fill or pattern	Word
Likely room	A few dots with space between them	Solid teal tint	Likely room
Uncertain	A dashed ring with a question mark	Grey diagonal hatch	Uncertain
Likely crowded	A tight cluster of dots	Rust tint with a fine dot pattern	Likely crowded
Confidence	One, two or three tally strokes	None	Low, medium, high
Not evidenced	? in a dotted circle	None	Not evidenced
Self-reported	Outline triangle	None	Self-reported
Evidence-supported	Tick	None	Evidence-supported
Assessed	Seal	Indigo	Assessed
Verified by check-in	Tick in a seal	Indigo	Verified
Simulated	Hatched chip	Grey diagonal hatch	Simulated
Real source	Outlined chip with a link icon	None	Real source, with the date read
Provenance chips name the kind of source: official record, self-reported, verified by check-in, or estimated by rule. In this prototype almost every chip is also hatched as simulated. The few real items, such as qualification titles, carry "Real source" and a link.
16.9 Buttons and forms
Button	Look	Use
Primary	Indigo fill, white label	One per view. The decision the screen exists for.
Secondary	Indigo outline	Other actions
Quiet	Text only	Low-stakes actions such as "Hear again" in the console or "Clear filters"
Destructive	Rust outline	Dismiss, and Reset demo. Always asks for confirmation, and a reason where a decision is undone.
    • A label is a verb and an object: "Add to plan", "Send to provider". No arrows in labels.
    • Console buttons are 36 px high. Phone buttons are 72 px.
Form	Rule
Beneficiary	No text fields at all. Choices are large tiles with an icon and audio.
Helper	48 px inputs. Typing is limited to a first name. Everything else is a picker.
Officer and provider	36 px inputs with labels above. A reason is required for any override, dismissal or replacement.
16.10 Icons, imagery and words
    • One outline icon set at one stroke weight. 20 px in the console and 32 to 48 px on the phone.
    • No stock photos, no generated images and no illustrations of people. The dot is the person.
    • No State Emblem, ministry logo or hackathon logo inside the product. It is a prototype and must not pass for an official site.
    • Use plain words. "People", not "beneficiary records". "Likely crowded", not "saturated". "Simulated", not "mock".
    • Never write "AI-powered", "smart" or "insights" in the interface.
    • "RPL pre-screen" always keeps the word "pre-screen".
16.11 Accessibility and responsiveness
Requirement	Detail
Keyboard	Every action is reachable and the focus ring is always visible: 2 px indigo with a 2 px gap
Screen readers	Charts have a text alternative. The map has a table view. Changes are announced in a live region.
Motion	Every animation has a reduced-motion version (section 17)
Language	Mark each text run with its language so that the right script font and voice are used
Audio	Every spoken line has its text on screen
Console widths	1440 px design. Works at 1280 px. Rail collapses under 1024 px.
Phone views	Designed at 390 px. On a desktop they sit centred in a phone frame.
16.12 What to avoid
Avoid	Because
Gradients, glass effects, glowing blobs, sparkle icons	They signal "AI demo", and this is a planning instrument
A wall of metric tiles	It hides what changed and what to decide
Identical rounded cards for everything	They erase the difference between a number, a list and a decision
Charts that hide sample size	The product's honesty depends on showing how little or how much is known
3D, tilted or animated maps	They add nothing a flat tile cannot show
A UI kit's default look	It reads as a template
All-capital labels, monospace data labels, arrows on buttons	They are template habits, not decisions
Tricolour decoration	It imitates official branding
17. Interaction design
Motion in this product has one job: to show that something caused something else. If an animation does not show a cause and its effect, leave it out.
17.1 Rules for motion
    • Every animation answers an action or a new fact. Nothing moves on its own except the listening meter.
    • No animation lasts longer than one second, apart from the dot's journey to the map.
    • One orchestrated moment exists: the WOW sequence in section 23. Everything else is small.
    • No entrance animations on page load. No hover effects on rows beyond a tint.
    • Every animated change is also announced as text in a live region.
    • With reduced motion switched on, each change happens at once and the changed element keeps a 2 px indigo outline for two seconds.
    • Do not fake waiting. The seed is local, so nothing needs a spinner.
17.2 The animations that carry meaning
#	Interaction	Trigger	What moves	Time	What it tells the viewer
1	Evidence from the transcript	A turn finishes playing	The supporting quote gains a marigold underline. A small marker travels from the quote to its skill unit.	400 ms	The evidence is her own words
2	Skill unit changes level	The marker arrives	The mark changes from "?" to a tick, and the count rises by one	200 ms	The count is built unit by unit, not scored
3	Barriers resolve	The profile is confirmed	Each of the seven markers fills to its status, with its "because" line	150 ms each	The diagnosis comes from stated facts
4	Options re-rank	"Rank with local evidence" is switched on	The option rows change places. Each moved row leaves an outline at its old rank for two seconds, labelled "was 1st". An evidence line appears under each.	600 ms	Local evidence changed the order, and here is how
5	Her dot travels	She confirms her choice at V6	Her marigold dot leaves the phone and lands on her cluster's tile	900 ms	One conversation became district evidence
6	A threshold is reached	Her dot lands	The dot row for the RPL camp fills its 20th place. The notch is reached. "Forming" changes to "Suggested".	400 ms	One more person made an intervention viable
7	The plan flags a line	The camp becomes viable	Line L1 gains a "Hold suggested" flag in the plan	200 ms	The district's plan responds to evidence
8	Evidence drawer	A tile is clicked	The drawer slides in from the right. Its contents appear at once, with no stagger.	240 ms	The map stays in view as context
9	Map layer or pathway change	A control is changed	Tile fills cross-fade	200 ms	Same places, different question
10	A line is replaced	"Replace" is confirmed	The old line is struck through and collapses to one row reading "Replaced by". The new lines slide in beneath it. The before-and-after strip updates.	500 ms	Nothing is deleted. The change and its reason stay visible.
11	Sent to provider	"Send to provider"	The status chip changes. The role switcher shows a count on Provider Desk.	200 ms	The work has changed hands
12	Outcome feeds back	A check-in is saved	The outcome strip gains one unit. The confidence strokes go from two to three. A learning event appears at the top of its list.	600 ms	Verification changed what the system believes
13	Voice states	Speaking, listening, thinking	A speaking bar, a live level meter, three quiet dots	Continuous	The system is listening to her
17.3 Detail on the three hardest
Re-rank (4). Use a position transition, so that each row visibly slides to its new place. Do not fade the list out and in. The "was 1st" outline matters, because it lets a viewer who blinked still see what changed.
Dot to map (5 and 6). In Story Mode the phone and the map share the screen, so the dot travels in a straight, slightly eased path between them. Outside Story Mode the views are on different screens. There, the map shows her dot arriving when the console is next opened, with the tile outlined for two seconds.
Outcome feedback (12). The three changes happen in order, 200 ms apart: the strip, then the confidence strokes, then the learning event. The order is the argument.
17.4 Feedback without motion
Moment	Feedback
A decision is saved	The button label becomes its past tense for two seconds, and the status chip changes
A reason is required	The dialog will not close until a reason is typed. The field says what it is for.
An action cannot be done	The control is absent, not greyed out, unless its absence would confuse. Then it is disabled with a one-line reason.
Something is simulated	The hatch and the word are always there. No tooltip is needed to find out.
17.5 Keyboard and presenter controls
Key	Where	Action
Tab and Shift+Tab	Everywhere	Move focus in reading order
Arrow keys	Map	Move between tiles
Enter	Map, tables	Open the drawer or the record
Escape	Drawer, dialog	Close and return focus to where it was
Space	Voice Session script	Play the next turn
Right and left arrows	Story Mode	Next beat and previous beat
L	Story Mode	Switch "Rank with local evidence"
R	Story Mode	Reset demo, after confirmation
Story Mode's keys work only while Story Mode is open, so they cannot interfere with typing a reason.
18. Data model
The model has four kinds of record: reference data, people and their words, computed evidence, and the district's decisions. Everything about people and places is simulated. Only the qualifications and standards are real.
18.1 Fields every record carries
Field	Values
ID	Stable, so the seed and the events can refer to it
Kind of source	Official record, self-reported, verified by check-in, or estimated by rule
Origin	Real or simulated
Source	A link to an entry in the Source list
Date	When it was collected or computed
Sample size	Where the value summarises several people
18.2 Reference data
Entity	Key fields	Relates to	In the prototype
Location	Level (district, block, cluster, village); name; parent; type (rural or peri-urban); households; tile position	Its parent; Beneficiary; Cell	Hand-written. Fictional names. Household counts simulated.
TravelTime	From cluster; to cluster or venue; minutes; usual mode	Location	Generated. Simulated.
Occupation	Name; sector	Pathway; Qualification	Hand-written. Four sectors.
Pathway	Name; occupation; type; market scope; certificate role; cost band; time to first income	Occupation; Qualification; Cell	Hand-written from section 9.3. Seed assumptions.
Qualification	Code; title; version; NSQF level; source link; date read	Standard; Pathway	Real, from the register (section 8.3)
Standard	Code; title	Qualification; SkillUnit	Real, from the register
SkillUnit	Plain name in two languages; main tasks; standard; core flag; mapping status; follow-up question; assessor line	Standard; SkillEvidence	Hand-written. Ours, and labelled as demo units.
Provider	Name; sectors; centres	TrainingRecord; Batch	Three hand-written: Provider A, B and C. Simulated.
Source	Name; kind; origin; date; the real source it stands in for	Any record	Hand-written. Shown on C7.
18.3 People and their words
Entity	Key fields	Relates to	In the prototype
Beneficiary	First name; initial; age band; gender; village; masked phone; language; current pathway; status	Household; Location; Conversation; Consent	Five hand-written and about 600 generated. Simulated.
Household	Village; earners; income sources; seasonal migration; SHG membership; training history	Beneficiary; Location	Generated. Simulated.
Conversation	Beneficiary; helper; language; mode (scripted or live); status; confirmed flag	Beneficiary; Turn; Fact	Four hand-written with turns. The rest are generated profiles with no transcript.
Turn	Order; speaker; text in the local script; English line; audio file	Conversation	Hand-written
Fact	Group; field; value; quote (turn, start, end); basis (stated or inferred); confirmed by her	Turn; Beneficiary	Hand-written for scripted conversations. Generated as profile fields for others. Self-reported.
WorkerCheck	Beneficiary; cell; paid days last month; work turned away; rate direction; date	Beneficiary; Cell	Generated. Sunita's is written by her session. Self-reported.
Consent	Recording; planning use; follow-up call; date; withdrawal date	Beneficiary	Written at V1 and V7. Seeded for others.
Task	Helper; beneficiary; type; due date; status	Beneficiary	Seeded, and written by events
The Beneficiary record has no caste or sub-caste field, no surname, no identity number and no street address. Age is a band.
18.4 Computed evidence
Entity	Key fields	Relates to	In the prototype
SkillEvidence	Beneficiary; skill unit; level 0 to 4; quotes; specifics; flags for a stated limit or gap	Beneficiary; SkillUnit; Fact	Computed by the Skill evidence module. Seeded for the five personas.
PreScreen	Beneficiary; qualification; core units in total, supported and not evidenced; band; entry route note	Beneficiary; Qualification	Computed
BarrierStatus	Beneficiary; pathway; barrier type; status; the fact it rests on	Beneficiary; Pathway; Fact	Computed by the Diagnosis module
PathwayOption	Beneficiary; pathway; rank on the person alone; rank with place; package; conflicts; reasons	Beneficiary; Pathway; Cell	Computed by the Pathways module
Choice	Beneficiary; the pathway chosen, or "decide later"; date; whether it went against the ranking	PathwayOption	Written at V6. Seeded for others.
Cell	Location; pathway; scope	SignalReading; Verdict	A computed list of 72
SignalReading	Cell; signal A to F; values; reading word; vote; sample size; date	Cell; Source	A, B and E are seed inputs. C, D and F are computed from WorkerCheck, Outcome and people.
DemandDocument	Title; issuer type; place; period; quantity as stated; the real source it stands in for	SignalReading for E	Hand-written. Simulated.
Verdict	Cell; verdict; sub-reason; confidence; votes; explanation sentences; what would change it	Cell; SignalReading	Computed by the Verdict module. Estimated by rule.
LearningEvent	Cell; what changed, from and to; the outcome that caused it; one sentence	Verdict; Outcome	Written by the Outcomes module
18.5 The district's decisions and their results
Entity	Key fields	Relates to	In the prototype
Opportunity	Type; pathway; place; candidates; threshold; venue options; window; status; evidence as it stood	Cell; Beneficiary; Verdict	Computed by the Allocation module. Status changes through events.
Intervention	Opportunity; type; who decided; reason; date	Opportunity; PlanLine	Written when the officer adds an opportunity to the plan
PlanLine	What; place; seats or candidates; provider; status; flags; lines it replaced; evidence as it stood; blank cost field	Intervention; Provider; Batch	Four seeded lines. Others are written by events.
Batch	Plan line; provider; candidates; units; venue; window; dates; status; provider response	PlanLine; Provider; Beneficiary	Written by events. Past cohorts are seeded. This is the cohort specification.
TrainingRecord	Beneficiary; provider; batch; course; dates; completion; certificate; the outcome the provider claimed	Beneficiary; Provider; Batch	About 250 generated past records. Provider-reported. Simulated.
Outcome	Beneficiary; pathway; cell; due point; status; paid days; earnings band; difficulty; source; date	Beneficiary; TrainingRecord; Cell	Generated history. Asha's is written by the demo. Verified by check-in.
AuditEvent	Time; role; action; object; reason; before and after	Any record	The event log. Seeded with a short history.
18.6 The names in the brief, mapped
Name in the brief	Here
Evidence	SkillEvidence, built from Fact
Skill	A task held as a Fact, and the person's SkillEvidence for a unit
SkillUnit	SkillUnit, under a real Standard
OpportunitySignal	SignalReading and Verdict, for a Cell
Intervention and Batch	Opportunity, then Intervention and PlanLine, then Batch
18.7 State is the seed plus the events
Nothing is edited in place. Each demo action appends one event, and every screen is computed from the seed and the events in order.
Event	Written by
Session started; consent recorded; profile confirmed; choice confirmed; follow-up scheduled	Voice Session
Task closed; check-in recorded; consent withdrawn	Helper
Evidence viewed; profile viewed; venue changed; opportunity added to plan; opportunity dismissed; line replaced; line kept against the evidence; batch sent	District Console
Capacity confirmed; change proposed; attendance recorded; result recorded	Provider Desk
Demo reset	Presenter
Each event stores the role, the time, the object, the reason where one is required, and the values before and after.
18.8 Seed files
The seed is a set of plain data files, one per entity that is not computed: config, locations, travel times, qualifications and standards, skill units, pathways, providers, sources, people, households, the four conversations with their turns and facts, worker checks, training records, outcomes, supply inputs for signals A and B, demand documents, plan lines, tasks and the starting events. Section 21 says how they are produced.
19. Prototype data strategy
Almost everything in the prototype is simulated, a few reference items are real, and the screen must always say which is which. No simulated number may look like an official statistic.
19.1 Four classes of data
Class	What is in it	How it is made	How it is labelled
Real	Qualification titles, codes, levels and standards. Scheme rules quoted in the interface. The names of the real sources each signal would use.	Copied from official documents, with a link and the date read	"Real source" chip with a link
Synthetic	About 600 people and their households, training records, outcomes, worker checks, supply counts and travel times	Produced from archetypes by a seeded generator (section 21)	"Simulated" hatch and tag
Demo	Five personas, four scripted conversations, the hero cells, four plan lines, three providers and the demand documents	Written by hand so the story holds together	"Simulated" hatch and tag. Persona records also say "Scripted".
Authored rules	Skill units, pathway attributes and every threshold	Written by the team	"Demo units" on the catalogue. "Estimated by rule" on verdicts. All listed on C7.
19.2 What a real pilot would draw on
These are candidate sources, not confirmed feeds. Check access, coverage and date for each before relying on it.
Need	Candidate source	What it could give	Caveat
Qualifications and standards	National Qualifications Register	Titles, codes, levels, standards	Versions change
Places and codes	Local Government Directory; Census village directory	Village names and codes; household counts	Census counts date from 2011
Signal A, existing workers	SHG federation and helper listings; Udyam Assist and e-Shram registrations	Counts by occupation	Registrations miss many home-based workers. Village-level access needs the department.
Signal B, recent entrants	Training records from this scheme and from other skilling schemes	Who trained in what, and where	Needs departmental access. Addresses can be weak.
Signal C, workload	This system's own conversations	Paid days, work turned away	Self-reported
Signal D, outcomes	This system's own check-ins	Verified status	Some people cannot be reached
Signal E, funded demand	Rural housing sanction lists; public works records; institutional orders such as school uniforms; openings stated by named employers	Committed work by place	A sanction is not yet work
District context	The district's Potential Linked Credit Plan; the District Skill Development Plan	Sector potential as assessed by those bodies	District-wide, not local. Publication dates vary.
Labour market context	Periodic Labour Force Survey	State and regional context	Not built for village-level estimates
School enrolment, for uniform orders	UDISE+	Enrolment by school	Orders depend on state policy
The first two signals a pilot can trust are C and D, because the system collects them itself. That is the reason the prototype treats them as the tie-breakers.
19.3 Labelling rules
    1. A banner on every data screen reads "Simulated district. Every figure here is demo data." It cannot be dismissed.
    2. Every chart, table and drawer carries its own "Simulated" tag, so that a cropped screenshot stays labelled.
    3. Each value's chip names its kind of source: official record, self-reported, verified by check-in, or estimated by rule.
    4. "Real source" appears only with a link and the date read.
    5. A simulated official record says what it stands in for: "Simulated. Stands in for: rural housing sanction list."
    6. No real logo, emblem, scheme letterhead or "Source: Ministry of" caption sits near a simulated value.
    7. Place and provider names are fictional. People have first names only.
    8. Anything from a live model call is tagged "Live, unreviewed" and never changes a seeded count.
    9. The Data and Trust screen lists every source with its class.
    10. The presenter says once, early: "Every number you will see is seeded."
19.4 The five labels
Label	Meaning	Example	Look
Real source	Copied from a named public document	Self Employed Tailor, AMH/Q1947	Outlined chip with a link icon and the date read
Simulated	Made for the demo	84 tailors in Devgaon	Grey diagonal hatch and the word
Self-reported	Said by the person and not checked	"Eight or nine days"	Chip with a speech mark
Verified	Confirmed by an independent check-in	Asha: 5 paid days last month	Tick in an indigo seal
Estimated	Produced by a rule from other values	Verdict: likely crowded	Chip with a ruler mark
Labels combine. Sunita's paid days are "Self-reported, simulated". The verdict for Devgaon is "Estimated, simulated".
19.5 How a fake number comes to look official, and how to prevent it
Risk	Prevention
A real district name beside invented counts	Use the fictional district by default (section 20)
Percentages with decimals	Show counts with their base: "6 of 19", not "31.6%"
A caption that names a ministry or scheme as the source	Captions say "Stands in for", never "Source"
A screenshot shared without its banner	The tag is inside every chart and table
A capacity figure produced by a model	The model never produces a number. Rules produce verdicts. Quantities in demand documents are typed into the seed and labelled.
A slide that quotes the demo's numbers as findings	The deck quotes only verified public figures. Demo numbers stay inside the demo.
20. Demo district strategy
Build on a fictional district shaped like a real type of district, and keep the option to load a real one through config. Do not name a real district until its data has been checked.
20.1 Why the default is fictional
    • No district's data was verified for this blueprint, so naming one would be a guess.
    • Invented counts beside a real district's name read as official statistics, however they are labelled.
    • A judge who knows that district will test the numbers, and the demo will lose on a detail that does not matter.
    • A fictional district lets the hero cells be placed by hand, so the story is certain to work.
The qualifications, the scheme rules and the names of the real sources stay real.
20.2 Criteria for choosing a real district later
Criterion	Why it matters	How to check	Pass mark
Data availability	Signals A, B and E need records by place	Look for the housing sanction list by panchayat, the district credit plan, and a village directory with codes	All three found, and the first two recent
Geographic diversity	The map needs contrast	Classify each block: town, plain, upland, forest edge	At least three block types
Relevant occupations	The four sectors must exist there	Look for tailoring or garment work, house construction, two-wheeler repair and any solar activity	At least three of the four
Public works information	Signal E needs funded work by place	Check whether housing or public works are published by panchayat	Published by panchayat
Realistic livelihood stories	The personas must ring true	Ask someone who works there to read the five personas	They recognise all five
Language and dialect	The voice must sound local	Find a native speaker to record and review every line	Every line reviewed
20.3 The type of district that works best
Choose a mid-sized, mostly rural district with these features.
    • A district town with a few garment units and vehicle service centres.
    • A river or canal plain with dense villages and many home tailors.
    • An upland or forest-edge block where travel is slow.
    • A share of SC households above the state average, and working SHG federations.
    • Rural housing under construction this year.
    • A main language that someone on the team speaks natively.
This type gives the demo its two contrasts. A dense plain shows crowding. A remote block shows why local batches matter.
20.4 The seed district
Block	Type	Clusters	Role in the story
Sadar	District town and its edge	Lalpur, Katra, Mandi Kalan, Naya Tola	Employers: garment units and service centres. Kavita lives in Lalpur.
Nadi Paar	River plain, dense villages	Devgaon, Rampura, Bela, Sonpur	Crowded tailoring. Sunita and Asha live in Devgaon. Sonpur is the block town.
Pahadi	Upland	Khairwa, Amjhar, Dhanora, Patharia	Masons and housing works. Raju lives in Khairwa.
Nahar	Canal and highway belt	Tikri, Nayagaon, Mohanpur, Barwa	Two-wheeler repair. Manoj lives in Tikri.
Van Kshetra	Forest edge, remote	Kusumi, Mahuadih, Salaiya, Tendua	Long travel times. The local mason batch.
The district is called Pragati in the seed. All names are common place names used fictionally, and any match with a real place is a coincidence. Each cluster holds four to six villages, named in the seed.
20.5 Loading a real district
Changes through config	Does not change
District, block, cluster and village names	The rules and thresholds, until a pilot tunes them
Tile positions, or a boundary file	The labelling rules
Household counts, if real ones are loaded	The five label types
Language strings and audio	The screens
Cluster types used for peer comparison	The consent wording, apart from translation
If real place names are loaded while the figures stay simulated, the banner must change to "Real place names. Simulated figures." This mix is risky. Use it only if a judge asks for it.
20.6 Language
    • The seed language is Hindi in Devanagari, with an English line under each turn.
    • Record the voice with a native speaker from the region. A synthetic voice is acceptable for the agent, and less so for the beneficiary.
    • Say on the Data and Trust screen that speech recognition across dialects is not tested in this prototype.
    • "Hunar Line" is a config value. Translate it for the district.
21. Synthetic dataset strategy
A small hand-written seed and a seeded generator produce a district of about 600 people. The hero records are fixed by hand, and a validation step proves the demo's numbers before every build.
21.1 What the dataset contains
Record	Count	Made by
Blocks, clusters, villages	5, 20 and about 95	Hand
People	About 600: five personas, the rest generated	Generator
Households	About 520	Generator
Scripted conversations	4: Sunita, Raju, Manoj, and Asha's check-in	Hand
Worker checks	About 330	Generator
Past training records	About 250, in 9 past cohorts	Generator
Past outcomes	About 100 people reached and about 20 not reached	Generator
Supply inputs for signals A and B	One row for each of the 70 cluster and block cells	Hand for hero cells, generator for the rest
Demand documents	6	Hand
Providers and plan lines	3 and 4	Hand
Cells, verdicts, opportunities	72, 72 and 8 at the start	Computed

Past cohort	Provider	Completed	Reached at check-in
Beginner tailoring, Nadi Paar, three cohorts	A	72: Devgaon 27, Rampura 20, Sonpur 16, Bela 9	58
Beginner tailoring, Sadar	A	25	12
Sewing machine operator, Sadar, two cohorts	B	55	14
Rural mason, district centre	C	28	9
Rooftop solar installer	C	30	None followed up
Two-wheeler mechanic, Sadar	C	12	8
21.2 Twelve archetypes
Each generated person is drawn from one archetype. Shares are of all 600 people.
#	Archetype	Share	Typical skill evidence	Typical barrier	Concentrated in
1	Experienced home tailor, no certificate	12%	4 to 6 of 7 tailor units	Certification, market access	Nadi Paar, Sadar
2	Recent tailoring trainee, certified, little work	9%	Certificate held; few paid days	Market access	Nadi Paar
3	Member of an SHG order group	3%	Stitching units; busy	None	Nadi Paar, Sadar
4	Garment-unit worker	5%	Operator units; busy	None	Sadar
5	Construction helper becoming a mason	10%	2 to 4 of 7 mason units	Certification; skill partial	Pahadi, Van Kshetra
6	Experienced mason	5%	5 to 7 mason units	Certification	Pahadi, Nahar
7	Seasonal migrant on building sites	8%	2 to 4 mason units	Information, placement link	Pahadi, Van Kshetra
8	Two-wheeler mechanic, employed	5%	4 to 6 of 6 units	Certification partial	Sadar, Nahar
9	Mechanic who wants a shop	3%	4 to 6 of 6 units	Capital	Nahar
10	School-leaver with no work experience	18%	None	Skill	All blocks
11	Farm labourer seeking a change	17%	None, or tasks outside the catalogue	Skill, mobility	Van Kshetra, Pahadi, Nadi Paar
12	Electrical or solar helper	5%	Tasks outside the catalogue	Skill	Sadar, Pahadi
21.3 How the generator works
    1. Fix the as-of date, 2 October 2026, and a random seed in config. The same seed always gives the same district.
    2. Set quotas. Wherever the demo depends on a count, give each cluster a fixed number of people per archetype. Use probabilities only where no count matters.
    3. Draw attributes inside each archetype's ranges: age band, years of experience, unit levels, paid days, limits, goals and consent.
    4. Leave gaps on purpose. Leave 15% to 25% of optional fields unknown. Leave some people without stated travel limits.
    5. Generate past cohorts and training records. Then generate outcomes, cell by cell, to match each cell's intended reading.
    6. Insert the five hand-written personas with fixed IDs.
    7. Compute cells, verdicts and opportunities with the real rule modules.
    8. Run the validation checklist. Fail the build if any hero number is off.
The generator is a build-time tool. Its output is committed as seed files, so the demo never depends on it running.
21.4 Validation checklist
Check	Expected at seed
Devgaon, own tailoring, inputs	84 existing; 27 trained; 15 worker checks with median 9 and 1 who turned work away; 22 due, 19 reached, 6 working
Devgaon, own tailoring, result	Likely crowded, medium
Tailors pre-screened likely ready who can reach the Devgaon panchayat hall	19: Devgaon 8, Rampura 5, Bela 3, Sonpur 3
Of those 19, people who can reach the Sonpur block office and be home on time	13. With Sunita it becomes 14 of 20.
People interested in uniform orders, Nadi Paar	12
People who want to start own tailoring in Devgaon	11
Masons partly ready in Pahadi	23 including Raju. 21 lack unit M1.
Mason beginners in the Kusumi and Mahuadih clusters who can reach the site venue	18 across 5 villages: 11 with stated limits, 7 without. 4 more are left out.
Mechanics who want their own shop, Nahar	4 including Manoj
Skilled or trained sewing machine operators within reach of Sadar	26
Provider A, Nadi Paar	72 completed, 56 claimed working, 58 reached, 20 verified working
The other hero cells	As in section 10.5
Own tailoring across the 20 clusters	6 likely crowded, 9 uncertain, 5 likely room
After Sunita's choice	O1 at 20; O2 at 13; Devgaon workload on 16 people
After Asha's check-in	Devgaon outcomes on 20 reached; confidence high

Own tailoring verdict	Clusters
Likely crowded	Devgaon, Rampura, Sonpur, Lalpur, Katra, Nayagaon
Likely room	Kusumi, Salaiya, Amjhar, Patharia, Barwa
Uncertain	Bela, Mandi Kalan, Naya Tola, Khairwa, Dhanora, Tikri, Mohanpur, Mahuadih, Tendua
Across all 72 cells, aim for about a quarter likely room, a quarter likely crowded and half uncertain. A district where everything is known would not be believable. Rural mason must be likely room in the Kusumi and Mahuadih clusters, so that opportunity O5 is allowed.
21.5 Realism rules
    • First names only, from a neutral list. Surnames are left out because they can signal caste.
    • Ages are bands between 18 and 45.
    • Avoid round numbers, and avoid the same value in two clusters.
    • Paid days follow the cell's reading: slack cells centre on 6 to 11 days, tight cells on 18 to 25.
    • About one past trainee in six cannot be reached.
    • About one person in ten declines planning use. Their answers feed no district count, and the screens still work.
    • Some cells have thin data and some have stale data.
    • Generated people have profile fields and no transcript. Their profile says "Generated profile. No transcript."
21.6 If time is short
The map and the drawer need only the cell inputs. People are needed only for candidate lists and the People table.
Cut	What to keep
Smallest seed that runs the demo	The five personas, about 60 supporting people in Nadi Paar, and hand-typed inputs for all 72 cells
Next step up	Add the people behind opportunities O4, O5, O7 and O8
Full seed	All 600 people from the generator
22. The 6 to 7 minute demo
The demo is one story told in twelve beats and seven minutes: Sunita's call, the district's decision, and Asha's follow-up. Run it in Story Mode, with one person speaking and one person driving.
22.1 The script
Time	Beat	Screen	The driver does	The audience sees	The speaker says
0:00 to 0:30	1. The problem	Story Mode opening: plan line L1 beside an idle phone	Nothing	"Beginner tailoring course, Nadi Paar, 30 seats"	"This is a district's skilling plan. Thirty more women will be trained as tailors in Nadi Paar. Nobody asked whether Nadi Paar needs thirty more tailors, or what happened to the last seventy-two. The national audit of PMKVY found about 40% of certifications in just ten job roles. We built the instrument that asks. Every number you will see is seeded."
0:30 to 1:30	2. Consent and her story	V1, then V2 on the left. Transcript on the right.	Plays A1 to B4 at 1.5x, then B6 and B8	Her words appear. Quotes gain a marigold underline.	"Sunita is with Rekha, a self-help group worker she knows. There is no form and no question about caste. She is asked what she did yesterday." Then let her speak.
1:30 to 2:15	3. Skill evidence	Skill evidence pane	Lets the units fill	Marks change from "?" to ticks. The count reaches 5 of 7. The pre-screen banner.	"Her words become evidence against the national standard for a self-employed tailor. Five of seven core units are supported by what she described. Buttonholes she only claimed. Machine repair she does not do. This is a pre-screen. Only an assessor can certify."
2:15 to 2:55	4. What blocks her	Barriers and pathways pane	Advances one beat	Seven markers fill. "Primary barrier: certification and customer access. Not skill."	"So what is holding her back? Not skill. She has no certificate, and she got nine days of work last month. A course would cost her weeks of wages to learn what she already knows."
2:55 to 3:15	5. Options on her story alone	Options, with local evidence off	Nothing	Own tailoring is ranked first	"On her story alone, the best option is more tailoring in her own village. This is where most systems stop."
3:15 to 3:50	6. Options with local evidence	The same pane	Presses L	The rows change places. Own tailoring moves to third, marked "was 1st". An evidence line appears under each.	"Now add what the district knows. Eighty-four tailors. Twenty-seven more trained in two years. Those we asked got nine days of work last month. Six of nineteen past trainees are working. No score. It says likely crowded, medium confidence, and shows why. Uniform orders move to first: the groups are turning work away, and there is a funded order."
3:50 to 4:05	7. Her choice	V5 and V6	Plays A12 briefly, then B13 and B14	She picks option one. "Chosen" appears.	"She hears all three, including the crowded one. She chooses."
4:05 to 4:35	8. The district sees it	Phone on the left, Livelihood Map on the right	Advances one beat	Her dot travels to Devgaon. The camp's dot row fills its 20th place. "Forming" becomes "Suggested". Line L1 is flagged.	"Her choice is now district evidence. She is the twentieth tailor nearby who is likely ready for assessment. An RPL camp is now viable. And the thirty-seat beginner batch carries a flag."
4:35 to 5:05	9. Why Devgaon is crowded	C2 with the drawer open	Clicks Devgaon	Six signals with sample sizes. "None found" under demand. "What would change this".	"The officer can open any place and see why. Each signal names its sample and the real source it stands in for. Where the evidence is thin, the map says uncertain."
5:05 to 6:00	10. The officer changes the plan	C3a, C4, C4a, then P2	Clicks "Use this venue" on Devgaon, "Add to plan", "Replace" on L1 with a typed reason, "Send to provider". Switches to Provider Desk and clicks "Confirm capacity".	Reach changes from 14 of 20 to 20 of 20. L1 is struck through. The before-and-after strip changes. The provider sees the cohort.	"The officer decides, not the system. She moves the camp to Devgaon so that all twenty can be home on time. She replaces the batch with the camp and an order group. Her reason and the evidence are stored with the decision. The provider gets a brief it can deliver."
6:00 to 6:40	11. The follow-up call	H3, V8, then C6	Opens Asha's task. Plays F2 to G3 and G5. Opens Outcomes.	The outcome strip gains one. Confidence goes from medium to high. A learning event appears. Provider A: 78% claimed, 34% verified.	"Eight months ago Asha finished a tailoring course. The provider recorded her as self-employed. We asked her. Five paid days last month. That is the twentieth verified outcome for Devgaon, and confidence rises to high. The provider claimed 78%. Verified: 34%."
6:40 to 7:00	12. Close	Story Mode closing: the two loops	Nothing	Diagnose, allocate, verify, as one loop	"One conversation diagnosed one person. Twenty conversations changed what the district funds. One follow-up call changed what it believes. Voice is only the front door."
22.2 If the slot is six minutes
Cut	Saves
Beat 4 becomes one sentence	20 seconds
Beat 9 is skipped. The drawer is shown only if asked.	30 seconds
In beat 10, skip the Provider Desk	10 seconds
Never cut beats 6, 8 or 11. They are the three proofs.
22.3 Story Mode
    • Story Mode holds the twelve beats as a list down the left edge. The current beat is marked.
    • Each beat sets the screens, the role view and the starting state. The driver never has to navigate.
    • Story Mode uses the real screens and writes the real events. It is not a slideshow of images.
    • A caption line at the bottom shows the beat's one-sentence point, for viewers who cannot hear.
    • Right arrow moves on. Left arrow goes back and undoes that beat's events. R resets everything.
22.4 Before the demo
    • ☐ Reset the demo and run all twelve beats once.
    • ☐ Confirm the validation checklist in section 21.4 passes.
    • ☐ Switch the network off and confirm nothing breaks.
    • ☐ Check audio volume in the room, and have the transcript visible in case the audio fails.
    • ☐ Keep a screen recording of a clean run, to play if the laptop fails.
    • ☐ Set the browser to full screen at 1440 px wide or more.
22.5 If a judge asks to see more
Request	Show	Time
"What about when you don't know?"	Manoj's profile, then Tikri on the map: uncertain, low confidence, a trial of two shops	30 seconds
"Does it ever recommend training?"	Kavita's profile: skill is the barrier, so a course is offered	20 seconds
"What if someone only half knows the trade?"	Raju's skill evidence: 3 of 7, a bridge on the missing units, 21 of 23 masons sharing one gap	30 seconds
"Can she choose the crowded option?"	Go back to beat 7 and choose option three. The choice is accepted, with an earlier check-in.	20 seconds
"Is this just scripted?"	Should-have: type one new sentence into the live box and watch it map to catalogue units, tagged "Live, unreviewed"	30 seconds
"Where do the numbers come from?"	C7 Sources and Rules	20 seconds
23. The WOW moment
The moment to remember is the twentieth dot. Sunita confirms her choice, her dot lands on the district map, an RPL camp becomes viable, and the planned beginner batch is flagged, all in one view and in under three seconds.
23.1 Two beats that make one argument
Beat	Direction	What the audience learns
The re-rank (beat 6)	The population changes her options	The system knows about everyone else in her area, and shows its evidence
The twentieth dot (beat 8)	Her choice changes the population's plan	Each conversation is also district evidence, and the plan responds
The re-rank is the setup. The twentieth dot is the moment. Together they show an individual conversation becoming population intelligence and then a changed allocation.
23.2 The re-rank, frame by frame
Time	What happens
Before	Three option rows. Own tailoring is first, tagged "Fits her limits. Pays at once." The switch "Rank with local evidence" is off.
0.0 s	The driver presses L. The switch turns on.
0.0 to 0.6 s	The rows slide to their new places. Own tailoring moves from first to third.
0.6 s	An outline stays at the old first position, labelled "was 1st", for two seconds.
0.8 s	One evidence line appears under each option, with its verdict mark.
After	Uniform orders: "Likely room. Groups are turning work away. A funded order this year." Garment-unit job: "Likely room. Not home by four." Own tailoring: "Likely crowded. 84 tailors, 27 more trained, about 9 paid days a month."
No number such as "0.63" appears anywhere. The reason is always a sentence with counts.
23.3 The twentieth dot, frame by frame
The screen is split. The phone is on the left, showing her confirmed choice. The Livelihood Map is on the right, with a strip beneath it that holds the RPL camp's dot row and plan line L1.
Time	What happens
Before	The Nadi Paar marker reads "19 of 20". The camp's dot row has 19 filled places and one empty place before the notch. L1 reads "Beginner tailoring course, 30 seats".
0.0 s	She says yes on V6. "Chosen" appears on the phone.
0.2 s	A marigold dot leaves the "Chosen" mark.
0.2 to 1.1 s	The dot travels to the Devgaon tile. The tile gains an indigo outline.
1.1 s	The dot settles into the dot row as the 20th. "19 of 20" becomes "20 of 20".
1.5 s	The notch is reached. "Forming" becomes "Suggested". A line reads "RPL camp is now viable."
1.9 s	L1 gains a flag: "Hold suggested. Likely crowded. Replace with RPL camp and order group."
2.3 s	The change feed gains a line: "RPL camp for tailors in Nadi Paar now has 20 of 20 candidates."
2.3 to 5.5 s	Nothing moves. The speaker says the line.
23.4 The frame a judge should be able to photograph
    • One marigold dot among nineteen indigo dots, at the notch.
    • "20 of 20" and "Suggested".
    • The flag on the 30-seat batch.
    • The phone, still showing what she chose.
    • The "Simulated" tag.
23.5 The line to say
"Her call was the twentieth. An RPL camp is now viable, and the district's thirty-seat batch is flagged. One conversation helped her, and it changed the plan."
23.6 Why it holds up under questions
    • The threshold is an operational fact, a provider's minimum for a camp. It is not a demand estimate.
    • The seed is arranged so that her call is the twentieth. Say so if asked. In a live district the same thing happens at whichever call crosses the line.
    • The flag is a suggestion. The officer replaces the batch herself in beat 10, with a typed reason.
    • Every element is reachable by ordinary navigation afterwards, so the moment is not a staged animation.
23.7 What to leave out of the moment
No confetti, no sound effect, no spinning counters, no zooming or tilting map, no chat bubble and no glow. The dot and the changed plan are enough.
23.8 If something fails
Failure	Fallback
The animation does not run	With reduced motion the changes appear at once, each with a two-second outline. The argument still holds.
Story Mode breaks	Confirm the choice in the Voice Session, switch to the District Console, and read the first line of the change feed.
The laptop fails	Play the screen recording.
23.9 The echo
Beat 11 repeats the pattern in small. One follow-up call adds one unit to the outcome strip, and the confidence strokes go from two to three. The audience has now seen the loop close twice.
24. Judge questions
These are the twenty hardest questions, each with an answer that concedes the limit first and then points to something on screen.
#	Question	Answer
1	Where did your data come from?	Three places. Qualifications and standards are real, copied from the national register with links. Scheme rules are quoted from PM-AJAY's guidelines. Every person, place and count is seeded and labelled as simulated. For each signal we name the real source a pilot would use.
2	Are these numbers real?	No, and every chart says so. We used a fictional district so that no invented number sits beside a real place name. What is real is the method: the signals, the rules and the labels.
3	How do you measure demand?	We do not, and we doubt anyone can at village level. We read observable signals: how many already do the work, how many were recently trained, how busy they are, what happened to earlier trainees, and whether funded work exists. Their votes give likely room, uncertain or likely crowded, with a confidence level.
4	What prevents hallucination?	The model has one job: extracting facts from her words. Every fact carries the quote it came from. Tasks map only to a closed catalogue. She confirms a spoken summary before anything is saved. Verdicts, rankings and barriers come from rules that print their reasons.
5	Does the AI decide someone's future?	No. Rules rank two or three options, and she chooses. She can choose the crowded option or decide later. The officer decides the plan and types a reason. Nothing here affects eligibility.
6	What if the system is wrong?	It will be, sometimes. So it states its confidence, treats thin evidence as uncertain, proposes a small trial instead of a full batch, and checks outcomes at 30, 90 and 180 days. A wrong call costs a small trial, not thirty seats.
7	What if the market changes?	The verdict describes today and never forecasts. Workload readings expire after 90 days and outcomes after 12 months. A new funded order changes the evidence at once. The drawer says what would change each verdict.
8	How do you verify skills?	We do not certify. We pre-screen: which core units her account supports with specifics, which she only claims, and which are unknown. A claim without detail stays self-reported. Certification stays with authorised assessors. After a camp, results are compared with the pre-screen.
9	How do you handle caste sensitivity?	Eligibility comes from the scheme's own list, so the conversation never asks caste or sub-caste and the data model has no such field. Seed names have no surnames. Family occupation is recorded only if she raises it, and counts only if she wants to continue it.
10	How do you protect beneficiary data?	Consent is spoken, in three parts, and each can be refused. We hold no identity numbers and no address. Officers see a first name and initial and never hear audio. Counts under five are hidden on the map. Every profile view is logged. A pilot would map this to the Digital Personal Data Protection Act.
11	Why does this need AI?	For one step: turning a spoken work history in a local language into structured facts with quotes. A form cannot do that for someone who does not read. Everything after that is rule-based on purpose, because decisions about people should be explainable.
12	Why isn't this just a dashboard?	A dashboard reports what happened. This produces decisions: ranked options for a person, and a proposed intervention with candidates, venue and evidence for the district. It also collects its own evidence, through conversations and follow-up calls.
13	Why wouldn't a government department build this itself?	It could, and it should own it. The rules sit open on screen so a department can adopt and tune them. What is missing today is the loop: local evidence going in and independent outcomes coming back. PM-AJAY already allows up to 4% of the grant for supervision, monitoring and evaluation.
14	How does this scale?	The unit of work is a ten-minute conversation run by a self-help group worker with a phone. The rules are simple counts, so computing is trivial. A new district needs a place list and a catalogue, not a new model. The hard part is voice quality in each language, which is why a helper is present.
15	How does the system learn?	By counting, not by training a model. Each conversation adds a workload reading. Each check-in adds a verified outcome. When counts cross a threshold, the verdict or its confidence changes, and a learning event records why. A pilot would tune thresholds against verified outcomes.
16	How do you prevent providers from manipulating outcomes?	Outcomes come from the person, on the number she gave before any provider was involved. The provider's claim is stored beside her answer and cannot overwrite it. Differences are listed for the officer. A pilot would also re-call a random sample.
17	How is this different from existing skilling portals or a counselling chatbot?	As far as their public descriptions show, they match one person to courses or jobs. We have not found one that weighs how many others in her village are sent the same way, or that feeds independently verified outcomes back into what is funded. This would sit alongside them.
18	Isn't "likely crowded" a way of telling poor people no?	It never blocks anyone. The option stays on her list and she can choose it. What changes is the advice she hears and what the district funds for the people already skilled. Today she is told nothing, and finds out after the course.
19	Your thresholds are arbitrary. Why 1.5 times? Why 20?	They are starting values, shown on the Rules screen, and we say so. The claim is the structure: several kinds of evidence and never one, workload and outcomes can veto, thin evidence gives uncertain. Viability thresholds are provider minimums that the officer sets.
20	What is actually built, and what is mocked?	Built: the rule modules, every screen, the event log and the conversation player, all running on seed data. Scripted: the conversations. Not built: telephony, dialect speech recognition, government integration and logins. The Data and Trust screen lists this.
Rules for answering
    • Concede the limit in the first sentence. Judges trust a team that names its own weak points.
    • Point to a screen. Almost every answer above has one: the drawer, the Rules tab, the Outcomes screen.
    • Never say a number is real unless it carries the "Real source" chip.
    • Never say "the AI recommends". Say "the rules rank, she chooses, the officer decides".
25. Security and privacy
Privacy is a visible part of the product. She is asked before anything is kept, each role sees only what it needs, and every view is logged. The prototype shows these controls and does not claim production security.
25.1 What is collected, and what never is
Collected	Why
First name, village, language	To address her and place her in a cluster
A phone number she gives	For the follow-up call. Stored masked.
Her work history, skills, limits and goals, with quotes	Her guidance; and, if she agrees, district counts
Paid days and work turned away	The workload signal, without her name
Her choice and later outcomes	The next step, and the outcome signal
Never collected: caste or sub-caste, religion, political views, identity numbers, street address or location coordinates, health details, and photographs of people. Seed names have no surnames.
25.2 Consent
    • Consent is spoken, in her language, in three separate parts: recording, planning use and a follow-up call (section 14.4).
    • Each part can be refused without ending the session.
    • Turn A1 tells her that caste is not asked and that existing benefits are unaffected.
    • She hears what was understood and can correct it before anything is saved.
    • She can withdraw later through the helper. "Record a withdrawal of consent" sits on H4 and on the profile's Timeline tab.
She withdraws	Effect
Planning use	Her answers leave every district count at the next recompute. Her own guidance continues.
Follow-up calls	Pending check-ins are cancelled
Everything	Her profile and transcript are deleted. Decisions already made keep an anonymous count and an audit note.
25.3 Who sees what
Data	Helper	District officer	Training provider
Name	First name	First name and initial	First name and initial, own cohort only
Phone number	Yes, to call her	Last two digits	No
Transcript text	No	Yes, and the view is logged	No
Audio	No	No	No
Skill evidence	No	Yes	Pre-screen band and the units to assess
Barriers and limits	Her next step only	Yes	Only limits that affect delivery
District counts and verdicts	No	Yes	No
Outcomes	Tasks for people she follows up	All, claimed and verified	Own cohorts, read-only
Audit log	No	Yes	No
Audio plays only in the Voice Session and in Story Mode. The beneficiary sees and hears only her own session.
25.4 Safeguards: built now, and needed for a pilot
Safeguard	In the prototype	In a pilot
Spoken consent in three parts	Built: V1 and V7	The same, with the consent audio kept
Pause	Built: V9	The same
Masked names and numbers	Built into each role view	Enforced by access control
Small counts hidden	Built: under 5 shows "fewer than 5"	The same, with the threshold reviewed
Audit log	Built from the event log	A log that cannot be altered
Role separation	Views only, with no login. The screen says so.	Sign-in and role-based access
Encryption and retention	Not built	Encryption in transit and at rest. Audio deleted after transcription unless she agreed to keep it. A retention period set by the department.
Language model use	Scripted. The optional live call sends one typed sentence and no names.	A deployment under the department's data terms. No identifiers in prompts. No training on beneficiary data.
25.5 Risks and mitigations
Risk	Mitigation
A helper or relative shapes her answers	The privacy tip, Pause, and a confirm-back she hears herself. A pilot re-calls a random sample without the helper.
A verdict or barrier is used to deny her something	Verdicts never affect eligibility. She can choose any option. Barriers are shown as supports to add.
She is identifiable in a small village	Counts under 5 are hidden. Villages do not appear on aggregate layers. The prototype has no export.
The system mishears her	Every fact is tied to a quote. She confirms the summary. Corrections are recorded.
Family occupation is used to steer her	It is recorded only if she raises it, and counts only if she says she wants to continue it
A provider misuses a candidate list	The list holds the minimum, and a pilot would expire it after delivery
The data is later used for another purpose	The purpose is stated in the consent. Planning use is separable. Every access is logged. A pilot needs a written policy.
25.6 For the hackathon build
    • Use no real personal data anywhere. Every person is simulated.
    • If the live layer uses a model key, keep it on the server side and out of the browser bundle.
    • Bundle fonts and icons locally. Load nothing from an outside address at run time, and add no analytics.
    • The live sentence box stores nothing after the page reloads.
25.7 Legal note
A pilot should map this design to the Digital Personal Data Protection Act, 2023 and its rules: notice in her language, consent for stated purposes, withdrawal, correction and erasure. This section states design intent and is not legal advice.
26. What not to build
Build nothing that the seven-minute story does not use. Each item below sounds impressive, costs real time, and weakens the three proofs.
Do not build	Why it tempts	Why it is excluded	Do this instead
An AI avatar or talking face	It looks like a product	A face adds nothing for a caller on a shared phone, and it reads as a gimmick	A voice and a speaking bar
A general chatbot ("ask me anything")	It is quick to add	It is the generic project this one must not be. It also invites answers nobody checked.	The fixed conversation phases in section 7
Blockchain certificates	It sounds secure	The product does not certify. Trust comes from the assessor and the audit log.	The pre-screen banner and the event log
A resume builder	Other teams will have one	The users are not applying for office jobs, and it shows nothing new	The cohort specification, which is what a provider needs
A job portal or course catalogue	It feels complete	Listings need real, current data and prove nothing about allocation	Seven pathways and three demand documents
Retrieval over scheme documents	It shows off the model	A few rules are needed, and they are already written into the product	Quote the two or three rules that matter, with a link
A multi-agent architecture	It sounds advanced	One extraction step and seven rule modules do the work. More agents add failure points and nothing to see.	One optional model call
Machine-learned demand forecasting	Judges like the word "prediction"	There is no data to train on. A forecast from invented data is the fake number this project exists to avoid.	The six signals and the vote rules
An employability or skill score	It is easy to display	A score hides its evidence and ranks people	Counts of units, with quotes
Model-written recommendations	It saves writing	Unreviewed text about a person's future is the main risk in this domain	Sentences produced by rules from a fixed set
Gamification, badges, streaks	It adds colour	It trivialises a livelihood decision	Clear next steps and a follow-up date
Social feeds or community features	It suggests engagement	It adds moderation and privacy problems and no evidence	Helper tasks
Twenty dashboards or a wall of metric tiles	It looks thorough	It hides the one thing that changed	Seven console screens and a change feed
3D, tilted or satellite maps	It impresses for a moment	A fictional district has no terrain. Depth hides the verdicts.	Flat tiles with patterns
Real telephony, IVR or WhatsApp integration	It is "the real channel"	Approvals, numbers and network risk, for a result the audience cannot tell apart from the phone frame	The helper-assisted session, with two disabled labels
Live speech recognition across dialects	It is the obvious AI feature	It fails in a noisy hall, and it is not the innovation	Recorded audio and scripted transcripts. One live sentence as a should-have.
Logins, roles and permissions	It seems necessary	It costs a day and the demo never shows it	A role switcher, and one honest line on the Data and Trust screen
Government system integration	It sounds deployable	It cannot be done at a hackathon and should not be claimed	Named sources, labelled "stands in for"
Several districts or many languages	It suggests scale	It triples the data work and thins the story	One district, one local language, English beneath
A native mobile app	"She uses a phone"	A phone-sized web view shows the same thing	The Voice Session in a phone frame
Payments or benefit transfers	It completes the journey	It is out of scope and risky to imitate	A blank cost field on each plan line
"Chat with your data" for the officer	It is fashionable	The officer needs evidence and a decision, not a conversation	The drawer and the Plan Builder
Dark mode and theme switching	It feels polished	It doubles the design work	One well-made light theme
Exports and report generators	Officials like reports	A file full of simulated numbers can travel without its label	On-screen views only
How to use this list
    • If a new idea appears during the build, ask one question: which of the twelve beats does it serve? If none, leave it.
    • If time runs out, cut from section 27's nice-to-have list first. Never cut a label, a consent step or the outcome check.
    • When a judge asks about an excluded item, say it was left out on purpose and give the reason from this table.
27. Must-have, should-have, nice-to-have
The must-have list is exactly what the twelve beats use. Finish and polish all of it before starting anything from the next list.
27.1 Must have
Item	Where	Used in beat
Shell: top bar, role switcher, simulated banner, Reset demo	Shared	All
Smallest seed, with the validation checklist passing	Sections 21.4 and 21.6	All
Scripted conversation C-01 with audio, transcript and playback controls	V1 to V7, V9	2, 7
Skill catalogue for tailor, mason and two-wheeler; evidence levels; pre-screen	Section 8	3
Skill evidence pane with quotes linked to units, and the pre-screen banner	C5a, Story Mode	3
Barrier rules, the summary sentence and support packages	Section 9	4
Both rankings, and the "Rank with local evidence" switch with its re-rank motion	Section 9.5	5, 6
Signal, verdict and confidence modules, with explanation sentences	Section 10	6, 9
Livelihood Map with the verdict layer and the pathway picker	C2	8, 9
Evidence drawer for every cell	C2a	9
Opportunities O1, O2 and O3, computed by the allocation module	C3, C3a	8, 10
Venue options with reach, and "Add to plan"	C3a	10
Plan with lines L1 to L4, flags, replace with a typed reason, and the before-and-after strip	C4	10
Cohort specification, "Send to provider", and "Confirm capacity"	C4a, P1, P2	10
Asha's check-in, the helper task that opens it, and the outcome rule	H3, V8	11
Outcomes screen: claimed against verified, and learning events	C6	11
Outcome feeding signal D, with confidence going from medium to high	Sections 10 and 12	11
Story Mode with twelve beats, and the dot travelling to the map	S1	All
Change feed on the Overview	C1	8
Provenance chips and "Simulated" tags on every number, chart and table	Everywhere	All
Sources and Rules tabs	C7	Questions
Runs with the network off	Everywhere	All
27.2 Should have
Item	Why it strengthens the prototype
Raju's and Manoj's conversations, playable from their profiles	They show a bridge module, an uncertain cell and a choice against the ranking
Kavita's and Asha's profiles	They show that training is offered when skill is the barrier, and that a certified person may need a market instead
Opportunities O4 to O8 with detail pages	They show the engine is general, not built for one story
The other four map layers, the block level and the table view	They answer "where is the hidden skill?" and make the map accessible
The full 600-person seed	It gives the People table and the dots real density
People table, and the Summary and Timeline tabs of the profile	They complete the officer's journey
Live sentence mode	It answers "is this just scripted?"
Entry route check on the pre-screen	It ties the pre-screen to the qualification file's own wording
Pre-screen compared with assessed results, as one line on C6	It shows the skill engine can be checked too
Provider's outcomes record	It completes the provider's journey
Helper's Today, New session and Person card screens	They complete the helper's journey
Consent and Audit log tabs	They make privacy visible
Keyboard control of the map, and reduced-motion versions	They meet the quality bar in section 30
Local-script text in the Voice Session, with English beneath	It makes the phone view believable
27.3 Nice to have
Item	Note
Corroborated evidence: a helper adds a photo of finished work	Level 3 in section 8.2
Provider's "Propose a change" flow	Dates, venue or seats
"Keep anyway" override, with an earlier check-in	Section 11.6
Withdrawal of consent, end to end	Section 25.2
Block fallback for outcomes, and stale-data handling	Section 10.3
A second local language	Config only
A real district loaded through config	Section 20.5, and only with the changed banner
Console layout under 1024 px	The demo runs on a laptop
A printable cohort specification	On screen is enough for the demo
Recording a live voice in V2	The transcript stays scripted
27.4 Never cut
These are small, and the project's honesty depends on them.
    • The "Simulated" banner and tags.
    • The consent screen and the Pause control.
    • The pre-screen banner.
    • The "uncertain" verdict and its hatched look.
    • The typed reason when the officer replaces a plan line.
    • The independent check-in.
28. Implementation phases
Build in eight phases, and keep a working demo at the end of each. Phase 0 and a thin pass through the story come first. Depth comes after.
28.1 Overview
Phase	Goal	Share of effort	Depends on
0. Foundation	A shell that loads the seed, switches roles and resets	10%	Sections 16, 18, 21
1. Beneficiary flow	Sunita's conversation plays end to end on the phone view	12%	Phase 0
2. Skill evidence and diagnosis	Her words become unit evidence, a pre-screen and barriers	15%	Phases 0 and 1
3. Local intelligence	Signals, verdicts, the map, the drawer and the re-rank	18%	Phases 0 and 2
4. Officer console	Overview, People, Profile, Data and Trust	10%	Phase 3
5. Allocation	Opportunities, the plan, the cohort and the Provider Desk	15%	Phase 3
6. Outcome verification	The check-in, the Outcomes screen and the feedback	8%	Phases 3 and 5
7. Story Mode and polish	Twelve beats, the WOW sequence, motion, states, rehearsal	12%	All
Spine first. Straight after Phase 0, wire one pass through beats 2, 6, 8, 10 and 11 using seeded results in place of the rule modules. Then replace seeded results with real modules, phase by phase. This way a demo exists from the first day.
If three people build. One takes the rule modules, the generator and validation. One takes the console. One takes the Voice Session, Story Mode and motion. Phases 4 and 5 can run in parallel once Phase 3 is done.
28.2 Phase 0: Foundation
Part	Phase 0
Builds	The app shell. Design tokens for colour, type and spacing. Top bar, role switcher, banner, Reset demo. Seed loader, config and event log. The shared marks: provenance chip, verdict marks, confidence strokes, evidence marks, person dot, unit-dot chart. Stubs for the seven rule modules that return seeded results. The smallest seed and the validation script.
Screens	The shell, and an internal component sheet that shows every token and mark
Functionality	Role switching, reset, offline loading
    • ☐ Switching role changes the whole layout.
    • ☐ Reset demo restores the seed state.
    • ☐ The validation checklist in section 21.4 passes.
    • ☐ The app runs with the network off.
    • ☐ Every mark in section 16.8 is readable in greyscale on the component sheet.
28.3 Phase 1: Beneficiary flow
Part	Phase 1
Builds	The phone frame. The scripted player: audio, turns, captions, speed. Consent, confirm-back, option tiles, choice, next step, pause. The helper's New session screen.
Screens	V0 to V7, V9, H2
Functionality	Plays C-01 from A1 to A16. Writes consent, confirmation and choice events.
    • ☐ C-01 plays through with audio and captions.
    • ☐ Pause blanks the screen and writes an event.
    • ☐ "Not right" re-asks only that item.
    • ☐ Choosing an option writes exactly one choice event. "Decide later" writes none.
    • ☐ The flow can be completed with the captions covered.
28.4 Phase 2: Skill evidence and diagnosis
Part	Phase 2
Builds	The catalogue for three trades. The Skill evidence module: levels, specifics, flags. The pre-screen. The Diagnosis module and support packages. The person-only ranking.
Screens	Skill evidence pane, Barriers and pathways pane, V4 content
Functionality	Evidence appears turn by turn. Quotes and units highlight each other.
    • ☐ Sunita shows 5 of 7 and likely ready. Raju shows 3 of 7 and partly ready. Manoj shows 5 of 6 and likely ready.
    • ☐ T6 is self-reported with its stated limit. T7 is not evidenced.
    • ☐ Clicking a unit highlights its quotes, and the reverse.
    • ☐ The pre-screen banner is present wherever a band is shown.
    • ☐ The qualification line carries a "Real source" chip and a working link.
    • ☐ The summary reads "Primary barrier: certification and customer access. Not skill."
    • ☐ No package contains a beginner course when skill is none.
28.5 Phase 3: Local intelligence
Part	Phase 3
Builds	The Signals and Verdict modules, with explanation sentences and "what would change this". The 72 cells. The with-place ranking and the switch. The tile map. The drawer with its small charts.
Screens	C2, C2a, the options pane with the switch
Functionality	Verdicts recompute when inputs or thresholds change. The re-rank animates.
    • ☐ The seven hero cells give the verdicts and confidence in section 10.5.
    • ☐ Changing a threshold in config changes verdicts with no change to code.
    • ☐ The Devgaon drawer matches section 10.6.
    • ☐ No score, index or decimal appears in any verdict area.
    • ☐ Sunita's two rankings match section 9.5, and the moved row shows "was 1st".
    • ☐ Uncertain tiles are hatched and no tile is blank.
    • ☐ Own tailoring shows 6 likely crowded, 9 uncertain and 5 likely room.
28.6 Phase 4: Officer console
Part	Phase 4
Builds	The left rail. The Overview with its change feed and decisions waiting. The People table. The profile's four tabs. Sources and Rules.
Screens	C1, C5, C5a, C7
Functionality	Each feed sentence opens the right place. Profile views are logged.
    • ☐ The seven seed sentences appear and each opens its target.
    • ☐ Opening a profile writes an audit event.
    • ☐ The Rules tab shows every threshold, read from config.
    • ☐ No caste field exists, and phone numbers are masked.
28.7 Phase 5: Allocation
Part	Phase 5
Builds	The Allocation module: pool, split, reach, venue, window, viability. Plan checks. The plan ledger with replace, reason and strip. The cohort specification. The Provider Desk. The link from a choice event to the threshold.
Screens	C3, C3a, C4, C4a, P1, P2
Functionality	Opportunities are computed, not typed. Decisions write events with reasons.
    • ☐ O1 is forming at 19 of 20 at seed, and suggested at 20 of 20 after Sunita's choice event.
    • ☐ Reach reads 14 of 20 for Sonpur and 20 of 20 for Devgaon.
    • ☐ L1 is flagged. Replace needs a typed reason. L1 stays visible as replaced.
    • ☐ The strip reads 120 beginner seats before. After all suggestions it reads 60, 43, 13, 26 and 2.
    • ☐ Sending puts the cohort in P1. Confirming capacity updates the status in C4.
    • ☐ Dismiss needs a reason and writes an event.
28.8 Phase 6: Outcome verification
Part	Phase 6
Builds	The Outcomes module. The check-in. The helper's tasks. Claimed against verified. Learning events. The update to signal D.
Screens	V8, H1, H3, H4, C6, P3
Functionality	A check-in changes the evidence and is announced as a learning event.
    • ☐ Asha's check-in gives "Needs support", with the source "the person, with a helper present".
    • ☐ Devgaon's outcomes go to 20 reached. Confidence becomes high. The verdict stays likely crowded.
    • ☐ The learning event appears on C6 and in the change feed.
    • ☐ Provider A shows 78% claimed and 34% verified, with counts.
    • ☐ Verified values cannot be edited from the Provider Desk.
28.9 Phase 7: Story Mode and polish
Part	Phase 7
Builds	Story Mode with twelve beats, the split view and its keys. The WOW sequence. All motion in section 17 with reduced-motion versions. Empty and error states. A pass on wording, local script and accessibility. Rehearsal and a recording.
Screens	S1, and every screen for states
Functionality	Each beat sets its screens and state. Going back undoes a beat's events.
    • ☐ All twelve beats run by arrow key in under seven minutes.
    • ☐ Going back one beat undoes that beat's events.
    • ☐ The frame described in section 23.4 can be reached and held.
    • ☐ Every criterion in section 30 passes.
    • ☐ A clean run has been recorded.
29. Antigravity handoff specification
Build this product: a one-district web prototype with four role views and a Story Mode, running offline on seed data, that plays the twelve beats in section 22 and passes section 30. Every product decision is made in this document. The developer chooses the tools.
29.1 Project objective
Item	Statement
What	The Livelihood Evidence Loop prototype, as specified in sections 4 to 21
For whom	A hackathon jury watching a seven-minute demo, then asking questions
Done when	Story Mode runs all twelve beats offline in under seven minutes, the validation checklist in section 21.4 passes, and every criterion in section 30 passes
Not the objective	A deployable system, real data, real telephony, logins or integrations
29.2 How to give this document to Antigravity
Step	What to do	Why
1	Put this blueprint in the repository as Markdown, one file per section, in a docs folder. Add an index file that says which sections each phase needs.	The agent reads files when asked. A rules file is capped at 24 KB, so the blueprint cannot live in one.
2	Write a short AGENTS.md at the workspace root, holding the rules in section 29.10 and a pointer to the docs folder	Antigravity keeps a root AGENTS.md or GEMINI.md active on every turn
3	Put longer topic rules in the .agents/rules folder, each with a trigger. Make the design rules load for interface files. Keep the data-honesty rules always on.	Always-on rules share a budget of about 20,000 tokens
4	Run one phase per conversation, and start each with the /plan command	It makes the agent write an implementation plan before it changes files
5	Read the plan and comment on it. Click Proceed only when it matches the phase in section 28.	A wrong reading of the brief is cheapest to fix in the plan
6	Ask for proof: tests for the rule modules, and a walkthrough with screenshots or browser recordings for screens	The walkthrough is the agent's own record of what it built
7	Give the agent a check it can run itself: the validation script from section 21.4	Agents do better with a local way to verify their work
These points were checked on 2 October 2026 against Antigravity's own documentation: Rules, Implementation plan, Walkthrough, Artifacts and Best practices. The product changes quickly, so confirm them before starting.
29.3 What is decided, and what the developer chooses
Decided here. Do not change.	The developer chooses
Scope: one district, four sectors, seven pathways	The web toolkit and language
The 31 screens and shared parts in section 15	File and folder layout
The rules, thresholds and seed numbers	How state is held, provided it is the seed plus events
The wording of verdicts, banners, buttons and spoken lines	How charts and the map are drawn, provided section 16 is met
The design direction and tokens	How the audio is produced: recorded or synthesised
The labelling rules in section 19	The test tools
The twelve beats	How the optional live call is hosted
Any tool is acceptable if it meets five requirements from section 4: it runs offline from static files, routes on the client, draws SVG, animates an element from one view to another, and carries no default look.
29.4 Exact pages
The paths are suggestions. What matters is that each screen has one address and that the address holds the view's state.
Path	Screen	Note
/story	S1 Story Mode	Opens at beat 1
/voice	V0 to V9	One path. Each screen is a state of the session, not a page.
/helper	H1 Today	New session, follow-ups and person card sit beneath it
/console	C1 Overview	The default for the District Console
/console/map	C2 and C2a	Pathway, layer, level and selected place are held in the address, so a feed sentence can open the exact view
/console/opportunities	C3	An opportunity's ID opens C3a
/console/plan	C4	A cohort's ID opens C4a
/console/people	C5	A person's ID opens C5a, with the tab in the address
/console/outcomes	C6	
/console/trust	C7	The tab is in the address
/provider	P1 Cohort inbox	A cohort's ID opens P2. Outcomes record sits beside it.
/components	Internal component sheet	Never shown in the demo
29.5 Exact user flows
The four journeys in section 6 are the flows. Three of them must work by ordinary navigation as well as in Story Mode.
    1. Session to district. New session, consent, conversation, confirm, skills, options, choice, next step. Then the change feed gains a line, and the map, drawer, opportunity list and detail all reflect her choice.
    2. Decision. Opportunity detail, add to plan, replace the flagged line with a reason, cohort specification, send. Then the Provider Desk shows the cohort, capacity is confirmed, and the plan shows the new status.
    3. Verification. The helper's task, the check-in, the Outcomes screen. Then the drawer for that place shows the new count and confidence.
29.6 Component hierarchy
App
|-- TopBar: DistrictName, SimulatedBanner, DataDate, RoleSwitcher, StoryModeButton, ResetDemo
|-- StoryMode: BeatList, SplitView (left pane, right pane), CaptionLine
|-- VoiceSession
|     |-- PhoneFrame, TopStrip, BottomBar (HearAgain, Pause, AskHelper)
|     |-- ScriptPlayer, VoiceState (speaking, listening, thinking, not caught)
|     |-- Screens V0..V9: LanguagePicker, ConsentQuestion, ConversationTurn,
|     |     SummaryLine, SkillIconList, OptionTile, ChoiceConfirm, NextStep,
|     |     CheckInQuestion, PausedScreen
|-- Helper: PhoneFrame, Today, NewSession, FollowUps, PersonCard
|-- Console
|     |-- LeftRail, PageHead
|     |-- Overview: ChangeFeed, DecisionsWaiting, SmallMap, DistrictFacts
|     |-- LivelihoodMap
|     |     |-- ControlStrip: PathwayPicker, LayerPicker, LevelToggle, ViewToggle
|     |     |-- TileMap: BlockOutline, ClusterTile, OpportunityMarker, ReferenceLines
|     |     |-- Legend, TableView
|     |     |-- EvidenceDrawer: VerdictHeader, SignalRow x6, ConfidenceNote,
|     |           WhatWouldChange, Recommendation
|     |-- Opportunities: OpportunityLedger, ThresholdDots
|     |     |-- OpportunityDetail: CandidateDots, VenueOptions, WindowOptions,
|     |           EvidenceSnapshot, PlanEffect
|     |-- Plan: BeforeAfterStrip, PlanLedger (PlanLine, Flag, History),
|     |     ReplaceDialog, CohortSpec (ProviderPicker)
|     |-- People: PeopleTable, Filters
|     |     |-- Profile tabs: Summary,
|     |           SkillEvidence (Transcript, UnitList, PreScreenPanel),
|     |           BarriersAndPathways (SummarySentence, BarrierStrip, OptionCard,
|     |             RankingSwitch, WhyThisOrder),
|     |           TimelineAndConsent
|     |-- Outcomes: CheckInStrips, ClaimedVerifiedRows, Differences, LearningEvents
|     |-- DataAndTrust: Sources, Rules, Consent, AuditLog
|-- ProviderDesk: CohortInbox, CohortDetail (Spec, CandidateList, ConfirmForm,
|     ResultsForm), OutcomesRecord
|-- Shared marks and charts: ProvenanceChip, VerdictMark, ConfidenceStrokes,
|     EvidenceMark, PersonDot, UnitDots, DotStrip, UnitStrip, MedianBar, ThresholdDots
|-- Shared structure: Ledger, Drawer, Dialog, EmptyState, ErrorState, LiveRegion

Not visual
|-- Config, SeedStore, EventLog
|-- Rule modules: SkillEvidence, Diagnosis, Pathways, Signals, Verdict, Allocation, Outcomes
|-- Views of state: everything a screen shows is computed from seed + events
SkillEvidence, BarriersAndPathways and the option list are each built once. The profile and Story Mode both use them.
PersonDot is marigold for the person in focus and indigo for everyone else. It is outlined when a detail is still to confirm.
29.7 States
Thing	States
Voice session	Not started; consent; in conversation; awaiting her confirmation; skills told; options shown; choice confirmed; decided later; stopped. Paused sits over any of these.
Voice	Speaking; listening; thinking; did not catch that
Skill unit	Not evidenced; self-reported; evidence-supported; corroborated; assessed
Pre-screen	Hidden until she confirms; likely ready; partly ready; not yet
Verdict	Likely room; uncertain, not enough evidence; uncertain, evidence is mixed; likely crowded. Each with low, medium or high confidence.
Opportunity	Forming; suggested; reviewed; added to plan; sent to provider; provider confirmed; change proposed; running; completed; outcomes verified; dismissed
Plan line	Proposed; flagged; kept against the evidence; replaced; resized; sent; confirmed
Check-in	Not due; due; one attempt; two attempts; visit task open; recorded; not reached
Outcome	The nine statuses in section 12.3
App	Role view; Story Mode beat; selected pathway, layer, level and place; reduced motion on or off
Any data view	Loaded; empty; error
29.8 Data required
Create these before any screen, in this order.
    1. Config: district, as-of date, language strings, every threshold.
    2. Locations and travel times.
    3. The catalogue: qualifications, standards and skill units from section 8.3.
    4. Pathways, providers and sources.
    5. Conversation C-01: turns A1 to A16 with audio, and its facts with quote positions.
    6. The five personas with their seeded evidence.
    7. Inputs for all 72 cells, starting with the seven hero cells.
    8. The supporting people for the smallest seed, plan lines L1 to L4, the demand documents and the starting events.
    9. The validation script that checks section 21.4.
29.9 Interactions, animation and layout
    • Section 17 lists the thirteen animations, their timing and their reduced-motion versions.
    • Build three first, because the demo rests on them: the re-rank, the dot travelling to the map, and the outcome feeding back.
    • The console is designed at 1440 px and must work at 1280 px. Story Mode needs 1280 px or more.
    • The Voice Session and helper screens are designed at 390 px and sit in a phone frame on a desktop.
    • Section 22 is the demo scenario. Story Mode drives it.
29.10 Rules for AGENTS.md
    1. Build only what the blueprint describes. If something is not specified, ask. Do not invent features.
    2. Never invent a number. All data comes from the seed files. If a value is missing, stop and ask.
    3. Every number, chart and table shows its provenance and a "Simulated" tag.
    4. No score, index or demand figure anywhere. A verdict is one of three states with a confidence level.
    5. Rule modules are separate from the interface. Each returns a result and its explanation sentences. Thresholds come from config.
    6. The language model never ranks, sets a verdict or names a barrier.
    7. No fields for caste, religion, surname, identity number or address.
    8. The pre-screen never says "certified". The banner text is fixed.
    9. State is the seed plus the events. Never edit seed data in place.
    10. The app runs offline. Nothing is requested from an outside address at run time.
    11. Follow section 16. No UI kit default look, no gradients, no glass effects, no emoji, no generated images, no official emblems.
    12. Use the blueprint's exact wording for verdicts, banners, buttons and spoken lines.
    13. Every action works by keyboard, focus is always visible, and every animation has a reduced-motion version.
    14. After each phase, run the validation script and that phase's checks, and show a walkthrough.
    15. Add no dependency without saying what it is for.
29.11 The opening message
Build this product. The specification is in docs/blueprint. Read the index first,
then sections 1, 4, 15, 16, 18 and 21, and section 28.2.

Do Phase 0 only. Start with a plan, and wait for my approval before changing files.

Your plan must state:
1. The tools you propose, and how each meets the requirements in section 4.
2. The files you will create.
3. How the seed loads with the network off, and how Reset demo works.
4. How the event log produces what each screen shows.
5. How you will prove each check in section 28.2, including the checklist in section 21.4.

Follow AGENTS.md. Do not invent data, features or wording.
If the blueprint does not answer a question, ask me.
When the phase is done, give me a walkthrough with a screenshot or recording for each check.
For each later phase, send the same shape of message: the phase number, the sections it depends on, "plan first", and "prove each check".
29.12 What to look for in every plan
    • ☐ It names the blueprint sections it read.
    • ☐ It lists the files it will create or change.
    • ☐ It adds no screen or feature beyond section 15.
    • ☐ It keeps the rules out of the interface code.
    • ☐ It introduces no number that is not in the seed or the config.
    • ☐ It says how each acceptance check will be shown to pass.
30. Acceptance criteria
The prototype is finished when every check below passes on the seed data, with the network off. The checks are grouped by what they protect: the three proofs, honesty, agency, explainability, the demo, and the quality of the interface.
30.1 The three proofs
    • ☐ Diagnose. Playing C-01 gives 5 of 7 core units with their quotes, a pre-screen of likely ready, and the sentence "Primary barrier: certification and customer access. Not skill."
    • ☐ Allocate, for her. Switching local evidence on moves own tailoring from first to third, marks it "was 1st", and shows an evidence sentence under each option.
    • ☐ Allocate, for the district. Her confirmed choice takes opportunity O1 from 19 to 20, changes it to suggested, flags plan line L1 and adds a sentence to the change feed.
    • ☐ The officer can replace L1 with O1 and O2 only after typing a reason. The reason and the evidence as it stood are kept in the line's history.
    • ☐ Verify. Asha's check-in takes Devgaon's outcomes to 20 reached, raises confidence to high, leaves the verdict unchanged and logs a learning event.
30.2 Honesty about data
    • ☐ The banner "Simulated district. Every figure here is demo data." is on every data screen and cannot be dismissed.
    • ☐ Crop test: a screenshot of any single chart or table still contains the word "Simulated".
    • ☐ Every signal row names its kind of source and the real source it stands in for.
    • ☐ "Real source" appears only on items that have a link and a date read.
    • ☐ No score, index, decimal percentage or demand figure appears anywhere in the interface.
    • ☐ No real district name, ministry logo or emblem appears.
    • ☐ The pre-screen banner appears wherever a band appears. The word "certified" never describes a pre-screen.
    • ☐ Output from a live model call is tagged "Live, unreviewed" and changes no seeded count.
30.3 Agency and privacy
    • ☐ She is offered two or three options and "Decide later". A likely crowded option can be chosen.
    • ☐ Consent has three parts. Refusing planning use keeps her out of every district count. Refusing the follow-up call schedules no check-in.
    • ☐ Pause hides the screen's content and stops recording in one tap.
    • ☐ No screen or record asks for or stores caste, religion, a surname, an identity number or an address.
    • ☐ The officer sees a first name and initial, a masked phone number and no audio.
    • ☐ Profile views and evidence views appear in the audit log.
    • ☐ Map layers show "fewer than 5" for any count under five.
30.4 Rules and explanations
    • ☐ Each verdict shows its votes, its confidence note and what would change it.
    • ☐ The seven hero cells match section 10.5. Both kinds of uncertain occur in the seed.
    • ☐ Changing a threshold in config changes the results with no change to code.
    • ☐ Each ranking has a "Why this order" list in plain sentences.
    • ☐ The same inputs always give the same recommendation sentence.
    • ☐ Reset demo returns every screen to its seed state.
30.5 Demo readiness
    • ☐ The twelve beats run by arrow key in seven minutes or less.
    • ☐ Going back a beat undoes that beat's events.
    • ☐ The validation checklist in section 21.4 passes.
    • ☐ A clean run has been recorded as a fallback.
    • ☐ The three flows in section 29.5 also work without Story Mode.
30.6 Frontend quality bar
The interface must look like a finished civic product from a serious government technology team, at the standard of the best product design.
It must not look like	The usual cause	What to do instead
A generic AI dashboard	Gradients, glow, a chat box, a wall of metric tiles	A change feed, a map and ledgers
A Bootstrap or UI-kit template	Default components and default spacing	Tokens from section 16, applied everywhere
A college project	Uneven spacing, mixed fonts, empty states that say "No data"	One spacing scale, one family, written empty states
A generated admin panel	Every list as cards, every number as a tile	Tables for lists, sentences for single facts
A collection of cards	Cards used to group things	Space and headings. Cards only for objects acted on.
Checks to run on every screen, with a screenshot in hand.
    • ☐ One focal point. At arm's length, the eye lands on the thing the screen exists to answer.
    • ☐ Five-second test. Someone who has not seen the map can say which places are crowded for tailoring within five seconds.
    • ☐ Greyscale test. Verdicts, evidence marks and provenance are still distinguishable with colour removed.
    • ☐ Spacing. Every gap is a step on the 4 px scale. Related things sit closer than unrelated things.
    • ☐ Type. One family. Sizes only from the scale. No all-capital labels. Tabular figures in every table.
    • ☐ Hierarchy. Each screen has one page title, clear section headings and at most one large figure.
    • ☐ Colour. Only the tokens. Marigold marks only the person in focus. Indigo marks only actions, selection and verified items.
    • ☐ Cards. No card holds a metric, wraps a table or groups a section.
    • ☐ Density. A console table shows 15 to 25 rows at 1440 by 900 px and is not padded to look spacious.
    • ☐ Charts. Each one states its finding in its title, shows its sample size and uses a form from section 16.6.
    • ☐ Motion. Only the animations in section 17, each under a second except the travelling dot.
    • ☐ States. Every data view has an empty state and an error state that say what to do next.
    • ☐ Words. Buttons are a verb and an object. Sentence case throughout. No "AI-powered", "smart" or "insights".
    • ☐ Navigation. Every sentence in the change feed opens the exact view it describes. Closing a drawer or dialog returns focus to where it was.
    • ☐ Detail panels. The evidence drawer never hides the selected tile, and opening it does not move the map.
    • ☐ Provenance. From any number, its source is one click away.
    • ☐ Two products, one family. The Voice Session and the console look clearly different, and share the dot and the colours.
Review each screen as a stranger would. If something looks like a template, change that first.
30.7 Accessibility and robustness
    • ☐ Text contrast is at least 4.5 to 1, and marks are at least 3 to 1.
    • ☐ Journey B can be completed with the keyboard alone, and focus is always visible.
    • ☐ With reduced motion on, every change still shows, with an outline in place of movement.
    • ☐ Charts have text alternatives, the map has a table view, and changes are announced.
    • ☐ Every spoken line has its text on screen.
    • ☐ The console works at 1280 px and 1440 px wide, and at 125% zoom.
    • ☐ The app loads from local files in under two seconds and logs no errors in the browser console.
    • ☐ Nothing shifts position while an animation plays.
31. Final architecture diagram
The whole product is one chain that closes on itself: a conversation becomes evidence, evidence becomes a decision, and the result of the decision becomes evidence again. Two people decide along the way, and the system decides nothing.
31.1 System flow
Beneficiary, with a local helper
  |
  v
Voice session (helper-assisted)        consent: recording, planning use, follow-up call
  |
  v
Conversation understanding             language model: facts with quotes, closed catalogue
  |                                    she confirms the spoken summary
  v
Livelihood profile                     household, skills, workload, limits, goals, support
  |
  +--> Skill evidence -----------------> level per skill unit, RPL pre-screen       [rule]
  +--> Barrier diagnosis --------------> seven barriers, the primary barrier        [rule]
  |
  v
Pathway engine  <----------------------- reads verdicts for her place
  |                                    two or three options, each with a support package
  v
SHE CHOOSES, or decides later          <== human decision 1
  |
  |   with planning consent, writes: workload check, skills, interest, limits
  v
District livelihood intelligence       evidence store: one record per cell (place x pathway)
  |
  v
Opportunity and crowding signals       signals A to F -> votes -> verdict + confidence  [rule]
  |
  v
Allocation engine                      RPL camp, bridge, local batch, trial, hold,
  |                                    order linkage, enterprise support, placement drive
  v
THE OFFICER DECIDES, with a reason     <== human decision 2
  |
  v
Intervention                           plan line + cohort specification to a provider
  |
  v
Training / RPL / business support / placement        the provider delivers and reports
  |
  v
Independent outcome verification       check-ins at 30, 90 and 180 days, answered by her
  |
  v
District intelligence updated          signal D, verdict and confidence recomputed;
  |                                    a learning event is logged
  v
Future allocation improved             the next ranking and the next plan read the new evidence
  |
  +------------------------------------> back to the Pathway engine and the Allocation engine
31.2 Who decides what
Step	Decided by	The system's part
What she said	She confirms it	Extracts facts with quotes
Skill evidence and barriers	Rules	Shows the quote behind each one
Which pathway	She	Ranks two or three options and gives reasons
Verdict for a place	Rules	Shows the signals, the votes and the confidence
What to fund	The officer	Proposes interventions with evidence
Capacity and dates	The provider	Sends the cohort specification
Certification	An authorised assessor	Pre-screens only
What happened afterwards	Her own answer	Asks, records, and compares with the provider's claim
31.3 How the entities relate
PLACES AND REFERENCE
  Location: district > block > cluster > village
  Occupation 1--n Pathway            Pathway n--1 Qualification
  Qualification 1--n Standard        Standard 1--n SkillUnit
  Location x Pathway = Cell          Cell 1--n SignalReading     Cell 1--1 Verdict

PEOPLE AND THEIR WORDS
  Location 1--n Beneficiary          Beneficiary n--1 Household
  Beneficiary 1--1 Consent           Beneficiary 1--n Task
  Beneficiary 1--n Conversation      Conversation 1--n Turn      Turn 1--n Fact

EVIDENCE ABOUT A PERSON  (computed from Facts)
  Beneficiary x SkillUnit     = SkillEvidence   (cites Facts and their quotes)
  Beneficiary x Qualification = PreScreen
  Beneficiary x Pathway       = BarrierStatus, PathwayOption
  Beneficiary 1--n Choice            Choice n--1 Pathway

EVIDENCE ABOUT A PLACE  (only with planning consent)
  Beneficiary 1--n WorkerCheck       WorkerCheck n--1 Cell   --> SignalReading C
  Beneficiary 1--n Outcome           Outcome n--1 Cell       --> SignalReading D
  Beneficiary (skills, interest, limits)                     --> SignalReading F
  DemandDocument n--1 Cell                                   --> SignalReading E

DECISIONS
  Verdict + Beneficiaries --> Opportunity   (computed)
  Opportunity 1--0..1 Intervention   Intervention 1--1 PlanLine
  PlanLine 1--0..1 Batch             Batch n--1 Provider     Batch n--n Beneficiary
  PlanLine n--n PlanLine             (replaced by)

RESULTS AND FEEDBACK
  Batch 1--n TrainingRecord          TrainingRecord n--1 Beneficiary   (provider-reported)
  Outcome --> LearningEvent --> Verdict                      (recomputed)

TRUST
  Every write --> AuditEvent         Every value --> Source  (kind; real or simulated)
31.4 The architecture in three sentences
People produce facts, and facts become evidence about a person. With her consent, the same facts become evidence about a place, and evidence about places becomes verdicts. Verdicts and people become opportunities, the officer turns opportunities into a plan, and verified outcomes correct the evidence for the next person.