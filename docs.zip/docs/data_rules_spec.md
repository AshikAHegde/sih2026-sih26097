# Data Model & Rule Modules Specification

## 1. Data Strategy & Constraints
*   **No Backend / No DB:** All state is local. `State = Seed Files + Event Log`.
*   **Simulated Data (The Generator):** ~600 people, 5 blocks, 20 clusters, ~330 worker checks, ~250 past training records.
*   **Real Data:** ONLY the National Qualifications Register inputs (Code, title, version, NSQF level).
*   **Labels:** Every metric must have a "Simulated" hatch/tag and a provenance chip (Official record, Self-reported, Verified, Estimated by rule).

## 2. Rule Modules (Deterministic, NO LLM Decisions)

### Module 1: Skill Evidence
*   **Input:** Extracted facts (action, object, tools).
*   **Process:** Maps to closed catalog (e.g., T1 Take measurements). Ranks level 0-4 (0: Not evidenced, 1: Self-reported, 2: Evidence-supported, 3: Corroborated, 4: Assessed).
*   **Output:** Pre-screen band (Likely ready: 70%+ core units; Partly ready: 40-69%; Not yet: <40%).

### Module 2: Diagnosis
*   **Process:** Evaluates 7 barriers: Skill, Certification, Capital, Market Access, Mobility/Time, Information, Placement.
*   **Output:** Generates a Support Package (e.g., if Skill is "none", package CANNOT contain a beginner course).

### Module 3: Pathways (Ranking)
*   **Logic:** Ranks by 5 unweighted keys: 1. Local verdict, 2. Fit with hard limits, 3. Skill fit, 4. Time to first income, 5. Goal match.
*   **Outputs:** Two lists ("Person only" and "With Place").

### Module 4: Signals (A-F) per Cell (Place x Pathway)
*   **A. Existing Workers:** Supply vs Peer Median.
*   **B. Recent Entrants:** Trained in last 24 months.
*   **C. Current Workload:** Median paid days, % turned work away (Slack vs Tight).
*   **D. Past Outcomes:** % working out of past trainees (Weak <35%, Strong >60%).
*   **E. Funded Demand:** Sanctioned work/orders.
*   **F. Our Callers:** Waitlist context (no vote).

### Module 5: Verdict
*   **Logic:** 
    *   *Likely Crowded:* 2+ crowded votes, 0 room votes from C, D, E.
    *   *Likely Room:* 2+ room votes, 0 crowded votes from C, D.
    *   *Uncertain:* Mixed evidence or < 2 signals.
*   **Confidence:** High (3+ signals, 20+ sample), Medium (10+ sample or named demand), Low (everything else).

### Module 6: Allocation
*   **Logic:** Groups people by level, checks travel time tables, compares viable sizes against thresholds (e.g., RPL Camp = 20 candidates). 
*   **Output:** Triggers Plan Flags (e.g., "Beginner seats in a likely crowded cell" flags for hold/replace).

### Module 7: Outcomes
*   **Logic:** 30/90/180-day check-ins. Answers (Paid days, earnings) update Outcome status (Working, Self-employed, Needs support).
*   **Output:** Updates Signal D, triggers Learning Event, compares against Provider claims.

## 3. The 5 Personas (Must match exactly)
1.  **Sunita (Devgaon):** 7 years tailoring. Needs certification/market access. Target: Uniform order group.
2.  **Raju (Khairwa):** 5 years masonry. Migrates. Needs RPL + bridge module + link to local housing works.
3.  **Manoj (Tikri):** Mechanic. Needs capital. Target: Enterprise support trial.
4.  **Kavita (Lalpur):** School leaver, no skills. Target: Machine operator course (Skill is the actual barrier here).
5.  **Asha (Devgaon):** Certified 8 months ago, no work. Follow-up validates lack of market access.
