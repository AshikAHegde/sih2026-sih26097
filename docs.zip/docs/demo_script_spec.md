# The 12-Beat Demo Script & WOW Moment

## Presenter "Story Mode" (S1)
Story Mode must allow the presenter to step through the 12 beats using keyboard arrow keys. It sets the exact screens and data state for each beat automatically.

### The 12 Beats (7 Minutes)
1.  **The Problem (0:00 - 0:30):** Show Plan Line L1 (Beginner tailoring, 30 seats, Nadi Paar). Highlight lack of feedback.
2.  **Consent & Story (0:30 - 1:30):** V1 (Consent) -> V2 (Conversation). Sunita speaks (audio at 1.5x). Facts highlight.
3.  **Skill Evidence (1:30 - 2:15):** Marks change from `?` to ticks. Count reaches 5 of 7. "Likely ready" banner appears.
4.  **What Blocks Her (2:15 - 2:55):** Barrier pane. Seven markers fill. Diagnosis reads: "Certification and customer access. Not skill."
5.  **Options (Person Only) (2:55 - 3:15):** Option 1 is "Own tailoring".
6.  **The Re-Rank (3:15 - 3:50):** Presenter hits 'L'. Local evidence toggles. "Own tailoring" slides to 3rd place with a "was 1st" outline. "Uniform orders" moves to 1st (funded order, groups busy).
7.  **Her Choice (3:50 - 4:05):** She chooses Option 1. "Chosen" tag appears.
8.  **THE WOW MOMENT (4:05 - 4:35):** 
    *   Marigold dot leaves phone UI and lands on Devgaon map tile.
    *   Camp dot row hits slot 20. Notch triggered. "Forming" -> "Suggested".
    *   Plan Line L1 (30 beginner seats) instantly flags: "Hold suggested. Likely crowded."
9.  **Why it's crowded (4:35 - 5:05):** Click Devgaon tile. Drawer opens showing 6 signals (84 tailors, 27 recent, 9 median days, etc.).
10. **Officer Changes Plan (5:05 - 6:00):** Officer clicks "Add to plan", replaces L1 with typed reason, sends cohort spec. Switch to Provider Desk -> "Confirm capacity".
11. **Follow-up / Verification (6:00 - 6:40):** Asha's check-in (5 paid days). Updates Devgaon outcomes to 20 reached. Confidence jumps to High. Provider claimed 78%, verified drops to 34%.
12. **Close (6:40 - 7:00):** Show the full loop diagram. 

## Strict Presenter Guardrails
*   Never say "The AI recommends". Say "The rules rank, she chooses, the officer decides."
*   If the animation fails, reduced-motion triggers an instant snap with a 2px indigo outline, preserving the narrative argument.
*   If asked "Where do numbers come from?", point to C7 (Sources and Rules) tab.
