# UI & Components Specification: Livelihood Evidence Loop

## 1. Design System & Tokens
**Colors:**
*   **Paper:** `#F5F7FA` (App background)
*   **Surface:** `#FFFFFF` (Tables, drawers, phone screen)
*   **Ink:** `#1A2233` (Text, table rules)
*   **Ink Soft:** `#55607A` (Secondary text)
*   **Rule:** `#D8DEE8` (Ledger lines)
*   **Indigo:** `#2F3E9E` (Primary actions, links, verified seal)
*   **Marigold:** `#F2A20C` (The person in focus / dot)
*   **Room:** `#0E7C6B` (Likely room - solid teal tint)
*   **Uncertain:** `#6B7385` (Grey diagonal hatch)
*   **Crowded:** `#B5471B` (Rust tint, fine dot pattern)

**Typography:**
*   Anek (or Noto Sans) with matching local script font.
*   **Crucial:** Use tabular lining figures for EVERY number in a table or chart.
*   Sentence case everywhere. No all-caps.

**Layout & Spacing:**
*   **Base Unit:** 4px (Steps: 4, 8, 12, 16, 24, 32, 48, 64).
*   **Console Grid:** 12 columns, 24px gutters, max width 1360px.
*   **Phone Frame:** 390x844px. Padding: 20px. Touch targets: min 64px, main controls 72px.
*   **Cards:** 8px radius, 1px border, NO shadows (except overlays/drawers).

## 2. Screen Inventory (31 Screens Total)

### Shared / Shell
*   **Top Bar & Role Switcher:** District name, "Simulated" banner, Data Date, View Toggle, Story Mode, Reset Demo.
*   **Story Mode (S1):** Beat list, split view, next/back arrows, caption line.

### Beneficiary Flow (Phone Frame - Voice First)
*   **V0:** Start and Language
*   **V1:** Consent (Recording, Planning, Follow-up)
*   **V2:** Conversation (Speaking bar, live meter, pause button)
*   **V3:** Confirm what we heard (4 lines, "Not right" on each)
*   **V4:** Skills found (Icons with ticks/marks)
*   **V5:** Your options (Ranked tiles, "Why?" button)
*   **V6:** Confirm choice
*   **V7:** Next step (Follow-up date)
*   **V8:** Follow-up check-in (4 questions)
*   **V9:** Paused (Protects privacy)

### Helper Flow (Mobile View)
*   **H1:** Today (Sessions planned, follow-ups due)
*   **H2:** New session (Name, cluster, language, disabled WhatsApp/Phone labels)
*   **H3:** Follow-ups (Task list)
*   **H4:** Person card (Task history, start check-in)

### District Console (1440px Desktop)
*   **C1:** Overview (Change feed, decisions waiting, small map, metrics)
*   **C2:** Livelihood Map (Tile map, pathway/layer/level toggles)
*   **C2a:** Evidence drawer (Slides in right, 6 signal rows, provenance chips)
*   **C3:** Opportunities (Grouped ledger, threshold markers)
*   **C3a:** Opportunity detail (Candidate dots, venue reach, plan effect)
*   **C4:** Plan Builder (Before-and-after strip, plan ledger, flags, replace dialog)
*   **C4a:** Cohort specification (Provider picker, brief)
*   **C5:** People (Dense table, filters)
*   **C5a:** Profile (Summary, Skill Evidence, Barriers & Pathways, Timeline & Consent)
*   **C6:** Outcomes (Claimed vs verified marks, learning events)
*   **C7:** Data and Trust (Sources, Rules, Consent, Audit log)

### Provider Desk
*   **P1:** Cohort inbox
*   **P2:** Cohort detail (Confirm capacity, report delivery)
*   **P3:** Outcomes record (Own claimed vs verified)

## 3. Motion & Animation Rules
*   **Strict Limit:** Max 1 second duration. NO random glowing, bouncing, or spinning. Cause-and-effect only.
*   **Re-rank (V5/C5a):** Options slide to new places (600ms). The old 1st place leaves an outline labeled "was 1st" for 2 seconds.
*   **WOW Moment Dot (Beat 8):** Marigold dot leaves the phone, travels in a straight eased path to the map, lands on the cluster tile (900ms), fills the 20th slot, notch triggers, and plan line flags.
*   **Accessibility:** Provide a reduced-motion fallback (instant snap + 2px indigo outline for 2 seconds).
