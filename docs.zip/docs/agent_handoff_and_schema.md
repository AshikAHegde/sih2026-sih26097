# Agentic IDE Handoff, Schema, & Synthetic Data Guide

This final document contains the specific IDE guidelines (`AGENTS.md` instructions), the exact Entity-Relationship schema for offline state management, and the rules for generating the synthetic seed dataset as dictated by the original blueprint.

## 1. AGENTS.md Directives (CRITICAL IDE INSTRUCTIONS)
*These rules must govern the AI agent's behavior throughout the build.*

*   **No Hallucinations/Inventions:** Build ONLY what the blueprint describes. If a feature is not specified, do not invent it.
*   **No Fake Numbers:** Never invent a number. All data must come from the Seed Files. If a value is missing, pause and ask the user.
*   **Strict UI Constraints:** Follow the Design System (Section 16). Do NOT use default UI kit themes, gradients, glassmorphism, emoji, generated images, or official government emblems.
*   **Labels are Mandatory:** Every number, chart, and table must explicitly show its provenance and a "Simulated" tag.
*   **No Black-Box AI:** No "scores", "indexes", or "demand figures" anywhere. A verdict is strictly one of three states (Likely room, Uncertain, Likely crowded) with a confidence level.
*   **Separation of Concerns:** Rule modules must be entirely separate from the interface code. Each module returns a result AND its plain-text explanation sentences. Thresholds must come from a `config` file.
*   **Strict Privacy Limits:** DO NOT create fields for caste, religion, surname, identity number, or address.
*   **Event-Driven State:** State is `seed + events`. NEVER edit seed data in place. Append events to the log to change state.
*   **Offline Only:** The app must run offline. Do not request resources from outside URLs at runtime. Add no analytics.
*   **Accessibility:** Every action must work via keyboard. Focus rings must be visible. Every animation MUST have a reduced-motion fallback.

## 2. Entity & Schema Definitions (Local Data Model)
*The prototype uses no backend. Implement these entities as local models/stores.*

### Reference Data
*   **Location:** Level (district, block, cluster, village), name, parent, type (rural/peri-urban), households, tile position.
*   **TravelTime:** From cluster, to cluster/venue, minutes, usual mode.
*   **Occupation / Pathway:** Name, sector, type, market scope, cost band, time to first income.
*   **Qualification / Standard / SkillUnit:** Code, title, version, NSQF level, main tasks. (This is the ONLY real data).
*   **Provider:** Name, sectors, centres.
*   **Source:** Name, kind, origin, date, the real source it stands in for.

### People & Conversations (Event-Sourced)
*   **Beneficiary:** First name, initial, age band, gender, village, masked phone, language, status. *(NO surname or caste).*
*   **Household:** Earners, income sources, seasonal migration, SHG membership, training history.
*   **Conversation / Turn / Fact:** The transcript data. Facts include quotes and specific actions.
*   **WorkerCheck:** Paid days last month, work turned away, rate direction.
*   **Consent:** Booleans for Recording, Planning Use, Follow-up call.
*   **Task:** Helper tasks with due dates.

### Computed Evidence & Decisions
*   **SkillEvidence:** Unit level (0-4), quotes, specifics, stated limits.
*   **PreScreen:** Qualification, core units supported, band (Likely ready, partly ready, not yet).
*   **BarrierStatus:** Pathway, barrier type, status (None, Partial, Blocking), specific quote.
*   **PathwayOption:** Rank (person only), Rank (with place), package, conflicts.
*   **Cell:** Location × Pathway.
*   **SignalReading (A-F):** Values, reading word, vote, sample size.
*   **Verdict:** The final cell status (Room/Uncertain/Crowded), confidence, votes, explanation.
*   **Opportunity / Intervention / PlanLine / Batch:** The district's planning ledger objects.
*   **TrainingRecord / Outcome:** Claimed vs Verified check-in data.
*   **AuditEvent:** Timestamp, role, action, object, reason, before/after states.

## 3. The Synthetic Dataset Generator
*Since you cannot connect to a real database, you must generate ~600 people using these strict 12 archetypes to make the demographic data realistic.*

**The 12 Demographic Archetypes (Total 600 people):**
1.  **Experienced home tailor, no cert** (12%): 4-6 tailor units. Needs cert/market access.
2.  **Recent tailoring trainee, certified, little work** (9%): Needs market access.
3.  **Member of an SHG order group** (3%): Busy, no barriers.
4.  **Garment-unit worker** (5%): Operator units, busy.
5.  **Construction helper becoming mason** (10%): 2-4 mason units. Needs cert/skill.
6.  **Experienced mason** (5%): 5-7 mason units. Needs cert.
7.  **Seasonal migrant on building sites** (8%): 2-4 mason units. Needs information/placement.
8.  **Two-wheeler mechanic, employed** (5%): 4-6 units.
9.  **Mechanic who wants a shop** (3%): 4-6 units. Needs Capital.
10. **School-leaver with no work experience** (18%): No skills. Needs Skill (Course).
11. **Farm labourer seeking a change** (17%): No relevant skills. Needs Skill/Mobility.
12. **Electrical or solar helper** (5%): Tasks outside the catalogue.

**Generator Rules:** 
*   Use a fixed random seed (Date: Oct 2, 2026).
*   Leave 15-25% of optional fields unknown.
*   Ages: 18-45 bands.
*   First names only (neutral list).
*   About 1 in 10 decline "planning use" consent (their data must NOT feed the district dashboard).

## 4. Final Verification (Before Handoff)
Before considering any phase complete, the IDE must ensure:
1.  **Crop Test:** Any screenshot of a chart/table contains the "Simulated" tag.
2.  **Greyscale Test:** Verdicts and evidence marks are distinguishable without color.
3.  **Traceability:** Clicking ANY number shows exactly where it came from (Source/Rule/Check-in).
